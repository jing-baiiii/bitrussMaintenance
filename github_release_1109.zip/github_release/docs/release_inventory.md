# Release Inventory

This directory contains the runnable source code and experiment documentation. The `data/` directory is distributed separately as `data.zip` because of its size.

| Location | Contents |
| --- | --- |
| `src/algorithms`, `src/dependencies` | Current kernels and dependencies for the four proposed methods |
| `experiments/src` | Drivers for independent-event timing, operation counts, RSS, capacity, accumulating-index, fixed-vertex insertion, and small-graph validation |
| `experiments/scripts` | Build, demonstration, full timing/count campaign, aggregation, validation, and packaging scripts. The DR/GH demonstration runs 26 configurations: 8 main-graph timing/count configurations, 8 GH scalability timing configurations, 4 insertion RSS/capacity configurations, 4 accumulating-index configurations, and 2 fixed-vertex insertion configurations. The full main timing/count entry point runs 52 configurations: 36 for the nine main graphs (9 graphs x 2 directions x timing/count) and 16 for GH/ID scalability (8 graph sizes x 2 directions x timing). |
| `experiments/preprocessing` | Original sampling source and dependencies, GH normalization source, and scope notes |
| `baselines/bai/upstream` | Unmodified local snapshot of Bai's upstream source |
| `baselines/bai/measured` | Source actually used for measurements, instrumentation, original build evidence, and source hashes |
| `data.zip` (external download) | Data directory distributed separately; see the download details below |
| `data/datasets/full` (inside `data.zip`) | All nine complete main graphs |
| `data/datasets/scale` (inside `data.zip`) | Frozen GH/ID graphs retaining 20%, 40%, 60%, and 80% of the original edges |
| `data/samples/paper9` (inside `data.zip`) | 36 event files: nine main graphs x two directions x two vertex-numbering schemes |
| `data/samples/scale` (inside `data.zip`) | 32 event files: eight scale graphs x two directions x two vertex-numbering schemes |
| `data/detection` (inside `data.zip`) | Candidate workloads and detection times for all nine graphs; DB insertion records are losslessly compressed with gzip |
| `data/reference` (inside `data.zip`) | 34 Bai event-timing records, plus raw outputs for 27 Bai resource/work-count configurations: 18 work-count configurations (nine graphs x insertion/deletion) and 9 insertion RSS/initialization configurations (one per graph) |
| `data/results/paper` (inside `data.zip`) | Results and recomputed summaries from the 88 completed configurations |
| `data/results/fixed_vertex` (inside `data.zip`) | Fixed-vertex insertion events, actual ordered insertion sequences, and checkpoint results for nine graphs |
| `data/results/supplement` (inside `data.zip`) | Submitted supplementary PDF, result CSV files, validation records, and checksums |
| `data/results/tables` (inside `data.zip`) | Per-table CSVs, submitted table snapshots, source hashes, and version information for 15 main-paper and 6 supplementary tables; also includes scalability results |
| `data/results/provenance` (inside `data.zip`) | Measured-kernel snapshots, supplementary experiment protocols, and version-selection records |
| `data/inputs.json` (inside `data.zip`) | Paths and SHA-256 hashes for all graphs and event files |
| `MANIFEST.sha256` | Integrity manifest for files remaining in this code repository |

The code and data are distributed separately because `data.zip` is approximately 248 MiB, exceeding GitHub's standard 100 MiB per-file upload limit. The data archive is publicly available on [Zenodo](https://zenodo.org/records/24081250), DOI [10.5281/zenodo.24081250](https://doi.org/10.5281/zenodo.24081250); [download data.zip directly](https://zenodo.org/records/24081250/files/data.zip?download=1). A mirror is available from https://pan.baidu.com/s/1P_Rwh-coqBwlR4wvtvJtbg?pwd=ytex (access code: `ytex`). Its SHA-256 is `011ef7926c3a506a055ba39f5a89c86aa1755bc020c4752dcebe14d10039ee70`. Extract it in the repository root; the archive contains a top-level `data/` directory. Graph filenames follow the experiment configuration names; original filenames are recorded in `data/inputs.json` under `original_filename`.

The 88 configurations in `data/results/paper` inside `data.zip` comprise the 52 main timing/count configurations listed above plus 36 supplementary configurations: 9 RSS, 9 allocation-capacity, and 18 accumulating-index configurations. The fixed-vertex experiment is stored under `data/results/fixed_vertex`.

The graph and event files retain the evaluated graph contents, vertex numbering, edge ordering, and event ordering.

## Included Results

- All experiment drivers for the four proposed methods compiled successfully; their algorithmic logic was not changed.
- Small-graph validation completed on 512 exhaustively enumerated graphs and 200 random graphs, covering 10,614 events and 42,456 method checks with no failures.
- The 88 completed configurations include 52 main timing/count configurations and 36 supplementary RSS, allocation-capacity, and accumulating-index configurations.
- SHA-256 hashes are provided for all 352 proposed-method raw result files. The archive also includes the 18 baseline work-count and 9 insertion RSS/initialization configurations.
- All 2,034 displayed numeric values in the 21 tables (main-paper Tables 2–16 and Supplementary Tables S1–S6) were checked against the included result files. Table 14 includes the mean and maximum of 500 event-peak RSS measurements under the independent-insertion protocol. See the [per-table results index](table_results.md).

The archive includes the ordered workloads, detector records, graph inputs, event-level outputs, and hashes for the experiments. Bai source attribution and license information are documented in `baselines/bai/README.md`.

## Upload Options

The code in this directory can be committed to Git as a whole; each included file is below GitHub's standard 100 MiB per-file limit. Download the complete `data.zip` archive separately using the link above.
