# Data and Upload Information

The code and experiment data are distributed separately because `data.zip` is approximately 248 MiB, above GitHub's standard 100 MiB per-file limit. The public data record is [available on Zenodo](https://zenodo.org/records/24081250), DOI [10.5281/zenodo.24081250](https://doi.org/10.5281/zenodo.24081250); [download data.zip directly](https://zenodo.org/records/24081250/files/data.zip?download=1). A mirror is also available from [Baidu Netdisk](https://pan.baidu.com/s/1P_Rwh-coqBwlR4wvtvJtbg?pwd=ytex) (access code: `ytex`). Its SHA-256 is `011ef7926c3a506a055ba39f5a89c86aa1755bc020c4752dcebe14d10039ee70`. The archive contains a top-level `data/` directory. Extract it in the repository root so paths such as `data/inputs.json`, `data/datasets/`, and `data/samples/` match the experiment scripts.

The archive contains the nine complete main graphs, frozen event files for those graphs, and four GH and four ID scalability graphs with their frozen events. Graph contents, vertex numbering, edge ordering, and event ordering match the evaluated inputs. For consistent paths and experiment configuration names, graph files use names such as `recordlabel.txt`, `starring.txt`, and `dblp.txt`. These are filename choices; the graph contents are unchanged. Original filenames are recorded in `data/inputs.json` under `original_filename`.

| Paper label | Configuration | Original filename | Release path |
| --- | --- | --- | --- |
| DR | recordlabel | out.dbpedia-recordlabel | data/datasets/full/recordlabel.txt |
| DS | starring | out.dbpedia-starring | data/datasets/full/starring.txt |
| YT | youtube | out.youtube-groupmemberships | data/datasets/full/youtube.txt |
| GH | github | github | data/datasets/full/github.txt |
| DT | team | out.dbpedia-team | data/datasets/full/team.txt |
| AM | actor-movie | out.actor-movie | data/datasets/full/actor-movie.txt |
| ID | imdb | out.komarix-imdb | data/datasets/full/imdb.txt |
| WK | WK | out.wiki-en-cat | data/datasets/full/WK.txt |
| DB | dblp | out.dblp-author | data/datasets/full/dblp.txt |

The datasets retain their original source attribution as described in the paper. Original filenames and SHA-256 values are listed in `data/inputs.json`.

## Events and Detection Records

`data/samples/paper9/` contains four files per main graph: `insert_ours`, `delete_ours`, `insert_bai`, and `delete_bai`. Each contains 500 ordered events. The `_ours` files use the internal vertex numbering assigned by the proposed-method graph loader; the `_bai` files use vertex identifiers from the original graph file. Use the matching numbering scheme when running each implementation.

The corresponding scalability files are in `data/samples/scale/<configuration>/`. The `insert.txt` and `delete.txt` files use the proposed-method numbering; `insert_bai.txt` and `delete_bai.txt` use the Bai input numbering. GH uses the frozen normalized graph, while ID uses the sampled graph. The published files and their hashes define the evaluated workloads.

`data/detection/<label>_ins.txt` and `_del.txt` record legal candidates and detection times. Columns are `u v trivial judge_time_ms`; `trivial=0` marks an accepted nontrivial event. The larger DB insertion file is losslessly stored as `.txt.gz` and can be read with Python's standard-library `gzip` module or `gzip -dc`. Compressed and uncompressed checksums are recorded in `data/detection/provenance.json`.

## Separate Distribution

The code is distributed through GitHub, and the experiment data are distributed in the `data.zip` archive linked above. The archive is separate because its size exceeds GitHub's standard per-file upload limit.

To create optional upload packages from the release root, run:

```bash
python3 experiments/scripts/package_uploads.py ../github_upload_packages
```

The script creates `code.zip`, `data_support.zip`, and individual ZIP files for the main and scalability graphs, preserving paths relative to the release root. ZIP files larger than 20 MiB are split into `.part001` segments; merge and extraction instructions are included in `README.txt`. Extract the desired packages into the same root directory. `data_support` contains the nine-graph event files, reference results, and compressed detection records.
