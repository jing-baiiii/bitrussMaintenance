# Reproducing the Experiments

## Environment and Timing Scope

The experiments use Linux, Bash, g++ with C++17/OpenMP, and the Python 3 standard library. The driver pins each process to a selected CPU and verifies that one thread is used. By default, it selects the first CPU allowed by the current affinity; `--cpu` can specify another permitted CPU.

Each independent event starts from the original graph state. Graph restoration, insertion-slot reservation, and correctness checks are outside the timed region. The timed region includes the event's graph and index updates, level processing, persistent-support maintenance, and kernel cleanup. The four methods' execution order rotates across events and repetitions. Timing and operation-count runs use separate builds. Three repetitions are reduced to a per-event median; means, geometric means, medians, P99, and maxima summarize the resulting event measurements.

## Build and Correctness Validation

```bash
bash experiments/scripts/build_drivers.sh
build/experiments/verify_oracle
```

The validator exhaustively checks all 3-by-3 bipartite graphs and runs seeded cumulative update sequences using seed `10720261027`, comparing against an independent static oracle. This command runs the small-graph validation suite.

## Main and Scalability Experiments

```bash
python3 experiments/scripts/run_paper.py --dry-run
python3 experiments/scripts/run_paper.py --output build/paper_results
```

The full campaign has 36 main-graph timing/count configurations (nine graphs, two directions, and timing/count modes) and 16 scalability timing configurations (four GH and four ID graph sizes, each in two directions). Download and extract `data.zip` as described in `datasets.md`, then select datasets as needed, for example `--datasets recordlabel github`. The complete main-graph campaign includes all nine main-graph configurations.

Before each run, the driver checks graph and event hashes. Outputs are written to a new directory. A complete 500-event configuration generates `summary/` automatically.

To run one configuration:

```bash
bash experiments/scripts/run_one.sh time data/datasets/full/recordlabel.txt data/samples/paper9/recordlabel_insert_ours.txt insert 500 3 2 build/one_run
```

The final `2` is an example CPU identifier and should be replaced with a CPU permitted on the current machine.

## Memory, Accumulating Updates, and Concentrated Insertion

```bash
bash experiments/scripts/run_all.sh
```

The demonstration entry point covers two main graphs, DR and GH, with 26 configurations: eight main-graph timing/count runs, eight GH scalability timing runs, eight memory/capacity/accumulating-index runs, and two concentrated-insertion runs. It also runs the independent small-graph validator.

The same general drivers can run the supplementary measurements on other graphs by changing the graph and `_ours` event paths:

```bash
build/experiments/memory data/datasets/full/recordlabel.txt data/samples/paper9/recordlabel_insert_ours.txt build/memory_DR 2
build/experiments/allocation data/datasets/full/recordlabel.txt data/samples/paper9/recordlabel_insert_ours.txt build/allocation_DR 2
build/experiments/index insert data/datasets/full/recordlabel.txt data/samples/paper9/recordlabel_insert_ours.txt build/index_DR 2
build/experiments/fixed_vertex data/datasets/full/recordlabel.txt build/fixed_vertex_DR 2 20260923
```

Process RSS and categorized requested capacities are measured using separate processes and instrumentation builds. The accumulating-index experiment applies each unique edge once, while independent-event timing preserves duplicate event rows.

The concentrated-insertion driver uses seed `20260923`, selects one left-side vertex, and applies 1,000 distinct cumulative incident insertions, including butterfly-free insertions. A separate validation sequence checks complete labels, total support, and persistent support at checkpoints 0, 100, 250, 500, and 1,000. The frozen event files in the data archive define the main experiment workloads.

## Bai Baseline and Result Files

`data/reference/manifest.json` lists 34 Bai event-timing records for the nine main graphs and GH/ID scalability experiments, with SHA-256 checksums. [Bai baseline documentation](../baselines/bai/README.md) describes the upstream snapshot, measurement source, build, and attribution. The unified baseline driver accepts `_ours` event files and maps them to the Bai graph representation.

`data/results/paper/` contains per-event outputs and summaries for 52 main timing/count configurations and 36 supplementary configurations. The small-graph validator independently checks all four proposed methods. The included experiment outputs and selected versions are indexed in [table results](table_results.md).

The all-candidate table uses `(sum of detection times for all legal candidates + sum of maintenance times for the 500 nontrivial events) / number of candidates`. The same detection cost is charged to each method. This component-wise cost corresponds to the specified two-stage workflow: detect candidates first, then run the original maintenance routine for nontrivial events. DB insertion detection records are gzip-compressed and read directly by the summarizer.
