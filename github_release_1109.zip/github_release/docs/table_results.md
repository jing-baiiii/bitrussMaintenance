# Results by Manuscript Table

Table numbers follow the current manuscript and supplement. Table 1 contains notation.

## Files

Each directory in the [per-table results index](../data/results/tables/) contains:

- `result.csv`: unrounded results recomputed from the included outputs; Table 2 reports static graph statistics.
- `sources.json`: source paths and hashes, selected version, aggregation definitions, and checks against the submitted table values.
- `submitted_table.tex`: snapshot of the corresponding manuscript table.

The machine-readable [index](../data/results/tables/index.csv) and [validation report](../data/results/tables/validation.json) summarize all 21 tables. Unless otherwise stated, three repetitions are reduced to a median per event, then statistics are computed over 500 events; P99 uses linear interpolation. The fixed-vertex experiment has 1,000 events.

| Table | Content and result directory | Selected results |
| --- | --- | --- |
| Table 2 | [Static graph statistics](../data/results/tables/Table02_datasets/) | Static properties of the nine datasets |
| Table 3 | [Acceptance and label-change rates](../data/results/tables/Table03_acceptance/) | Frozen candidate files and formal event outputs |
| Table 4 | [Speedups](../data/results/tables/Table04_speedup/) | Formal timing results for four methods and Bai baseline |
| Table 5 | [Insertion time statistics](../data/results/tables/Table05_time_insert/) | Mean, geometric mean, median, P99, and maximum |
| Table 6 | [Deletion time statistics](../data/results/tables/Table06_time_delete/) | Mean, geometric mean, median, P99, and maximum |
| Table 7 | [Two-stage workflow cost estimates](../data/results/tables/Table07_all_candidates/) | Detection records and nontrivial-event maintenance results |
| Table 8 | [Bai closure-edge query counts](../data/results/tables/Table08_closure/) | Formal work counts; insertion site 1 and deletion site 15 |
| Table 9 | [BM/SA algebra comparison](../data/results/tables/Table09_algebra/) | Formal operation-count and timing results |
| Table 10 | [SA/SAP filters and EE comparison](../data/results/tables/Table10_pruning/) | Formal operation-count and timing results |
| Table 11 | [Persistent-support counts](../data/results/tables/Table11_persistent/) | Formal operation counts |
| Table 12 | [Ten slowest events](../data/results/tables/Table12_top10/) | Selected by Bai baseline event median; proposed-method timing results |
| Table 13 | [Candidate edge-level groups](../data/results/tables/Table13_tiers/) | Formal counts and timing; the first bin includes zero-candidate events |
| Table 14 | [Insertion RSS and capacity](../data/results/tables/Table14_memory/) | Mean and maximum event-peak RSS under independent insertions; capacity from separate allocation runs |
| Table 15 | [Initialization](../data/results/tables/Table15_preparation/) | Initialization results for four methods and Bai baseline |
| Table 16 | [Final accumulating-update checkpoint](../data/results/tables/Table16_stability/) | Accumulating updates and per-query output |
| Table S1 | [Sun incidence representation size](../data/results/tables/TableS1_sun_incidence/) | Analytical calculations from $m+b$ and $4b$ |
| Table S2 | [Initial query costs](../data/results/tables/TableS2_query_initial/) | Query-record summary |
| Table S3 | [Post-insertion query distributions](../data/results/tables/TableS3_query_tail_insert/) | Query-record summary |
| Table S4 | [Post-deletion query distributions](../data/results/tables/TableS4_query_tail_delete/) | Query-record summary |
| Table S5 | [Candidate-detection cost components](../data/results/tables/TableS5_all_candidate_detection/) | Detection and maintenance records used by Table 7 |
| Table S6 | [Fixed-vertex concentrated insertion](../data/results/tables/TableS6_fixed_vertex/) | Nine-dataset experiment results |

Five-method outputs for the four GH/ID graph sizes are in the [scalability results](../data/results/tables/Figure_scalability/result.csv); the event records are under `data/results/paper/E5_*`.

## Aggregation and Scope

The 21 tables include 2,034 displayed numeric values, checked against the current manuscript at its displayed precision. The release recomputes `result.csv` from the included records and provides the Table 12 [TeX table](../data/results/tables/Table12_top10/latest_table.tex) and [selected-event details](../data/results/tables/Table12_top10/selected_events.csv). Speedups are computed from unrounded means and formatted at the end.

Table 2 summarizes static graph properties. Table S1 analytically derives explicit incidence-representation sizes from those properties.

Tables 7 and S5 report component-wise costs for the specified two-stage workflow: common detection followed by the original maintenance routine for nontrivial events. In the CSV files, `aggregate_mean_ms` is the estimated cost and `baseline_speedup` is the corresponding cost ratio. Table 14 reports memory results under the independent-insertion protocol; Max is the maximum among the 500 event-peak measurements.

## Selected Experiment Versions

The 88 configurations in the data archive comprise 52 main timing/count configurations and 36 supplementary RSS, allocation-capacity, and accumulating-index configurations. SHA-256 checksums are provided for all 352 proposed-method raw result files. See the [version selection record](../data/results/provenance/version_selection.json).

Bai baseline results include 18 work-count configurations for the nine graphs, nine insertion RSS/initialization configurations, and 34 main/scalability timing records. Run metadata, output hashes, and count definitions are included in [`resource_work_manifest.json`](../data/reference/resource_work_manifest.json).

The fixed-vertex concentrated-insertion experiment is an additional formal experiment. Query and all-candidate results are summarized from their corresponding event records. `data/results/provenance/` contains experiment protocols, input JSON, and measured-source snapshots.

## Recompute Summaries

From the release root, regenerate per-table summaries from the included records:

```bash
python3 experiments/scripts/export_tables.py
```

The command recomputes per-table CSV files, checks the manuscript table snapshots, and generates the Table 12 TeX file. `all_display_matches=true` and `all_latest_display_matches=true` indicate that the table values match the event-level results.
