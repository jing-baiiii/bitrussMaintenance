#ifndef DELETION_AUDIT61_H
#define DELETION_AUDIT61_H
#include <map>
#include <set>
#include <string>
#include <cstdint>
#include <limits>
namespace audit61 {
struct Frequency {
    long long initial=0,cascade=0,initialLogical=0,cascadeLogical=0,batches=0,last=-1;
};
struct Record {
    std::map<std::string,long long> counts;
    std::map<std::pair<uint32_t,uint32_t>,Frequency> frequency;
    std::map<uint32_t,long long> recomputes;
    std::set<std::pair<uint32_t,uint32_t>> admissions;
    std::map<const void*,uint32_t> originalIds;
    long long batch=0;
    void reset() {counts.clear();frequency.clear();recomputes.clear();admissions.clear();batch=0;}
};
inline Record record;
inline void add(const char* key,long long amount=1) {record.counts[key]+=amount;}
inline void update(uint32_t e,uint32_t k,long long loss,bool initial) {
    auto& f=record.frequency[{e,k}];
    if(initial) {++f.initial;f.initialLogical+=loss;} else {++f.cascade;f.cascadeLogical+=loss;}
    if(f.last!=record.batch) {++f.batches;f.last=record.batch;}
}
inline void rebuild(uint32_t e) {++record.recomputes[e];}
inline void admission(uint32_t e,uint32_t k) {record.admissions.insert({e,k});}
inline uint32_t original(const void* e) {return record.originalIds.at(e);}
}
#ifdef ABP_COUNT_OPS
#define A61_ADD(key, amount) audit61::add(key,amount)
#define A61_UPDATE(e,k,loss,initial) audit61::update(e,k,loss,initial)
#define A61_REBUILD(e) audit61::rebuild(e)
#define A61_ADMIT(e,k) audit61::admission(e,k)
#define A61_BATCH() (++audit61::record.batch)
#else
#define A61_ADD(key, amount) ((void)0)
#define A61_UPDATE(e,k,loss,initial) ((void)0)
#define A61_REBUILD(e) ((void)0)
#define A61_ADMIT(e,k) ((void)0)
#define A61_BATCH() ((void)0)
#endif
#endif
