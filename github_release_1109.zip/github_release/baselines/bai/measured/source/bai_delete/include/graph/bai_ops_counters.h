 























 




























#pragma once
#include <atomic>
#include "baiDeletionCounters.h"

namespace scnu {
     
    inline std::atomic<long long> g_bai_cand{0};
    inline std::atomic<long long> g_bai_cand_seed{0};
    inline std::atomic<long long> g_bai_baff{0};
    inline std::atomic<long long> g_bai_baff_exam{0};
    inline std::atomic<long long> g_bai_dec{0};
    inline std::atomic<long long> g_bai_dec_init{0};
    inline std::atomic<long long> g_bai_layers{0};
    inline std::atomic<long long> g_bai_layer_scan{0};
    inline void bai_reset_algq() {
        g_bai_cand.store(0, std::memory_order_relaxed);
        g_bai_cand_seed.store(0, std::memory_order_relaxed);
        g_bai_baff.store(0, std::memory_order_relaxed);
        g_bai_baff_exam.store(0, std::memory_order_relaxed);
        g_bai_dec.store(0, std::memory_order_relaxed);
        g_bai_dec_init.store(0, std::memory_order_relaxed);
        g_bai_layers.store(0, std::memory_order_relaxed);
        g_bai_layer_scan.store(0, std::memory_order_relaxed);
    }

#ifdef ABP_COUNT_OPS
    inline long long g_bai_ops_alg   = 0;    
    inline long long g_bai_ops_touch = 0;    
    inline void bai_reset_ops() { g_bai_ops_alg = 0; g_bai_ops_touch = 0; bai_reset_algq(); }
  #define BAI_OPS_ALG()      (++scnu::g_bai_ops_alg)
  #define BAI_OPS_TOUCH2()   (scnu::g_bai_ops_touch += 2)
  #define BAI_CAND()         (scnu::g_bai_cand.fetch_add(1, std::memory_order_relaxed))
  #define BAI_CAND_SEED(k)   (scnu::g_bai_cand_seed.fetch_add((long long)(k), std::memory_order_relaxed))
  #define BAI_BAFF()         (++baiDeletion::guards[baiDeletion::activeSite], scnu::g_bai_baff.fetch_add(1, std::memory_order_relaxed))
  #define BAI_BAFF_EXAM()    (scnu::g_bai_baff_exam.fetch_add(1, std::memory_order_relaxed))
  #define BAI_DEC()          (scnu::g_bai_dec.fetch_add(1, std::memory_order_relaxed))
  #define BAI_DEC_INIT()     (scnu::g_bai_dec_init.fetch_add(1, std::memory_order_relaxed))
  #define BAI_LAYER()        (scnu::g_bai_layers.fetch_add(1, std::memory_order_relaxed))
  #define BAI_LAYER_SCAN()   (scnu::g_bai_layer_scan.fetch_add(1, std::memory_order_relaxed))
   


  #define BAI_WEDGE(k)       (baiDeletion::activeSite=(k), ++scnu::g_bai_wedge_probes, ++scnu::g_bai_site_probes[k])
#else
    inline long long g_bai_ops_alg   = 0;
    inline long long g_bai_ops_touch = 0;
    inline void bai_reset_ops() {}
  #define BAI_OPS_ALG()      ((void)0)
  #define BAI_OPS_TOUCH2()   ((void)0)
  #define BAI_WEDGE(k)       ((void)0)
  #define BAI_CAND()         ((void)0)
  #define BAI_CAND_SEED(k)   ((void)0)
  #define BAI_BAFF()         ((void)0)
  #define BAI_BAFF_EXAM()    ((void)0)
  #define BAI_DEC()          ((void)0)
  #define BAI_DEC_INIT()     ((void)0)
  #define BAI_LAYER()        ((void)0)
  #define BAI_LAYER_SCAN()   ((void)0)
#endif
}
