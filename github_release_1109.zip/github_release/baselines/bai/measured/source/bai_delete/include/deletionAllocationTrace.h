#ifndef DELETION_ALLOCATION_TRACE_H
#define DELETION_ALLOCATION_TRACE_H
#include <cstdlib>
#include <new>
#include <cstddef>
#include <limits>

 
namespace deletionAllocation {
struct alignas(std::max_align_t) Header { size_t bytes; size_t epoch; };
static size_t epoch=0, current=0, peak=0;
static bool enabled=false;
static void begin(size_t resident=0){++epoch;current=peak=resident;enabled=true;}
static void end(){enabled=false;}
static void* allocate(size_t bytes){
    if(bytes>std::numeric_limits<size_t>::max()-sizeof(Header)) throw std::bad_alloc();
    auto p=static_cast<Header*>(std::malloc(sizeof(Header)+bytes));
    if(!p) throw std::bad_alloc();
    p->bytes=bytes;p->epoch=enabled?epoch:0;
    if(enabled){current+=bytes;if(current>peak)peak=current;}
    return p+1;
}
static void release(void* pointer) noexcept {
    if(!pointer) return;
    auto p=static_cast<Header*>(pointer)-1;
    if(enabled&&p->epoch!=0) current-=p->bytes;
    std::free(p);
}
}
void* operator new(size_t bytes){return deletionAllocation::allocate(bytes);}
void* operator new[](size_t bytes){return deletionAllocation::allocate(bytes);}
void operator delete(void* p) noexcept {deletionAllocation::release(p);}
void operator delete[](void* p) noexcept {deletionAllocation::release(p);}
void operator delete(void* p,size_t) noexcept {deletionAllocation::release(p);}
void operator delete[](void* p,size_t) noexcept {deletionAllocation::release(p);}
#endif
