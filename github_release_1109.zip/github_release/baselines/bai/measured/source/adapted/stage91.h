#ifndef STAGE91_H
#define STAGE91_H
#include <array>
#include <chrono>
namespace stage91 {
enum Stage {Shared,Discovery,CandidateSupport,Cascade,Persistent,Stages};
inline const char* names[]={"shared_and_cleanup","discovery_structure_seeds","candidate_and_support","peeling_cascade_phi","persistent_support"};
inline std::array<double,Stages> elapsed{};
inline bool active=false;
inline Stage current=Shared;
inline std::chrono::steady_clock::time_point last;
inline void set(Stage next) {
    if(active) {
        auto now=std::chrono::steady_clock::now();
        elapsed[current]+=std::chrono::duration<double,std::milli>(now-last).count();last=now;
    }
    current=next;
}
struct Scope {Stage previous;Scope(Stage s):previous(current){set(s);}~Scope(){set(previous);}};
inline void begin(){elapsed.fill(0);current=Shared;last=std::chrono::steady_clock::now();active=true;}
inline void end(){set(Shared);active=false;}
}
#endif
