#ifndef WORK91_H
#define WORK91_H
#include <map>
#include <set>
#include <string>
#include <cstdint>
namespace work91 {
struct Record {uint64_t total=0;std::set<std::pair<uint64_t,uint64_t>> keys;};
inline std::map<std::string,Record> records;
inline void reset(){records.clear();}
inline void visit(const char* name,uint64_t object,uint64_t level) {
    auto& record=records[name];++record.total;record.keys.emplace(object,level);
}
}
#define WORK91_VISIT(name,object,level) work91::visit(name,object,level)
#define WORK91_ZERO(name) work91::records.try_emplace(name)
#define WORK91_LIVE(name,object,level) do {if((object)>=0)work91::visit(name,object,level);} while(0)
#endif
