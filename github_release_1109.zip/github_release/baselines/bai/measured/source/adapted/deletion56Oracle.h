#ifndef DELETION56_ORACLE_H
#define DELETION56_ORACLE_H
#include <array>
#include <map>

 
static vector<array<intE,4>> oracle56Butterflies(const Graph& graph) {
    map<pair<intV,intV>,intE> edges;
    for(intE e=0;e<graph.eIdToV.size();++e) {
        auto uv=graph.eIdToV[e]; edges[{min(uv.first,uv.second),max(uv.first,uv.second)}]=e;
    }
    vector<array<intE,4>> result;
    for(intV a=0;a<graph.numT;++a) for(intV c=a+1;c<graph.numT;++c) {
        vector<pair<intE,intE>> common;
        for(intV b=0;b<graph.numT;++b) {
            auto x=edges.find({min(a,b),max(a,b)}), y=edges.find({min(c,b),max(c,b)});
            if(x!=edges.end()&&y!=edges.end()) common.push_back({x->second,y->second});
        }
        for(size_t i=0;i<common.size();++i) for(size_t j=i+1;j<common.size();++j) {
            array<intE,4> butterfly={common[i].first,common[i].second,common[j].first,common[j].second};
            sort(butterfly.begin(),butterfly.end()); result.push_back(butterfly);
        }
    }
    sort(result.begin(),result.end());result.erase(unique(result.begin(),result.end()),result.end());
    return result;
}
static vector<intE> oracle56Phi(const vector<array<intE,4>>& butterflies,const vector<char>& present) {
    vector<intE> phi(present.size(),0);
    for(size_t k=1;k<=butterflies.size();++k) {
        auto live=present; bool changed=true;
        while(changed) {
            changed=false; vector<size_t> support(present.size(),0);
            for(auto b:butterflies) if(live[b[0]]&&live[b[1]]&&live[b[2]]&&live[b[3]])
                for(intE e:b) ++support[e];
            for(intE e=0;e<live.size();++e) if(live[e]&&support[e]<k) {live[e]=0;changed=true;}
        }
        bool any=false;
        for(intE e=0;e<live.size();++e) if(live[e]) {phi[e]=k;any=true;}
        if(!any) break;
    }
    return phi;
}
static vector<intE> oracle56Support(const vector<array<intE,4>>& butterflies,const vector<char>& present) {
    vector<intE> support(present.size(),0);
    for(auto b:butterflies) if(present[b[0]]&&present[b[1]]&&present[b[2]]&&present[b[3]])
        for(intE e:b) ++support[e];
    return support;
}
#endif
