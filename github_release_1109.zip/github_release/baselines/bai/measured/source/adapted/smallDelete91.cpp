#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "state91.h"
#include "deletion56Oracle.h"
#include <filesystem>
#include <fstream>

static void check91(const Delete91& state,const vector<char>& present,
                    const vector<array<intE,4>>& butterflies,bool persistent) {
    const auto phi=oracle56Phi(butterflies,present),es=oracle56Support(butterflies,present);
    for(intE e=0;e<present.size();++e) {
        auto uv=state.graph.eIdToV[e];
        if((findEntity91(state.graph,uv.first,uv.second)==e)!=bool(present[e]))
            throw runtime_error("adjacency identity mismatch");
        if(state.phi[e]!=phi[e]||(present[e]&&state.es[e]!=es[e]))
            throw runtime_error("phi/es oracle mismatch edge="+to_string(e));
    }
    for(intV v=0;v<state.graph.numT;++v) {
        if(state.graph.deg[v]!=state.graph.adj[v].size()||state.graph.eId[v].size()!=state.graph.adj[v].size())
            throw runtime_error("adjacency sizes mismatch");
    }
    if(state.graph.numE!=count(present.begin(),present.end(),1))throw runtime_error("entity count mismatch");
    map<array<intE,4>,int> represented,expected;
    vector<vector<pair<intB,intE>>> members(present.size());
    const auto& index=state.index;
    for(intB b=0;b<index.numV;++b) {
        if(index.bloomDegree[b]!=index.bloomWdgCnt[b])throw runtime_error("bloom degree mismatch");
        vector<pair<intE,intE>> paths;
        for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
            auto p=index.bloomEI[j];
            if(!present[p.first]||!present[p.second])throw runtime_error("dead edge in live path");
            paths.push_back(p);members[p.first].push_back({b,p.second});members[p.second].push_back({b,p.first});
        }
        for(size_t i=0;i<paths.size();++i)for(size_t j=i+1;j<paths.size();++j) {
            array<intE,4> key={paths[i].first,paths[i].second,paths[j].first,paths[j].second};
            sort(key.begin(),key.end());++represented[key];
        }
    }
    for(auto b:butterflies)if(all_of(b.begin(),b.end(),[&](intE e){return present[e];}))++expected[b];
    if(represented!=expected)throw runtime_error("live butterfly index mismatch");
    for(intE e=0;e<present.size();++e) {
        vector<pair<intB,intE>> actual;
        for(intB j=index.edgeVI[e];j<index.edgeVI[e+1];++j)if(index.edgeEI[j].first>=0)actual.push_back(index.edgeEI[j]);
        sort(actual.begin(),actual.end());sort(members[e].begin(),members[e].end());
        if(actual!=members[e])throw runtime_error("membership relation mismatch");
    }
    if(persistent) {
        vector<intB> h(present.size(),0);
        for(auto b:butterflies)if(all_of(b.begin(),b.end(),[&](intE e){return present[e];}))
            for(intE e:b)if(all_of(b.begin(),b.end(),[&](intE x){return phi[x]>=phi[e];}))++h[e];
        if(h!=state.h)throw runtime_error("persistent own-level oracle mismatch");
    }
}

int main(int argc,char** argv) {
    size_t graphID=0,eventID=0,checks=0,independent=0,sequence=0;
    string algorithm;
    try {
        if(argc!=2)throw runtime_error("output folder required");
        filesystem::path folder=argv[1];if(!filesystem::create_directory(folder))throw runtime_error("output exists");
        mt19937 random(910181);
        for(graphID=0;graphID<1112;++graphID) {
            const int side=graphID<512?3:graphID<812?4:5;
            Insertion60Base base;auto& graph=base.graph;graph=Graph(side,side,0);
            for(int u=0;u<side;++u)for(int v=0;v<side;++v) {
                const bool take=graphID<512?bool(graphID&(1u<<(u*side+v))):random()%100<10+(graphID%18)*5;
                if(take) {graph.adj[u].push_back(side+v);graph.adj[side+v].push_back(u);++graph.deg[u];++graph.deg[side+v];++graph.numE;}
            }
            if(!graph.numE)continue;
            vector<intV> order,inverse;graph.sort_deg(order);invertMap(order,inverse);graph.reorder_in_place(inverse);
            vector<intE> phi,es;arrayBuildBase(graph,base.index,es,phi);
            vector<intB> h;buildPersistentSupport(base.index,phi,h);
            auto butterflies=oracle56Butterflies(graph);
            for(const string variant:{"PB","SL","AF"}) {
                algorithm=variant;
                for(eventID=0;eventID<phi.size();++eventID) {
                    Delete91 state(base,phi,es,variant=="AF"?h:vector<intB>{});
                    vector<char> present(phi.size(),1);present[eventID]=0;
                    state.remove(eventID,variant);check91(state,present,butterflies,variant=="AF");++checks;++independent;
                }
                Delete91 state(base,phi,es,variant=="AF"?h:vector<intB>{});
                vector<char> present(phi.size(),1);vector<intE> permutation(phi.size());iota(permutation.begin(),permutation.end(),0);
                shuffle(permutation.begin(),permutation.end(),random);
                for(eventID=0;eventID<permutation.size();++eventID) {
                    auto edge=permutation[eventID];present[edge]=0;
                    state.remove(edge,variant);check91(state,present,butterflies,variant=="AF");++checks;++sequence;
                }
            }
        }
        ofstream summary(folder/"summary.json");
        summary<<"{\"graphs\":1112,\"checks\":"<<checks<<",\"independent\":"<<independent<<",\"sequence\":"<<sequence
               <<",\"seed\":910181,\"failures\":0,\"algorithms\":[\"PB_D\",\"SL_D\",\"AF_D\"]}\n";
        cout<<"DELETE_VERIFY_PASS checks="<<checks<<endl;
    }catch(const exception& e) {cerr<<"DELETE_VERIFY_FAIL graph="<<graphID<<" event="<<eventID<<" algorithm="<<algorithm<<" "<<e.what()<<endl;return 1;}
}
