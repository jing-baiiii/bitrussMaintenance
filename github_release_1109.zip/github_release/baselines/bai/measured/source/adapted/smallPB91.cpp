#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "arrayInsertionLayer60.h"
#include "arrayInsertionPB91.h"
#include "deletion56Oracle.h"
#include "arrayBMI_pp.h"
#include <filesystem>
#include <fstream>

static void oneThread() {
    size_t n=0;for(auto& p:filesystem::directory_iterator("/proc/self/task")){(void)p;++n;}
    if(n!=1)throw runtime_error("actual thread count not one");
}
static pair<intV,intV> keyOf(pair<intV,intV> p) {return {min(p.first,p.second),max(p.first,p.second)};}
static pair<intE,intE> pathOf(pair<intE,intE> p) {return {min(p.first,p.second),max(p.first,p.second)};}

struct Truth60 {
    vector<intE> phi;
    vector<uint64_t> es;
    vector<array<intE,4>> butterflies;
};
static Truth60 truth(const PB91State& state) {
    Graph entities(0,state.base->graph.numT,0);entities.numE=state.edges();
    for(intE e=0;e<state.edges();++e)entities.eIdToV.push_back(state.endpoints(e));
    auto butterflies=oracle56Butterflies(entities);vector<char> present(state.edges(),1);
    auto supports=oracle56Support(butterflies,present);
    return {oracle56Phi(butterflies,present),vector<uint64_t>(supports.begin(),supports.end()),std::move(butterflies)};
}
static void indexTruth(const PB91State& state,const Truth60& gold) {
    using Paths=set<pair<intE,intE>>;
    map<pair<intV,intV>,Paths> expected,actual;
    for(auto b:gold.butterflies) {
        set<intV> vertices;for(intE e:b) {auto uv=state.endpoints(e);vertices.insert(uv.first);vertices.insert(uv.second);}
        intV minimum=*vertices.begin(),opposite=minimum;
        for(intV v:vertices)if(v!=minimum&&state.base->left[v]==state.base->left[minimum])opposite=v;
        if(opposite==minimum)throw runtime_error("oracle butterfly partitions invalid");
        auto key=keyOf({minimum,opposite});
        for(intV v:vertices)if(state.base->left[v]!=state.base->left[minimum]) {
            vector<intE> edges;
            for(intE e:b) {auto uv=state.endpoints(e);if(uv.first==v||uv.second==v)edges.push_back(e);}
            if(edges.size()!=2)throw runtime_error("oracle wedge edges invalid");
            expected[key].insert(pathOf({edges[0],edges[1]}));
        }
    }
    vector<vector<PB91State::Membership>> expectedMembers(state.edges());
    map<array<intE,4>,int> represented;
    for(intB b=0;b<state.blooms();++b) {
        auto key=keyOf(state.master(b));
        if(actual.count(key))throw runtime_error("duplicate master mapping");
        vector<pair<intE,intE>> paths;
        state.wedges(b,[&](auto p) {
            if(p.first>=state.edges()||p.second>=state.edges()||p.first==p.second)throw runtime_error("wedge invalid edge ids");
            if(!actual[key].insert(pathOf(p)).second)throw runtime_error("duplicate persistent wedge");
            paths.push_back(p);
            expectedMembers[p.first].push_back({b,p.second});expectedMembers[p.second].push_back({b,p.first});
        });
        if(paths.size()<2)throw runtime_error("persistent bloom below two paths");
        for(size_t i=0;i<paths.size();++i)for(size_t j=i+1;j<paths.size();++j) {
            array<intE,4> butterfly={paths[i].first,paths[i].second,paths[j].first,paths[j].second};
            sort(butterfly.begin(),butterfly.end());++represented[butterfly];
        }
    }
    if(actual!=expected)throw runtime_error("persistent master/wedge oracle mismatch");
    if(represented.size()!=gold.butterflies.size())throw runtime_error("represented butterfly count mismatch");
    for(auto b:gold.butterflies)if(represented[b]!=1)throw runtime_error("butterfly represented nonuniquely");
    for(intE e=0;e<state.edges();++e) {
        vector<PB91State::Membership> actualMembers;
        state.memberships(e,[&](auto entry){actualMembers.push_back(entry);});
        sort(actualMembers.begin(),actualMembers.end());sort(expectedMembers[e].begin(),expectedMembers[e].end());
        if(actualMembers!=expectedMembers[e])throw runtime_error("persistent edge membership mismatch");
        auto uv=state.endpoints(e);
        if(state.findEdge(uv.first,uv.second)!=e||state.findEdge(uv.second,uv.first)!=e)throw runtime_error("persistent adjacency/id mismatch");
    }
    for(intV v=0;v<state.base->graph.numT;++v) {
        map<intV,intE> list;
        state.neighbors(v,[&](intV w,intE e){if(!list.emplace(w,e).second)throw runtime_error("duplicate adjacency");});
        size_t expectedDegree=0;
        for(intE e=0;e<state.edges();++e) {
            auto uv=state.endpoints(e);if(uv.first==v||uv.second==v)++expectedDegree;
        }
        if(expectedDegree!=list.size())throw runtime_error("persistent adjacency degree mismatch");
    }
    const auto& work=state.workspace;
    if(!work.touched.empty()||!work.seenTouched.empty())throw runtime_error("workspace touched not cleared");
    for(size_t e=0;e<work.candidate.size();++e)
        if(work.candidate[e]||work.retired[e]||work.inBatch[e]||work.seenEvent[e]||work.support[e])throw runtime_error("workspace state not cleared");
}

struct Built60 {PB91State state;vector<pair<intV,intV>> missing;};
static Built60 build(int left,int right,const vector<char>& included) {
    auto base=make_shared<Insertion60Base>();Graph& g=base->graph;g=Graph(right,left,0);
    for(int u=0;u<left;++u)for(int v=0;v<right;++v)if(included[u*right+v]) {
        g.adj[u].push_back(left+v);g.adj[left+v].push_back(u);++g.deg[u];++g.deg[left+v];++g.numE;
    }
    vector<intV> order,inverse;g.sort_deg(order);invertMap(order,inverse);g.reorder_in_place(inverse);
    base->left.resize(g.numT);for(intV v=0;v<g.numT;++v)base->left[v]=order[v]<(intV)left;
    vector<intE> phi,support;
    if(g.numE)arrayBuildBase(g,base->index,support,phi);
    else {
        g.eId.resize(g.numT);base->index.numU=0;base->index.numV=0;base->index.numE=0;
        base->index.edgeVI={0};base->index.bloomVI={0};
    }
    vector<pair<intV,intV>> missing;
    for(int u=0;u<left;++u)for(int v=0;v<right;++v)if(!included[u*right+v])missing.push_back({inverse[u],inverse[left+v]});
    return {PB91State(base,phi,vector<uint64_t>(support.begin(),support.end())),missing};
}

int main(int argc,char**argv) {
    string context;
    try {
        if(argc<2||argc>3)throw runtime_error("output folder required");
        filesystem::path folder=argv[1];if(!filesystem::create_directory(folder))throw runtime_error("output exists");
        ofstream rows(folder/"events.tsv"),witness(folder/"witnesses.jsonl");
        rows<<"test\tfamily\tphase\tevent\tinserted\tnew_butterflies\tcandidates\tpeel_pairs\tphi_inc_including_new\tphi_inc_excluding_new\tmax_old_edge_jump\tnew_blooms\tnew_wedges\twork_writes\tlogical_decrement\n";
        mt19937 rng(6001302);size_t graphs=0,single=0,sequence=0;
        uint64_t maxJump=0;bool multiLayerWitness=false,multiBloomWitness=false,batchWitness=false;
        struct Spec {int u,v,density;unsigned mask;string family;};
        vector<Spec> specs;
        for(unsigned mask=0;mask<512;++mask)specs.push_back({3,3,-1,mask,"exhaustive3"});
        for(int side:{4,5})for(int i=0;i<300;++i)specs.push_back({side,side,10+(i%18)*5,0,"random"+to_string(side)});
        for(int m=2;m<=16;++m) {
            specs.push_back({2,m,-2,0,"K2m_minus_edge"});specs.push_back({m,2,-2,0,"Km2_minus_edge"});
        }
        for(auto uv:vector<pair<int,int>>{{3,7},{7,3},{4,6},{6,4},{6,6},{8,8}})specs.push_back({uv.first,uv.second,90,0,"dense"});
        for(int i=0;i<60;++i)specs.push_back({6,7,20+(i%14)*5,0,"random6x7"});
        oneThread();
        for(size_t test=0;test<specs.size();++test) {
            auto spec=specs[test];vector<char> included(spec.u*spec.v,0);
            for(size_t i=0;i<included.size();++i)included[i]=spec.density==-1?bool(spec.mask&(1u<<i)):
                spec.density==-2?i!=0:rng()%100<(unsigned)spec.density;
            auto built=build(spec.u,spec.v,included);++graphs;
            auto initialGold=truth(built.state);
            if(built.state.phi!=initialGold.phi||built.state.es!=initialGold.es)throw runtime_error("initial state mismatch");
            indexTruth(built.state,initialGold);
            auto event=[&](PB91State& state,pair<intV,intV> uv,const string& phase,size_t id) {
                context="test="+to_string(test)+" family="+spec.family+" phase="+phase+" event="+to_string(id);
                auto before=state.phi;PB91Metrics metrics;
                auto oldTruth=truth(state);intE inserted=state.insert(uv.first,uv.second,&metrics);
                auto gold=truth(state);oneThread();
                
                Graph original=state.base->graph;
                if(phase=="sequence") {
                    original=Graph(0,state.base->graph.numT,0);
                    for(intE e=0;e<before.size();++e) {
                        auto xy=state.endpoints(e);original.adj[xy.first].push_back(xy.second);original.adj[xy.second].push_back(xy.first);
                        ++original.deg[xy.first];++original.deg[xy.second];++original.numE;
                    }
                    for(auto& row:original.adj)sort(row.begin(),row.end());
                }
                BEGraphLoMem ix;vector<intE> total,levels;
                if(phase=="single") {ix=state.base->index;levels=before;for(auto s:built.state.es)total.push_back(s);}
                else arrayBuildBase(original,ix,total,levels);
                unordered_map<pair<intV,intV>,intB,pair_hash> masters;abi_buildMasterToBloom(ix,masters);
                auto originalEndpoints=original.eIdToV;
                insertEdgeIntoG(original,uv.first,uv.second);original.eIdToV.push_back(uv);originalEndpoints.push_back(uv);
                vector<intB> vi;vector<intV> nbr;vector<intE> ids;buildVertexAdj(original,vi,nbr,ids);
                levels.push_back(0);total.push_back(0);
                auto got=arrayBMI_pp(ix,levels,total,vi,nbr,ids,originalEndpoints,masters,original,uv.first,uv.second,levels.size()-1,nullptr,false);
                bool originalCorrect=true,adapterAgrees=true;
                for(intE e=0;e<got.size();++e) {
                    auto xy=originalEndpoints[e];auto mapped=state.findEdge(xy.first,xy.second);
                    originalCorrect &= got[e]==gold.phi[mapped]&&total[e]==gold.es[mapped];
                    adapterAgrees &= got[e]==state.phi[mapped]&&total[e]==state.es[mapped];
                }
                if(!adapterAgrees||!originalCorrect||state.phi!=gold.phi||state.es!=gold.es) {
                    ofstream fail(folder/"failure.json");
                    fail<<"{\"context\":\""<<context<<"\",\"original_correct\":"<<(originalCorrect?"true":"false")
                        <<",\"adapter_agrees_original\":"<<(adapterAgrees?"true":"false")<<",\"insert\":["<<uv.first<<','<<uv.second<<"],\"before_edges\":[";
                    for(intE e=0;e<before.size();++e){auto xy=state.endpoints(e);if(e)fail<<',';fail<<'['<<xy.first<<','<<xy.second<<','<<before[e]<<']';}fail<<"]}\n";
                    throw runtime_error("legacy/original independent oracle mismatch");
                }
                indexTruth(state,gold);
                uint64_t delta=0,jump=0;
                for(intE e=0;e<before.size();++e) {
                    if(state.phi[e]<before[e])throw runtime_error("insertion decreased phi");
                    delta+=state.phi[e]-before[e];jump=max(jump,(uint64_t)(state.phi[e]-before[e]));
                }
                uint64_t lost=gold.butterflies.size()-oldTruth.butterflies.size();
#ifdef INSERT60_COUNT
                if(metrics.phiWritesExcludingNew!=delta||metrics.phiWritesIncludingNew!=delta+state.phi[inserted]
                    ||metrics.initialButterflies!=lost||metrics.totalSupportWrites!=4*lost)
                    throw runtime_error("legacy counters mismatch");
#endif
                auto save=[&](const string& kind) {
                    witness<<"{\"kind\":\""<<kind<<"\",\"test\":"<<test<<",\"family\":\""<<spec.family
                        <<"\",\"phase\":\""<<phase<<"\",\"event\":"<<id<<",\"inserted\":"<<inserted
                        <<",\"u\":"<<uv.first<<",\"v\":"<<uv.second<<",\"max_old_jump\":"<<jump<<",\"edges\":[";
                    for(intE e=0;e<state.edges();++e) {
                        auto xy=state.endpoints(e);if(e)witness<<',';
                        witness<<'['<<xy.first<<','<<xy.second<<','<<(e<before.size()?before[e]:0)<<','<<state.phi[e]<<']';
                    }
                    witness<<"]}\n";
                };
                if(jump>maxJump){maxJump=jump;save("largest_old_jump");}
                if(!multiLayerWitness&&jump>1){multiLayerWitness=true;save("old_edge_multi_layer");}

                rows<<test<<'\t'<<spec.family<<'\t'<<phase<<'\t'<<id<<'\t'<<inserted<<'\t'<<lost<<'\t'
                    <<metrics.candidates<<'\t'<<metrics.peelWedges<<'\t'<<delta+state.phi[inserted]<<'\t'<<delta<<'\t'<<jump
                    <<'\t'<<metrics.newBlooms<<'\t'<<metrics.newWedges<<'\t'<<0<<'\t'<<0<<'\n';
                const auto snapshotPhi=state.phi;const auto snapshotEs=state.es;size_t oldEdges=state.edges();
                bool refused=false;
                try {state.insert(uv.first,uv.second);}catch(const runtime_error&){refused=true;}
                if(!refused||state.phi!=snapshotPhi||state.es!=snapshotEs||state.edges()!=oldEdges)throw runtime_error("duplicate insertion not rejected unchanged");
            };
            for(size_t i=0;i<built.missing.size();++i) {
                auto state=built.state;event(state,built.missing[i],"single",i);++single;
            }
            shuffle(built.missing.begin(),built.missing.end(),rng);
            if(argc<3)continue;
            auto state=built.state;
            for(size_t i=0;i<built.missing.size();++i){event(state,built.missing[i],"sequence",i);++sequence;}
        }
        if(!multiLayerWitness)throw runtime_error("missing old multi-layer witness");

        if(!rows||!witness)throw runtime_error("output failure");
        ofstream summary(folder/"summary.json");
        summary<<"{\"graphs\":"<<graphs<<",\"single_events\":"<<single<<",\"sequence_events\":"<<sequence
            <<",\"full_phi_es_index_checks\":"<<single+sequence<<",\"max_old_layer_jump\":"<<maxJump
            <<",\"old_multi_layer_witness\":true,\"actual_threads\":1,\"failures\":0,\"seed\":6001302}\n";
        cout<<"INSERT_VERIFY_PASS graphs="<<graphs<<" single="<<single<<" sequence="<<sequence<<" max_old_jump="<<maxJump<<" actual_threads=1\n";
    }catch(const exception& e){cerr<<"INSERT_VERIFY_FAIL "<<context<<' '<<e.what()<<'\n';return 1;}
}
