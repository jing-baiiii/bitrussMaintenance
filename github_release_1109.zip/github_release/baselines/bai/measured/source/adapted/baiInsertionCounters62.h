#ifndef BAI_INSERTION_COUNTERS62_H
#define BAI_INSERTION_COUNTERS62_H
#include <cstdint>
#include <unordered_set>
#include <array>
#include <stdexcept>
namespace baiInsertion62 {
enum Site { Initial, Candidate, CascadeCandidate, CascadePartial, UpdateWS, Partial, Other, Sites };
struct Counters {
    uint64_t layers=0,batches=0,candidateTests=0,candidates=0,peeled=0;
    uint64_t phiWrites=0,phiLogicalInc=0,phiLogicalIncExcludingNew=0;
    std::array<uint64_t,Sites> first{},second{},confirmed{},supportWrites{},supportInc{},supportDec{},supportAssignments{};
    std::unordered_set<const void*> tested,candidateUnique,peeledUnique;
};
inline Counters values;
inline Site site=Other;
inline const void* inserted=nullptr;
struct Scope {Site previous;Scope(Site s):previous(site){site=s;}~Scope(){site=previous;}};
inline void reset(const void* edge){values=Counters();site=Other;inserted=edge;}
inline void phi(const void* e,uint32_t before,uint32_t after) {
    ++values.phiWrites;
    if(after<before)throw std::runtime_error("Bai insertion phi decreased");
    values.phiLogicalInc+=after-before;
    if(e!=inserted)values.phiLogicalIncExcludingNew+=after-before;
}
}
#ifdef PI62_COUNT
#define PI62_SCOPE(s) baiInsertion62::Scope pi62Scope(baiInsertion62::s)
#define PI62_LAYER() (++baiInsertion62::values.layers)
#define PI62_BATCH() (++baiInsertion62::values.batches)
#define PI62_TEST(e) do{++baiInsertion62::values.candidateTests;baiInsertion62::values.tested.insert((e).get());}while(0)
#define PI62_CAND(e) do{++baiInsertion62::values.candidates;baiInsertion62::values.candidateUnique.insert((e).get());}while(0)
#define PI62_PEEL(e) do{++baiInsertion62::values.peeled;baiInsertion62::values.peeledUnique.insert((e).get());}while(0)
#define PI62_FIRST() (++baiInsertion62::values.first[baiInsertion62::site])
#define PI62_SECOND() (++baiInsertion62::values.second[baiInsertion62::site])
#define PI62_CONFIRMED() (++baiInsertion62::values.confirmed[baiInsertion62::site])
#define PI62_PHI(e,b,a) baiInsertion62::phi((e).get(),b,a)
#define PI62_INC() do{++baiInsertion62::values.supportWrites[baiInsertion62::site];++baiInsertion62::values.supportInc[baiInsertion62::site];}while(0)
#define PI62_DEC() do{++baiInsertion62::values.supportWrites[baiInsertion62::site];++baiInsertion62::values.supportDec[baiInsertion62::site];}while(0)
#define PI62_ASSIGN() do{++baiInsertion62::values.supportWrites[baiInsertion62::site];++baiInsertion62::values.supportAssignments[baiInsertion62::site];}while(0)
#else
#define PI62_SCOPE(s) do{}while(0)
#define PI62_LAYER() do{}while(0)
#define PI62_BATCH() do{}while(0)
#define PI62_TEST(e) do{}while(0)
#define PI62_CAND(e) do{}while(0)
#define PI62_PEEL(e) do{}while(0)
#define PI62_FIRST() do{}while(0)
#define PI62_SECOND() do{}while(0)
#define PI62_CONFIRMED() do{}while(0)
#define PI62_PHI(e,b,a) do{}while(0)
#define PI62_INC() do{}while(0)
#define PI62_DEC() do{}while(0)
#define PI62_ASSIGN() do{}while(0)
#endif
#endif
