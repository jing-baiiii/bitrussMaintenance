#ifndef ARRAY_INSERTION_PB91_H
#define ARRAY_INSERTION_PB91_H
#include "insertionAllocation62.h"
#include "arrayBMI.h"
#include <functional>
struct PB91Metrics {
    uint64_t firstHop=0;
    uint64_t secondHop=0;
    uint64_t edgeLookups=0;
    uint64_t initialButterflies=0;
    uint64_t structuralWedges=0;
    uint64_t supportWedges=0;
    uint64_t propagationWedges=0;
    uint64_t peelWedges=0;
    uint64_t preexpandWedges=0;
    uint64_t compensationWedges=0;
    uint64_t memberships=0;
    uint64_t candidates=0;
    uint64_t newBlooms=0;
    uint64_t newWedges=0;
    uint64_t totalSupportWrites=0;
    uint64_t phiWritesIncludingNew=0;
    uint64_t phiWritesExcludingNew=0;
};
#ifdef INSERT60_COUNT
#define PB91_COUNT(field,n) do {if(metrics)metrics->field+=(n);}while(0)
#else
#define PB91_COUNT(field,n) do {}while(0)
#endif
class PB91State: public Insertion60State {
public:
    shared_ptr<const unordered_map<pair<intV,intV>,intB,pair_hash>> masterToBloom;
    PB91State(shared_ptr<const Insertion60Base> b,vector<intE> p,vector<uint64_t> s)
        :Insertion60State(b,std::move(p),std::move(s)) {
        PI62_MEMORY_BLOCK(Index,
            auto m=make_shared<unordered_map<pair<intV,intV>,intB,pair_hash>>();
            abi_buildMasterToBloom(b->index,*m);masterToBloom=m);
    }
    intE insert(intV u1,intV v1,PB91Metrics* metrics=nullptr) {

    auto& bitr=phi;
    const auto& BEG=base->index;
    const bool useSupportPruning=false;
    const intE n=BEG.numU;
    if(u1>=base->graph.numT||v1>=base->graph.numT||base->left[u1]==base->left[v1]||findEdge(u1,v1)!=noEdge)
        throw runtime_error("invalid legacy insertion");
    const intE eid=edges();
    PI62_MEMORY_BLOCK(Output,phi.push_back(0);es.push_back(0));
    PI62_MEMORY_BLOCK(Graph,
        addedEdges.push_back({u1,v1});
        for(auto uv:{make_pair(u1,v1),make_pair(v1,u1)}) {
            auto& row=addedAdj[uv.first];
            auto it=lower_bound(row.begin(),row.end(),uv.second,[](auto a,intV b){return a.first<b;});
            row.insert(it,{uv.second,eid});
        });

    auto E2=[&](intV a,intV b)->intE{ PB91_COUNT(edgeLookups,1);return findEdge(a,b); };
    auto BWDG=[&](intB b)->intE{
        auto it=addedWedges.find(b);
        return (b<BEG.numV?BEG.bloomWdgCnt[b]:0)+(it==addedWedges.end()?0:it->second.size());
    };
    auto lookupMaster=[&](pair<intV,intV> key)->intB {
        auto fresh=addedMaster.find(key);if(fresh!=addedMaster.end())return fresh->second;
        auto it=masterToBloom->find(key);return it==masterToBloom->end()?-1:it->second;
    };
    int site=0;
    auto forEachWedge=[&](intB b,const std::function<void(intE,intE)>& fn) {
        wedges(b,[&](Wedge w) {
            if(site==0){PB91_COUNT(structuralWedges,1);}
            else if(site==1){PB91_COUNT(supportWedges,1);}
            else if(site==2){PB91_COUNT(propagationWedges,1);}
            else {PB91_COUNT(peelWedges,1);}
            fn(w.first,w.second);
        });
    };
    auto forEachMemb=[&](intE e,const std::function<void(intB,intE)>& fn) {
        memberships(e,[&](Membership m){PB91_COUNT(memberships,1);fn(m.first,m.second);});
    };
    auto addWedge=[&](intB b,intV wv) {
        auto mp=master(b);intE e1=E2(wv,mp.first),e2=E2(wv,mp.second);
        if(e1==noEdge||e2==noEdge)throw runtime_error("legacy missing wedge edge");
        PI62_MEMORY_BLOCK(Index,
            addedWedges[b].push_back({e1,e2});
            addedMemberships[e1].push_back({b,e2});addedMemberships[e2].push_back({b,e1}));
        PB91_COUNT(newWedges,1);
    };
    auto adjacent=[&](intV v,vector<intV>& scratch)->const vector<intV>& {
        if(!addedAdj.count(v))return base->graph.adj[v];
        neighbors(v,[&](intV w,intE){scratch.push_back(w);});sort(scratch.begin(),scratch.end());return scratch;
    };

     
    auto supOK=[&](intE x, intB BLevel)->bool{ return !useSupportPruning || (intB)es[x]>BLevel; };

     
    vector<intV> uScratch;const auto& u1N=adjacent(u1,uScratch);
    vector<intV> vScratch;const auto& v1N=adjacent(v1,vScratch);
    OPS_ALG_N(v1N.size());    
    unordered_set<intV> v1set(v1N.begin(), v1N.end());
    unordered_set<pair<intV,intV>,pair_hash> isProc;
    vector<pair<intV,intV>> bloomPairs;
    unordered_map<pair<intV,intV>,intV,pair_hash> newBloomWedge;
    bool found=false;
    for(intV v: u1N){ PB91_COUNT(firstHop,1);
        OPS_ALG();    
        if(v==v1) continue;
        vector<intV> scratch;const auto& vN=adjacent(v,scratch);
        for(intV u: vN){ PB91_COUNT(secondHop,1);
            OPS_ALG();    
            if(u==u1) continue;
            if(!v1set.count(u)) continue;
            found=true;PB91_COUNT(initialButterflies,1);
            intV mn=min(min(u,v),min(u1,v1));
            pair<intV,intV> mp;
            if(mn==u||mn==u1) mp=make_pair(min(u,u1),max(u,u1));
            else              mp=make_pair(min(v,v1),max(v,v1));
            if(isProc.count(mp)) continue;
            isProc.insert(mp);
            bloomPairs.push_back(mp);
            intB existing=lookupMaster(mp);
            bool empty=existing<0||BWDG(existing)==0;
            if(empty) newBloomWedge[mp] = (mn==u||mn==u1)? v : u;
        }
    }
    v1set.clear(); isProc.clear();

    if(!found){
        return eid;
    }

    for(auto&mp: bloomPairs){
        OPS_ALG();
        intB existing=lookupMaster(mp);
        intE wc=existing>=0?BWDG(existing):0;
        
    }

     
    const intE N = edges();
    OPS_ALLOC_N(7LL*N);    
    vector<intE> Q(N);
    vector<char> visited(N,0), hasBeenProcessed(N,0), isUpdated(N,0), onTouched(N,0);
    vector<intB> se(N,0);
    vector<intE> seToUpdate(N);
    vector<intE> touched; touched.reserve(256);
    auto touch=[&](intE e){ if(!onTouched[e]){ onTouched[e]=1; touched.push_back(e); } };

    for(auto& mp : bloomPairs){
        OPS_ALG();
        intV uid=mp.first, wid=mp.second;
        intB bloomId;
        bloomId=lookupMaster(mp);
        if(bloomId<0) {
            bloomId=blooms();
            PI62_MEMORY_BLOCK(Index,addedBlooms.push_back({mp});addedMaster.emplace(mp,bloomId));
            PB91_COUNT(newBlooms,1);
        }
        site=0;

        intV spokeNew = (u1==uid||u1==wid)? v1 : u1;

        if(BWDG(bloomId)==0){
            auto nbw=newBloomWedge.find(mp);
            if(nbw!=newBloomWedge.end()) addWedge(bloomId, nbw->second);
        }

        vector<intV> wedgeVers;
        forEachWedge(bloomId, [&](intE we1,intE we2){
            intV wv=abi_findWdgVer(endpoints(we1), endpoints(we2));
            if(wv!=ABI_NOV) wedgeVers.push_back(wv);
        });

        vector<intV> addedB; addedB.reserve(wedgeVers.size()+1);
        intE thirdEdge = E2(spokeNew, uid);
        intE fourthEdge= E2(spokeNew, wid);

        for(intV vid : wedgeVers){
            OPS_ALG();    
            addedB.push_back(vid);
            intV curAddedIdx = (intV)addedB.size();
            intE firstEdge = E2(vid, uid);
            intE secondEdge= E2(vid, wid);
            if(firstEdge==ABI_NOE||secondEdge==ABI_NOE||thirdEdge==ABI_NOE||fourthEdge==ABI_NOE) continue;

            es[firstEdge]++; es[secondEdge]++; es[thirdEdge]++; es[fourthEdge]++;PB91_COUNT(totalSupportWrites,4);

            intB BLevel = min(min(bitr[firstEdge],bitr[secondEdge]),min(bitr[thirdEdge],bitr[fourthEdge]));

            intV start_idx=0,end_idx=0;
             
            if(bitr[firstEdge]==BLevel){ touch(firstEdge); Q[end_idx++]=firstEdge; visited[firstEdge]=1; se[firstEdge]++; }
            if(bitr[secondEdge]==BLevel){ touch(secondEdge); Q[end_idx++]=secondEdge; visited[secondEdge]=1; se[secondEdge]++; }
            if(bitr[thirdEdge]==BLevel){ touch(thirdEdge); Q[end_idx++]=thirdEdge; visited[thirdEdge]=1; se[thirdEdge]++; }
            if(bitr[fourthEdge]==BLevel){ touch(fourthEdge); Q[end_idx++]=fourthEdge; visited[fourthEdge]=1; se[fourthEdge]++; }

             
            for(intV j=0;j<curAddedIdx-1;j++){ PB91_COUNT(preexpandWedges,1);
                OPS_ALG();    
                intV w=addedB[j];
                intE e1=E2(w,uid), e2=E2(w,wid);
                if(e1==ABI_NOE||e2==ABI_NOE) continue;
                if(bitr[e1]>=BLevel && bitr[e2]>=BLevel && supOK(e1,BLevel) && supOK(e2,BLevel)){
                    if(bitr[e1]==BLevel){ if(!visited[e1]){ touch(e1); Q[end_idx++]=e1; visited[e1]=1; } touch(e1); se[e1]++; }
                    if(bitr[e2]==BLevel){ if(!visited[e2]){ touch(e2); Q[end_idx++]=e2; visited[e2]=1; } touch(e2); se[e2]++; }
                    if(bitr[thirdEdge]==BLevel){ se[thirdEdge]++; }
                    if(bitr[fourthEdge]==BLevel){ se[fourthEdge]++; }
                }
            }

            ThresholdFilteredEdgeHeap_vec edgeHeap;
             
            auto propagate=[&](intE e){ site=2;
                forEachMemb(e, [&](intB bID, intE etwin){
                    if(BWDG(bID)<2) return;
                    if(bitr[etwin]<BLevel || !supOK(etwin,BLevel)) return;    
                    forEachWedge(bID, [&](intE ce1,intE ce2){
                            
                        if(e==ce1||e==ce2) return;
                        if(bitr[ce1]<BLevel||bitr[ce2]<BLevel||!supOK(ce1,BLevel)||!supOK(ce2,BLevel)) return;   
                        if(!visited[ce1]&&bitr[ce1]==BLevel){ touch(ce1); Q[end_idx++]=ce1; visited[ce1]=1; }
                        if(!visited[ce2]&&bitr[ce2]==BLevel){ touch(ce2); Q[end_idx++]=ce2; visited[ce2]=1; }
                        if(!visited[etwin]&&bitr[etwin]==BLevel){ touch(etwin); Q[end_idx++]=etwin; visited[etwin]=1; }
                    });
                });
            };
             
            while(start_idx<end_idx){
                OPS_ALG();    
                intE e=Q[start_idx++];site=1;PB91_COUNT(candidates,1);
                forEachMemb(e, [&](intB bID, intE etwin){
                    
                    if(BWDG(bID)<2) return;
                    if(bitr[etwin]<BLevel || !supOK(etwin,BLevel)) return;    
                    forEachWedge(bID, [&](intE ce1,intE ce2){
                            
                        if(e==ce1||e==ce2) return;
                        if(bitr[ce1]<BLevel||bitr[ce2]<BLevel||!supOK(ce1,BLevel)||!supOK(ce2,BLevel)) return;   
                        touch(e); se[e]++;
                    });
                });
                
                edgeHeap.addEdge(e, se[e]);
                if((intB)se[e] > BLevel) propagate(e);    
            }
            

             
            while(edgeHeap.hasEdgesLessOrEqual(BLevel)){
                OPS_ALG();    
                vector<intE> edgesToProcess = edgeHeap.removeAllEdgesLessOrEqual(BLevel);
                intE seToUpdateIdx=0;
                for(intE e : edgesToProcess){ site=3;
                    OPS_ALG();    
                    forEachMemb(e, [&](intB bID, intE etwin){
                        if(BWDG(bID)<2) return;
                        if(bitr[etwin]<BLevel || !supOK(etwin,BLevel) || hasBeenProcessed[etwin]) return;    
                        forEachWedge(bID, [&](intE ce1,intE ce2){
                                
                            if(e==ce1||e==ce2) return;
                            if(bitr[ce1]<BLevel||bitr[ce2]<BLevel||!supOK(ce1,BLevel)||!supOK(ce2,BLevel)) return;   
                            if(hasBeenProcessed[ce1]||hasBeenProcessed[ce2]) return;
                            if(edgeHeap.contains(ce1)){ touch(ce1); se[ce1]--; if(!isUpdated[ce1]){seToUpdate[seToUpdateIdx++]=ce1; isUpdated[ce1]=1;} }
                            if(edgeHeap.contains(ce2)){ touch(ce2); se[ce2]--; if(!isUpdated[ce2]){seToUpdate[seToUpdateIdx++]=ce2; isUpdated[ce2]=1;} }
                            if(edgeHeap.contains(etwin)){ touch(etwin); se[etwin]--; if(!isUpdated[etwin]){seToUpdate[seToUpdateIdx++]=etwin; isUpdated[etwin]=1;} }
                        });
                    });
                    if((e==thirdEdge && bitr[fourthEdge]>=BLevel && !hasBeenProcessed[fourthEdge]) ||
                       (e==fourthEdge && bitr[thirdEdge]>=BLevel && !hasBeenProcessed[thirdEdge])){
                        for(intV j=0;j<(intV)addedB.size();j++){ PB91_COUNT(compensationWedges,1);
                            OPS_ALG();    
                            intV w=addedB[j]; intE e1=E2(w,uid), e2=E2(w,wid);
                            if(e1==ABI_NOE||e2==ABI_NOE) continue;
                            if(bitr[e1]>=BLevel && bitr[e2]>=BLevel && !hasBeenProcessed[e1] && !hasBeenProcessed[e2]){
                                intE other = (e==thirdEdge)? fourthEdge : thirdEdge;
                                if(edgeHeap.contains(other)){ touch(other); se[other]--; if(!isUpdated[other]){seToUpdate[seToUpdateIdx++]=other; isUpdated[other]=1;} }
                                if(edgeHeap.contains(e1)){ touch(e1); se[e1]--; if(!isUpdated[e1]){seToUpdate[seToUpdateIdx++]=e1; isUpdated[e1]=1;} }
                                if(edgeHeap.contains(e2)){ touch(e2); se[e2]--; if(!isUpdated[e2]){seToUpdate[seToUpdateIdx++]=e2; isUpdated[e2]=1;} }
                            }
                        }
                    }
                    for(intV j=0;j<(intV)addedB.size();j++){ PB91_COUNT(compensationWedges,1);
                        OPS_ALG();    
                        intV w=addedB[j]; intE e1=E2(w,uid), e2=E2(w,wid);
                        if(e1==ABI_NOE||e2==ABI_NOE) continue;
                        if(e!=e1 && e!=e2) continue;
                        if(e==e1 && bitr[e2]>=BLevel && !hasBeenProcessed[e2] && !hasBeenProcessed[thirdEdge] && !hasBeenProcessed[fourthEdge]){
                            if(edgeHeap.contains(e2)){ touch(e2); se[e2]--; if(!isUpdated[e2]){seToUpdate[seToUpdateIdx++]=e2; isUpdated[e2]=1;} }
                            if(edgeHeap.contains(thirdEdge)){ touch(thirdEdge); se[thirdEdge]--; if(!isUpdated[thirdEdge]){seToUpdate[seToUpdateIdx++]=thirdEdge; isUpdated[thirdEdge]=1;} }
                            if(edgeHeap.contains(fourthEdge)){ touch(fourthEdge); se[fourthEdge]--; if(!isUpdated[fourthEdge]){seToUpdate[seToUpdateIdx++]=fourthEdge; isUpdated[fourthEdge]=1;} }
                        }
                        if(e==e2 && bitr[e1]>=BLevel && !hasBeenProcessed[e1] && !hasBeenProcessed[thirdEdge] && !hasBeenProcessed[fourthEdge]){
                            if(edgeHeap.contains(e1)){ touch(e1); se[e1]--; if(!isUpdated[e1]){seToUpdate[seToUpdateIdx++]=e1; isUpdated[e1]=1;} }
                            if(edgeHeap.contains(thirdEdge)){ touch(thirdEdge); se[thirdEdge]--; if(!isUpdated[thirdEdge]){seToUpdate[seToUpdateIdx++]=thirdEdge; isUpdated[thirdEdge]=1;} }
                            if(edgeHeap.contains(fourthEdge)){ touch(fourthEdge); se[fourthEdge]--; if(!isUpdated[fourthEdge]){seToUpdate[seToUpdateIdx++]=fourthEdge; isUpdated[fourthEdge]=1;} }
                        }
                    }
                    hasBeenProcessed[e]=1;
                }
                for(intE i=0;i<seToUpdateIdx;i++){ OPS_ALG(); intE e=seToUpdate[i]; edgeHeap.updateEdgeWeight(e, se[e]); isUpdated[e]=0; }
                
            }
            { auto allE = edgeHeap.getAllEdges(); OPS_ALG_N(allE.size());    
              for(intE e : allE){ OPS_ALG(); PB91_COUNT(phiWritesIncludingNew,1);if(e!=eid){PB91_COUNT(phiWritesExcludingNew,1);}bitr[e]=BLevel+1; } }    

            for(intE t: touched){ OPS_ALG(); se[t]=0; visited[t]=0; hasBeenProcessed[t]=0; isUpdated[t]=0; onTouched[t]=0; }
            touched.clear();
        }

        addWedge(bloomId, spokeNew);
    }

    return eid;
    }
};
#endif
