//
//  utils.h
//  Tip_decompisition
//
//  Created by Jing Bai on 2023/1/20.
//  Copyright © 2023 Jing Bai. All rights reserved.
//

#ifndef utils_h
#define utils_h
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <numeric>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cassert>
#include <utility>
#include <string>
#include <cstring>
#include <ctime>
#include <map>
#include <atomic>


template <typename T1, typename T2>
class valCompareGreater
{
    const std::vector<T2> &value_vector;

    public:
    valCompareGreater(const std::vector<T2> &val_vec):
        value_vector(val_vec) {}

    bool operator() (const T1 &i1, const T1 &i2) const
    {
        return value_vector[i1] > value_vector[i2];
    }
};

template <typename T1, typename T2>
class valCompareLesser
{
    const std::vector<T2> &value_vector;

    public:
    valCompareLesser(const std::vector<T2> &val_vec):
        value_vector(val_vec) {}

    bool operator() (const T1 &i1, const T1 &i2) const
    {
        return value_vector[i1] < value_vector[i2];
    }
};

template <typename T>
void free_vec (std::vector<T> &vec)
{
    std::vector<T> dummy;
    vec.swap(dummy);
}

template <typename T1, typename T2>
void serial_sort_kv (std::vector<T1> &idxVec, std::vector<T2> &valueVec)
{
    std::stable_sort(idxVec.begin(), idxVec.end(), valCompareGreater<T1,T2>(valueVec));
}

template <typename T1, typename T2>
void serial_sort_kv_increasing (std::vector<T1> &idxVec, std::vector<T2> &valueVec)
{
    std::stable_sort(idxVec.begin(), idxVec.end(), valCompareLesser<T1,T2>(valueVec));
}

template <typename T1, class compare>
void sort_indices (std::vector<T1> &idxVec, compare comp)
{
    stable_sort(idxVec.begin(), idxVec.end(), comp);
}

template <typename T>
void invertMap (std::vector<T> &ipMap, std::vector<T> &opMap)
{
    opMap.resize(ipMap.size());
    for (size_t i=0; i<ipMap.size(); i++)
    {
        opMap[ipMap[i]] = i;
        
    }
}

template <typename T1, typename T2>
inline T1 choose2(T2 n)
{
    if (n < 2) return 0;
    T1 retVal = (T1)n;
    retVal = retVal*(retVal-1);
    return retVal/2;
}

//exclusive sum
template <typename T1, typename T2>
void prefix_sum (std::vector<T1> &output, std::vector<T2> &input)
{
    if (output.size() != (input.size() + 1))
        output.resize(input.size() + 1);
    size_t start = 0;
    size_t end = input.size();
    
    output[0] = 0;
    for (size_t i=start; i<end; i++)
        output[i+1] = output[i] + input[i];
}

template <typename T1, typename T2,typename T3>
void prefix_sum_cut (std::vector<T1> &output, std::vector<T2> &input, T3 revised_length)
{
    size_t sz = 0;
    if((revised_length+1) < (input.size()+1))
        sz = revised_length+1;
    else sz = (input.size()+1);

    if (output.size() != sz)
        output.resize(sz);
    size_t start = 0;
    size_t end = sz - 1;
    
    output[0] = 0;
    for (size_t i=start; i<end; i++)
        output[i+1] = output[i] + input[i];
}

template <typename T>
void init (std::vector<T> &vec, T val)
{
    size_t numElems = vec.size();
    for (size_t i=0; i<numElems; i++)
        vec[i] = val;
}

template <typename Tout, typename Tin>
Tout reduce (std::vector<Tin> &in)
{
    Tout retVal = 0;
    size_t vecSize = in.size();
    for (size_t i=0; i<vecSize; i++)
        retVal += in[i];
    return retVal;
}

template<typename T>
T intersection_count(std::vector<T> &vec1, std::vector<T> &vec2)
{
    T ans = 0;
    if(vec1.empty() || vec2.empty()){
        return 0;
    }   
    // we assume vec1 and vec2 are sorted by ascending order of the elements
    T i, j;
    i = j = 0;
    while(i < vec1.size() && j < vec2.size()){
        if(vec1[i] == vec2[j]){
            ans++;
            i++;
            j++;
        }
        else if(vec1[i] > vec2[j]){
            j++;
        }
        else{
            i++;
        }
    }   
    return ans;
}

 
bool isVertexInSet(const std::vector<unsigned int>& vertexSet, unsigned int vertex)
{
     
    return std::binary_search(vertexSet.begin(), vertexSet.end(), vertex);
}

template<typename T>
T findMinimum(T a, T b, T c, T d) {
     
    return std::min({a, b, c, d});
}

#endif /* utils_h */
