#!/usr/bin/env python3
"""
Sample edges from a bipartite graph.
The first input line is a header; subsequent lines contain endpoint pairs.
For each percentage, write a sampled edge subset named <input>_sample<percent>.txt.

Usage:
    python3 sample_bipartite_edges.py INPUT [--ratios 20 40 60 80] [--seed 42]

Example:
    python3 sample_bipartite_edges.py data/datasets/full/actor-movie.txt --seed 42
"""

import argparse
import os
import random
import sys


def sample_bipartite_edges(input_file, ratios, seed=None, prefix=None, output_dir=None):
    if seed is not None:
        random.seed(seed)

    with open(input_file, 'r') as f:
        header = f.readline()
        edges = f.readlines()

    total_edges = len(edges)
    print(f"Reading file: {input_file}")
    print(f"Total edges: {total_edges}")

    if output_dir is None:
        output_dir = os.path.dirname(input_file)

    for ratio_pct in ratios:
        ratio = ratio_pct / 100.0
        sample_size = int(total_edges * ratio)
        if sample_size == 0:
            print(f"  Ratio {ratio_pct}%: sample is empty, skipping")
            continue

        sampled = random.sample(edges, sample_size)

        if prefix:
            ratio_tag = f"{ratio_pct // 10:02d}"
            output_file = os.path.join(output_dir, f"{prefix}{ratio_tag}edgeSample.txt")
        else:
            base_name = os.path.basename(input_file)
            name_without_ext = os.path.splitext(base_name)[0]
            output_file = os.path.join(output_dir, f"{name_without_ext}_sample{ratio_pct}.txt")

        with open(output_file, 'w') as f:
            f.write(header)
            f.writelines(sampled)

        print(f"  Ratio {ratio_pct}%: retained {sample_size} edges -> {output_file}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Sample edges from a bipartite graph")
    parser.add_argument("input_file", help="Input bipartite graph file")
    parser.add_argument("--ratios", type=int, nargs="+", default=[20, 40, 60, 80],
                        help="Sampling percentages (default: 20 40 60 80)")
    parser.add_argument("--seed", type=int, default=None,
                        help="Random seed for reproducible sampling")
    parser.add_argument("--prefix", type=str, default=None,
                        help="Output prefix; YT produces names such as YT02edgeSample.txt")
    parser.add_argument("--output-dir", type=str, default=None,
                        help="Output directory (default: input file directory)")
    args = parser.parse_args()

    if not os.path.isfile(args.input_file):
        print(f"Error: file does not exist: {args.input_file}", file=sys.stderr)
        sys.exit(1)

    sample_bipartite_edges(args.input_file, args.ratios, args.seed, args.prefix, args.output_dir)
