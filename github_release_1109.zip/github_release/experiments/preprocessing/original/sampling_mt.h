//
//  sampling_mt.h
 
//
 
 
 
 
 
//
 
 
 
//

#ifndef sampling_mt_h
#define sampling_mt_h
#include "Header.h"
#include "graph.h"
#include "utils.h"
#include <random>
#include <cstdio>
#include <string>
#include <chrono>    
 

// ============================================================
 
// ============================================================
inline void initFixedSeed(unsigned int seed = 20260923u)
{
    srand(seed);
}

// ============================================================
 
 
// ============================================================
inline long getMemoryVmHWM_KB()
{
    FILE* fp = fopen("/proc/self/status", "r");
    if(fp == NULL) return 0;
    char line[256];
    long kb = 0;
    while(fgets(line, sizeof(line), fp))
    {
        if(strncmp(line, "VmHWM:", 6) == 0)
        {
             
            sscanf(line + 6, "%ld", &kb);
            break;
        }
    }
    fclose(fp);
    return kb;
}

 
inline double getMemoryVmHWM_MB()
{
    return getMemoryVmHWM_KB() / 1024.0;
}

// ============================================================
 
 
 
 
// ============================================================
inline pair<intV,intV> sampleUniformNonEdge(Graph &G, int maxTry = 1000)
{
    for(int t = 0; t < maxTry; t++)
    {
        intV u = G.uLabels[rand() % G.numU];
        intV v = G.vLabels[rand() % G.numV];
         
        if(!isVertexInSet(G.adj[u], static_cast<unsigned int>(v)))
            return make_pair(u, v);
    }
    return make_pair(G.numT, G.numT);  
}

// ============================================================
 
 
 
 
// ============================================================
inline pair<intV,intV> sampleUniformExistEdge(Graph &G, int maxTry = 1000)
{
    for(int t = 0; t < maxTry; t++)
    {
        intV u = G.uLabels[rand() % G.numU];
        if(G.deg[u] < 1) continue;
        intV v = G.adj[u][rand() % G.deg[u]];
        return make_pair(u, v);
    }
    return make_pair(G.numT, G.numT);  
}

 
inline bool isValidSample(Graph &G, const pair<intV,intV> &e)
{
    return !(e.first == G.numT && e.second == G.numT);
}

// ============================================================
 
//
 
 
 
//
 
 
 
 
 
 
 
 
//
 
 
// ============================================================
inline bool hasButterflyOnEdge(Graph &G, intV u1, intV v1, double &elapsed_ms)
{
     
     
    auto t0 = std::chrono::steady_clock::now();

    intV degV1 = 0;
    std::vector<intV>& v1Neighbors = G.get_neigh(v1, degV1);
    intV degU1 = 0;
    std::vector<intV>& u1Neighbors = G.get_neigh(u1, degU1);
    std::unordered_set<intV> v1NeighSet(v1Neighbors.begin(), v1Neighbors.end());

    bool hasBFL = false;
    for (intV v : u1Neighbors)
    {
        if (v == v1) continue;               
        intV degV = 0;
        std::vector<intV>& vNeighbors = G.get_neigh(v, degV);
        for (intV u : vNeighbors)
        {
            if (u == u1) continue;           
            if (v1NeighSet.count(u)) { hasBFL = true; break; }   
        }
        if (hasBFL) break;
    }

    auto t1 = std::chrono::steady_clock::now();
    elapsed_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    return hasBFL;
}

#endif
