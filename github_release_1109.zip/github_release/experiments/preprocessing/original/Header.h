//
//  Header.h
//  Tip_decompisition
//
//  Created by Jing Bai on 2023/1/20.
//  Copyright © 2023 Jing Bai. All rights reserved.
//

#ifndef Header_h
#define Header_h
#include <iostream>
#include <string>
#include <cstdlib>
#include <algorithm>
#include <cstring>
#include <time.h>
#include <cstdio>
#include <cassert>
#include <cstdio>
#include <stdio.h>
#include <numeric>
#include <set>
#include <unordered_set>
#include <unordered_map>
#include <map>
#include <sstream>
#include <vector>
#include <queue>
#include <stdio.h>
#include <errno.h> 
#include <stdlib.h> 
#include <string.h> 
#include <omp.h>
#include <thread>
#include <fstream>
#include <random>
#include <numeric>
//#include "graph.h"
//#include "utils.h"
//#include "count.h"


#endif /* Header_h */
