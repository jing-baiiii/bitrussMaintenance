//
//  graph.h
//  Tip_decompisition
//
//  Created by Jing Bai on 2023/1/20.
//  Copyright © 2023 Jing Bai. All rights reserved.
//

#ifndef graph_h
#define graph_h
//#include "Header.h"
#include "utils.h"




using namespace std;

typedef unsigned int intV;
typedef unsigned int intE;
typedef long long int intB;

 
 
 
 
inline long long g_blooms_visited = 0;
inline long long g_butterflies_accessed = 0;
inline void resetStructAccessCounters() { g_blooms_visited = 0; g_butterflies_accessed = 0; }

#define CL_SIZE 1


/*********************************************************
Bloom Edge Graph Space Efficient
*********************************************************/
typedef struct BEGraphLoMem
{
    intE numU; // # edges of G
    intB numV; // # blooms
    intB numE; // # edges in BE Index

    std::vector<intB> edgeVI; //offsets for U
    std::vector<intB> bloomVI; //offsets for V
    std::vector<intE> edgeDegree;
    std::vector<intE> bloomDegree;
    std::vector<intE> bloomWdgCnt;
    std::vector<std::pair<intV,intV>> bloomMaster; // bloomMaster[bloomID]: (ver, ver), they are the two master vertices of the bloom
    std::vector<std::pair<intB, intE>> edgeEI; //edges from U to V (bloom ID, neighbor edge ID)
    std::vector<std::pair<intE, intE>> bloomEI; //edges to V to U (transpose of edgeEI)

} BEGraphLoMem;

/*********************************************************
Bloom Vertex Graph Space Efficient
*********************************************************/
typedef struct BVGraphLoMem
{
    intV numU; // # vertex of G
    intB numV; // # blooms
    intB numE; // # edges in BV Index

    std::vector<intV> verVI; //offsets for U
    std::vector<intB> bloomVI; //offsets for V
    std::vector<intE> verDegree; // how many blooms the vertex participate
    std::vector<intV> bloomDegree; // how many vertices the bloom have
    std::vector<intE> bloomWdgCnt;
    std::vector<std::pair<intV, intV>> bloomMaster; // bloomMaster[bloomID]: (ver, ver), they are the two master vertices of the bloom
    std::vector<intB> verEI; // bloomID, vertex participate which blooms
    std::vector<intV> bloomEI; // which vertices in the bloom
    std::vector<bool> isNull_bloom;// is the current bloom deleted
    
} BVGraphLoMem;

/*********************************************************
Index for Searching ABCore
*********************************************************/
typedef struct SearchVerIndex
{
    std::vector<intB> A_deg_offset; //the position in B_offset
    std::vector<intB> B_offset; //the position of A-B in block_ver
    std::vector<intV> block_ver; // the vertices that belong to (A,B)-butterfly
    
} SearchVerIndex;


/*********************************************************
Index for pruning vertices before del_cnt
*********************************************************/
typedef struct peelTipIndex
{
    std::vector<intB> tipValue; //tip value, length = G.numT

    std::vector<intV> vCoVertex; //the vertices of V ordered by tipValue, length = the total with tipValue > 0
    std::vector<intB> vCoValue; //the corresponding tipValue of U of the vertices in vCoVertex

    std::vector<intV> uCoVertex; //
    std::vector<intB> uCoValue;
    
} peelTipIndex;

struct pair_hash
{
    template<class T1, class T2>
    std::size_t operator() (const std::pair<T1, T2>& p) const
    {
        auto h1 = std::hash<T1>{}(p.first);
        auto h2 = std::hash<T2>{}(p.second);
        return h1 ^ h2;
    }
};

typedef struct Edge {
    // intE support;
    intB bitrussness;
    unordered_map<pair<intV, intV>, intE, pair_hash> blooms; //all the blooms containing the edge, and the edge's twin in corresponding bloom
}Edge;

typedef struct Bloom 
{
    intV uid; //The vertex with highest priority
    intV wid; //The vertex a same side with u
    intB bloomWdgCnt;
    unordered_set<intV> Wedges; //The wedges(start-middle-end) that the bloom have
}Bloom;


 
typedef struct Edge_vec {
    // intE support;
    intB bitrussness;
    vector<pair<pair<intV, intV>, intE>> blooms; //all the blooms containing the edge, and the edge's twin in corresponding bloom
    
     
    void reserve_blooms(size_t expected_size) {
        blooms.reserve(expected_size);
    }
    
     
    intE findBloomTwin(const pair<intV, intV>& bloomPair) const {
        for (const auto& item : blooms) {
            if (item.first == bloomPair) {
                return item.second;
            }
        }
        return -1;  
    }
    
     
    void addBloomPair(const pair<intV, intV>& bloomPair, intE twinEdge) {
        blooms.push_back({bloomPair, twinEdge});
    }
    
     
    void removeBloomPair(const pair<intV, intV>& bloomPair) {
        auto it = remove_if(blooms.begin(), blooms.end(), 
            [&bloomPair](const auto& item) { return item.first == bloomPair; });
        blooms.erase(it, blooms.end());
    }
}Edge_vec;

typedef struct Bloom_vec 
{
    intV uid; //The vertex with highest priority
    intV wid; //The vertex a same side with u
    intB bloomWdgCnt;
    vector<intV> Wedges; //The wedges(start-middle-end) that the bloom have
    
     
    void reserve_wedges(size_t expected_size) {
        Wedges.reserve(expected_size);
    }
    
     
    void insertWedge(intV v) {
        if (find(Wedges.begin(), Wedges.end(), v) == Wedges.end()) {
            Wedges.push_back(v);
        }
    }
    
     
    void eraseWedge(intV v) {
        auto it = remove(Wedges.begin(), Wedges.end(), v);
        Wedges.erase(it, Wedges.end());
    }
    
     
    bool containsWedge(intV v) const {
        return find(Wedges.begin(), Wedges.end(), v) != Wedges.end();
    }
    
     
    size_t size() const {
        return Wedges.size();
    }
}Bloom_vec;

 
 






























class Graph
{

private:

    std::vector<uint8_t> deleted; //is the vertex deleted in previous rounds
    void remove_duplicates();

public:

    intV numU;
    intV numV;
    intV numT;
    intE numE;
    intB sumB;
    intV numTT;
    intE max_deg_U;
    intE max_deg_V;
    intV i_U; // max_deg_U is from which vertex in U with the original togetherID before ordering (vertex)
    intV i_V; // max_deg_V is from which vertex in V with the original togetherID before ordering (vertex)
    intV *ranks;
    intB maxBitrussness;
    
    std::vector<std::vector<intV>> adj;
    std::vector<std::vector<intE>> eId;
    std::vector<intV> deg;
    std::vector<intV> verDeg;
    std::vector<intV> uLabels;
    std::vector<intV> vLabels;
    std::vector<intV> small_bNum; //collect the vertices whose butterfly number is less than a parameter
    std::vector<bool> weight;
    std::vector<bool> uORv; //uORv[9] = 0 means vertexID=9 and it is belong to U
    // std::unordered_map<pair<intV, intV>, Bloom, pair_hash> bIndex; // uid, wid, and the bloom
    std::vector<pair<intV, intV>> edgeArray;   
    std::unordered_map<pair<intV, intV>, intE, pair_hash> edgeToId;   
    vector<std::pair<intV, intV>> eIdToV;  
    
    

    Graph(): numV(0), numU(0), numT(0), numE(0), sumB(0), max_deg_U(0), max_deg_V(0), i_U(0), i_V(0) {}
    Graph(intV V, intV U, intE E): numV(V), numU(U), numT(U+V), numE(E)
    {
        adj.resize(numT);
        uLabels.resize(numU);
        vLabels.resize(numV);
        deg.resize(numT, 0);
        deleted.resize(numT, 0);
        weight.resize(numT, true);
        uORv.resize(numT,false);
        edgeArray.resize(numE);
    }

    //get neighbors of a vertex
    inline std::vector<intV>& get_neigh(intV v, intV &degV);
    inline std::vector<intV>& get_neigh_verDeg(intV v, intV &degV);
    inline intV& get_rank(intV v);
    inline void set_rank(vector<intV> &verToLab);

    //sort adjacency lists on increasing order of index or
    //decreasing order of user-specified priority
    void sort_adj();
    void sort_adj(std::vector<intV> &priority);

    //sort vertices in the degree order
    void sort_deg(std::vector<intV> &opList);
    void sort_label(std::vector<intV> &labToVer, std::vector<intV> &verToLab);
    void sort_bfl(std::vector<intV> &sortedLabels, vector<intB> &butterflyCnt);

    //reorder the graph and produce a new graph object
    void reorder(std::vector<intV> &newLabels, Graph &outG);
    //reorder the same graph object
    void reorder_in_place(std::vector<intV> &newLabels);
    //create a copy (excludes deleted vertice/edges)
    void copy(Graph &outG);

    //read graph from a file
    void read_graph(std::string &filename, int peelSide);
    void read_graph_bin(std::string &filename, int peelSide);
    void reformat_graph(Graph &G, vector<bool> &removed, vector<intV> &labToVer);

    //check if vertex is deleted
    inline bool is_deleted(intV v);
    
    //check if vertex is belong to U (0) or V (1)
    inline bool U_or_V(intV v);

    //delete/restore vertices
    inline void delete_vertex(intV v);
    inline void restore_vertex(intV v);

    //delete edges
    inline void delete_edges();
    inline void restore_edges();
    
    inline void del_neigh(bool *removed, intV vertex, intV other);
    inline void assign_weight(intV bflThre_l, intV bflThre_r, vector<intB> &butterflyCnt, vector<bool> &weight, vector<intV> &labToVer);
    inline  bool whether_change_weight(intV &n, intV vertex, intV bflThre_l, intV bflThre_r, vector<intB> &butterflyCnt, bool *weight, vector<intV> &labToVer);
    inline void get_true_neigh(intV v, intV &degV, bool *weight, vector<intV> &true_adj);

    void get_labels(std::vector<intV> &labels, int side);

    //FOR DEBUGGING//
    void dump_graph();
    void print_graph();
    void print_orderedGraph(vector<intV> &labalsToVertex, vector<intV> &vertexToLabals);

    ~Graph() {
        for (intV i=0; i<numT; i++)
            free_vec(adj[i]);
        free_vec(adj);
        free_vec(deg);
        free_vec(uLabels);
        free_vec(vLabels);
        free_vec(eId);
        free_vec(deleted);
        free_vec(weight);
    }
};

void Graph::reformat_graph(Graph &G, vector<bool> &removed, vector<intV> &labToVer)
{
    Graph g;
    vector<bool> temp_uORv;
    temp_uORv.resize(numT,false);
    
    vector<intV> newlabToOldlab(numT);
    sort_deg(newlabToOldlab);
//    cout << "newlabToOldlab:" << endl;
//    for(intV i = 0; i < numT; i++)
//    {
//        cout << "(" << i << "," << newlabToOldlab[i] << "), ";
//    }
//    cout << endl;
    vector<intV> oldlabToNewlab(numT,0);
    for(intV i = 0; i < numT; i++)
    {
        oldlabToNewlab[newlabToOldlab[i]] = i;
    }
//    cout << "oldlabToNewlab:" << endl;
//    for(intV i = 0; i < numT; i++)
//    {
//        cout << "(" << i << "," << oldlabToNewlab[i] << "), ";
//    }
//    cout << endl;
//    cout << "labToVer___beforeq:" << endl;
//    for(intV i = 0; i < numT; i++)
//    {
//        cout << "(" << i << "," << labToVer[i] << "), ";
//    }
//    cout << endl;
    vector<intV> temp_labToVer(numT);
    for(intV i = 0; i < numT; i++)
    {
        temp_labToVer[i] = labToVer[newlabToOldlab[i]];
    }
    labToVer.swap(temp_labToVer);
    vector<intV> ().swap(temp_labToVer);
    
//    cout << "labToVer:" << endl;
//    for(intV i = 0; i < numT; i++)
//    {
//        cout << "(" << i << "," << labToVer[i] << "), ";
//    }
//    cout << endl;
    
//    for(intV i = 0; i < numT; i++)
//    {
//        temp_uORv[i] = uORv[newlabToOldlab[i]];
//    }
//    temp_uORv.swap(uORv);
    
//    cout << "uORv:" << endl;
//    for(intV i = 0; i < numT; i++)
//    {
//        cout << "(" << i << "," << uORv[i] << "), ";
//    }
//    cout << endl;
//    cout << "temp_uORv:" << endl;
//    for(intV i = 0; i < numT; i++)
//    {
//        cout << "(" << i << "," << temp_uORv[i] << "), ";
//    }
//    cout << endl;
    vector<bool> ().swap(temp_uORv);
    
    vector<vector<intV>> newAdj;
    newAdj.resize(numT);
    for(intV i = 0; i < numT; i++)
    {
        if(!removed[i])
        {
            //cout << "i = " << i << endl;
            vector<intV> new_vec(G.deg[i]);
            intV idx = 0;
            for(intV j = 0; j < adj[i].size(); j++)
            {
                if(!removed[adj[i][j]])
                {
                    new_vec[idx++] = oldlabToNewlab[adj[i][j]];
                }
            }
            newAdj[oldlabToNewlab[i]].resize(new_vec.size());
            newAdj[oldlabToNewlab[i]].swap(new_vec);
        }
    }
    vector<intV> ().swap(oldlabToNewlab);
    for(intV i = 0; i < G.numT; i++)
    {
        adj[i].clear();
        adj[i].swap(newAdj[i]);
        vector<intV> ().swap(newAdj[i]);
    }
    G.sort_adj();
    vector<intV> newDeg (numT);
    for(intV i = 0; i < numT; i++)
    {
        newDeg[i] = deg[newlabToOldlab[i]];
    }
    deg.swap(newDeg);
//    cout << "G.deg_new:" << endl;
//    for(intV i = 0; i < numT; i++)
//    {
//        cout << "(" << i << "," << deg[i] << "), ";
//    }
//    cout << endl;
}

void Graph::read_graph(std::string &filename, int peelSide)
{
    FILE* fp = fopen(filename.c_str(), "r");
    if (fp==NULL)
    {
        fputs("file error\n", stderr);
        exit(EXIT_FAILURE);
    }
    printf("reading....\n");
    //ignore sentences starting with "%"
    fpos_t position;
    char buf[256];
    fgetpos(fp, &position);
    fgets(buf, sizeof(buf), fp);
    while((buf[0]=='%') && !feof(fp))
    {
        fgetpos(fp, &position);
        fgets(buf, sizeof(buf), fp);
    }
    if (feof(fp))
        return;
    fsetpos(fp, &position);
    //printf("comments finished\n");
    

    std::vector<std::pair<intV, intV>> edges;
    intV u, v;
    intE e = 0;
    // fscanf(fp, "%d", &u);
    // fscanf(fp, "%d", &u);
    // fscanf(fp, "%d", &u);
    while(!feof(fp))
    {
        if (fscanf(fp, "%d", &u) <= 0)
            break;
        if (fscanf(fp, "%d", &v) <= 0)
            break;
        if (peelSide==1)
            std::swap(u, v);
        numU = std::max(u+1, numU);
        numV = std::max(v+1, numV);
        edges.push_back(std::make_pair(u, v));
        e++;
    }
    fclose(fp);
    cout << "e = " << e << endl;
    //printf("%lu edges read\n", edges.size());
    numT = numU + numV;
    
    uLabels.resize(numU);
    for (intV i=0; i<numU; i++)
        uLabels[i] = i;

    //in Koblenz format, both U and V indices start from 1
    //to distinguish, add numU to V indices
    vLabels.resize(numV);
    for (intV i=0; i<numV; i++)
        vLabels[i] = i+numU;
        
    adj.resize(numT);
    intE numEdgesRead = edges.size();
    for (intE i=0; i<numEdgesRead; i++)
    {
        u = edges[i].first; v = edges[i].second+numU;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    //printf("adjacency list created\n");

    deleted.resize(numT, false);
    weight.resize(numT, true);
    uORv.resize(numT,false);
    //cout << "numU = " << numU << ", numV = " << numV << ", numT = " << numT << ", numE = " << numE << endl;
    remove_duplicates();
    //cout << "after remove_duplication: " << endl << "numU = " << numU << ", numV = " << numV << ", numT = " << numT << ", numE = " << numE << endl;
    //print_graph();

}

inline std::vector<intV>& Graph::get_neigh(intV v, intV &degV)
{
    degV = deg[v];
    return adj[v];
}
inline void Graph::get_true_neigh(intV v, intV &degV, bool *weight, vector<intV> &true_adj)
{
    degV = deg[v];
    intV deg = 0;
    for(intV i = 0; i < degV; i++)
    {
        if(weight[adj[v][i]] == true)
        {
            true_adj.push_back(adj[v][i]);
            deg++;
        }
    }
    degV = deg;
}
inline std::vector<intV>& Graph::get_neigh_verDeg(intV v, intV &degV)
{
    degV = verDeg[v];
    return adj[v];
}
inline intV& Graph::get_rank(intV v)
{
    return ranks[v];
}
inline void Graph::del_neigh(bool *removed, intV vertex, intV other)
{
    if(!removed[other])
        deg[other]--;
    for(auto it = adj[other].begin(); it != adj[other].end();)
    {
        if(*it == vertex)
        {
            it = adj[other].erase(it);
            break;
        }
        it++;
    }
}
inline void Graph::assign_weight(intV bflThre_l, intV bflThre_r, vector<intB> &butterflyCnt, vector<bool> &weight, vector<intV> &labToVer)
{
    cout << "assign_weight..............." << endl;
    intV toRemove = 0;
    for(intV i = 0; i < numT; i++)
    {
        //cout << "i=" << i << ", labToVer["<<i<<"]="<< labToVer[i]<<", butterflyCnt["<<i<<"]=" << butterflyCnt[i];
        if((labToVer[i] < numU && butterflyCnt[i] < bflThre_l) || (labToVer[i] >= numU && butterflyCnt[i] < bflThre_r))
        {
            //cout << "if: weight[" << i<<"]="<< weight[i]<<endl;
            weight[i] = false;
            toRemove++;
        }
        else
        {
            //cout <<"else: weight[" << i<<"]="<< weight[i]<<endl;
            weight[i] = true;
        }
    }
    cout << "end of assign_weight..............." << endl;
    cout << "To remove vertex_num = " << toRemove << endl;
}
inline bool Graph::whether_change_weight(intV &n, intV vertex, intV bflThre_l, intV bflThre_r, vector<intB> &butterflyCnt, bool *weight, vector<intV> &labToVer)
{
    if((weight[vertex] == true && labToVer[vertex] < numU && butterflyCnt[vertex] < bflThre_l) || (weight[vertex] == true && labToVer[vertex] >= numU && butterflyCnt[vertex] < bflThre_r))
     {
         weight[vertex] = false;
         n++;
         return true;
     }
    else
        return false;
}

//remove duplicate edges (also computes final degree)
void Graph::remove_duplicates()
{
    deg.resize(numT);
    verDeg.resize(numT);
    sort_adj();

    for (intV i=0; i<numT; i++)
    {
        intV numNeigh = 0;
        for (intV j=0; j<adj[i].size(); j++)
        {
            if (j==0)
                numNeigh++;
            else if (adj[i][j] != adj[i][j-1])
                numNeigh++;
        }
        //set degree
        deg[i] = numNeigh;
        //verDeg[i] = numNeigh;
        if(numNeigh!=adj[i].size())
        {
            std::vector<intV> vec(numNeigh);
            numNeigh = 0;
            for (intV j=0; j<adj[i].size(); j++)
            {
                if (j==0)
                    vec[numNeigh++] = adj[i][j];
                else if (adj[i][j] != adj[i][j-1])
                    vec[numNeigh++] = adj[i][j];
            }
            vec.swap(adj[i]);
        }
        //assert(deg[i]==adj[i].size());
    }

    intE tempE = 0;
    for (intV i=0; i<numT; i++)
    {
        tempE += deg[i];
       if(i<numU)
       {
           if(deg[i] > max_deg_U)
           {
               i_U = i;
               max_deg_U = deg[i];
           }
       }
       else
       {
           if(deg[i] > max_deg_V)
           {
               i_V = i;
               max_deg_V = deg[i];
           }
       }
        
    }
   printf("\nmax_deg_U = %u, from: %d, max_deg_V = %u, from: %d\n", max_deg_U, i_U, max_deg_V, i_V);
    numE = tempE/2;
    
}

void Graph::sort_adj()
{
    for (intV i=0; i<numT; i++)
        std::stable_sort(adj[i].begin(), adj[i].end());
}

void Graph::sort_adj(std::vector<intV> &priority)
{
    for (intV i=0; i<numT; i++)
        serial_sort_kv(adj[i], priority);
}

//sorted labels is the list of vertices in a degree sorted order
//sort keys based on the values. Note that this does not change the value array
//The value array is indexed by the keys
void Graph::sort_deg(std::vector<intV> &sortedLabels)
{
    sortedLabels.resize(numT);
    for (intV i=0; i<numT; i++)
        sortedLabels[i] = i;
    serial_sort_kv(sortedLabels, deg);
}
void Graph::sort_label(std::vector<intV> &labToVer, std::vector<intV> &verToLab)
{

//    cout << "deg.capacity = " << deg.capacity() << endl;
//    printf("\nprint labToLab: (i,vec[i])\n");
//    for(intV i = 0; i < labToLab.size(); i++)
//    {
//        printf("(%d,%d), ",i,labToLab[i]);
//    }
//    printf("\n");
//    printf("\nprint deg: (i,vec[i])\n");
//    for(intV i = 0; i < deg.size(); i++)
//    {
//        printf("(%d,%d), ",i,deg[i]);
//    }
//    printf("\n");
}


void Graph::sort_bfl(std::vector<intV> &sortedLabels, vector<intB> &butterflyCnt)
{
    sortedLabels.resize(numT);
    vector<intB> bfl(numT);
    for (intV i=0; i<numT; i++)
    {
        sortedLabels[i] = i;
        bfl[i] = butterflyCnt[i];
    }
    serial_sort_kv(sortedLabels, bfl);
}

//newLabels is the map from existing to new labels
//eg. newLabels = [1, 2, 0] means vertex 0 is now 1,
//vertex 1 is now 2 and vertex 2 is now 0.
void Graph::reorder_in_place(std::vector<intV> &newLabels)
{
    std::vector<std::vector<intV>> adjNew (numT);
    std::vector<intV> uNew (numU);
    std::vector<intV> vNew (numV);
    std::vector<intV> degNew (numT);
    std::vector<uint8_t> delNew (numT);
    for (intV i=0; i<numU; i++)
        uNew[i] = newLabels[uLabels[i]];
    for (intV i=0; i<numV; i++)
        vNew[i] = newLabels[vLabels[i]];
    sort_indices(uNew, std::less<intV>());
    sort_indices(vNew, std::less<intV>());
    for (intV i=0; i<numT; i++)
    {
        intV numNeigh = adj[i].size();
//        adjNew[newLabels[i]].resize(numNeigh);
        adjNew[newLabels[i]].swap(adj[i]);
        for (intV j=0; j<numNeigh; j++)
            adjNew[newLabels[i]][j] = newLabels[adjNew[newLabels[i]][j]];
//            adjNew[newLabels[i]][j] = newLabels[adj[i][j]];
        degNew[newLabels[i]] = deg[i];
        delNew[newLabels[i]] = deleted[i];
    }
    uNew.swap(uLabels);
    vNew.swap(vLabels);
    adjNew.swap(adj);
    degNew.swap(deg);
    delNew.swap(deleted);
    sort_adj();
}

inline bool Graph::is_deleted(intV v)
{
    return ((deleted[v]==1) ? true : false);
}

inline void Graph::delete_vertex(intV v)
{
    deleted[v] = 1;
}

inline void Graph::restore_vertex(intV v)
{
    deleted[v] = 0;
}

void Graph::print_graph()
{
    printf("print graph.................\n");
    cout << "numU = " << numU << ", numV = " << numV << ", numT = " << numT << ", numE = " << numE << endl;
    cout << "degree: " << endl;
    intV from_U = -1;
    intV from_V = -1;
    for (intV i=0; i<numT; i++)
    {
        if(i<numU && (deg[uLabels[i]]>max_deg_U))
        {
            max_deg_U = deg[uLabels[i]];
            from_U = uLabels[i];
        }
        if(i<numV && (deg[vLabels[i]]>max_deg_V))
        {
            from_V = vLabels[i];
            max_deg_V = deg[vLabels[i]];
        }
        cout << "deg[" << i << "] = " << deg[i] << " ";
    }
    cout << endl;
    
    printf("\nmax_deg_U = %u, from: %d,  max_deg_V = %u, from: %d\n", max_deg_U, from_U, max_deg_V, from_V);
    printf("\nadj:\n");
    for (intV i=0; i<numT; i++)
    {
        for (intV j=0; j<deg[i]; j++)
            printf("(%d,%d); ", i, adj[i][j]);
    }
    printf("\nuLabels\n");
    for(intV i = 0; i < numU; i++)
    {
        printf("%d ", uLabels[i]); //together ID
    }
    printf("\nvLabels\n");
    for(intV i = 0; i < numV; i++)
    {
        printf("%d ", vLabels[i]); //together ID
    }
    printf("\n");
//    for(intV i = 0; i < numT; i++)
//    {
//        printf("delete[%d] = %d, ", i, deleted[i] );
//    }
//    printf("\n");
}

void Graph::print_orderedGraph(vector<intV> &labalsToVertex, vector<intV> &vertexToLabals)
{
    printf("print the orderedGraph..................\n");
    printf("print the vertices after sort_deg: \n");
    for(intV i = 0; i < numT; i++)
    {
        printf("%d:%d ", labalsToVertex[i], vertexToLabals[labalsToVertex[i]]);
    }
    printf("\n");
    print_graph();
}
#endif /* graph_h */
