//
 
//
 
 
 
 
//
 
 
 
//    3) insertEdges_konect_<dataset>.txt / deletedEdges_konect_<dataset>.txt
 
 
//
 
//
#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "sampling_mt.h"
#include <iostream>
#include <iomanip>
#include <algorithm>
using namespace std;

intB maxT = 0;    

 
#include <streambuf>
struct TeeBuf : std::streambuf {
    std::streambuf *a, *b;
    TeeBuf(std::streambuf* x, std::streambuf* y) : a(x), b(y) {}
    int overflow(int c) override {
        if (c == EOF) return !EOF;
        int r1 = a->sputc((char)c);
        int r2 = b->sputc((char)c);
        return (r1 == EOF || r2 == EOF) ? EOF : c;
    }
    int sync() override { return (a->pubsync() == 0 && b->pubsync() == 0) ? 0 : -1; }
};

 
struct Attempt {
    intV u, v;           
    bool trivial;        
    double judge_ms;     
};

 
 
static void toKonect(Graph &G, vector<intV> &labelsToVertex, intV lab, intV &kid, int &side)
{
    intV oldid = labelsToVertex[lab];
    if (oldid < G.numU) { kid = oldid; side = 0; }
    else                { kid = oldid - G.numU; side = 1; }
}

 
static void writeEdgeFiles(Graph &G, vector<intV> &labelsToVertex,
                           const vector<pair<intV,intV>> &seq,
                           const string &oursFile, const string &baiFile)
{
    ofstream f1(oursFile);
    f1 << "# Internal vertex identifiers for the proposed-method driver" << endl;
    for (const auto &p : seq) f1 << p.first << " " << p.second << endl;
    f1.close();

    ofstream f2(baiFile);
    f2 << "# Original graph vertex identifiers for the Bai loader" << endl;
    for (const auto &p : seq) {
        intV ku, kv; int su, sv;
        toKonect(G, labelsToVertex, p.first, ku, su);
        toKonect(G, labelsToVertex, p.second, kv, sv);
        if (su == 0) f2 << ku << " " << kv << endl;    
        else         f2 << kv << " " << ku << endl;    
    }
    f2.close();
}

 
static void writeStats(const string &file, const string &dataset, const string &op,
                       const vector<Attempt> &log, intV accepted)
{
    intV total = (intV)log.size();
    intV trivialCnt = 0; double trivialSum = 0.0;
    vector<double> trivialTimes;
    for (const auto &a : log) {
        if (a.trivial) { trivialCnt++; trivialSum += a.judge_ms; trivialTimes.push_back(a.judge_ms); }
    }
    double acceptRate = total > 0 ? (double)accepted / total : 0.0;
    double avgTrivial = trivialCnt > 0 ? trivialSum / trivialCnt : 0.0;
     
    double med = 0, p99 = 0, mx = 0;
    if (!trivialTimes.empty()) {
        sort(trivialTimes.begin(), trivialTimes.end());
        med = trivialTimes[trivialTimes.size() / 2];
        p99 = trivialTimes[(size_t)(trivialTimes.size() * 0.99) < trivialTimes.size()
                           ? (size_t)(trivialTimes.size() * 0.99) : trivialTimes.size() - 1];
        mx  = trivialTimes.back();
    }

    ofstream f(file);
    f << "# All legal candidates, trivial and nontrivial; internal vertex identifiers" << endl;
    f << "# dataset=" << dataset << " op=" << op << endl;
    f << "# total_attempts=" << total << " nontrivial(accepted)=" << accepted
      << " trivial=" << trivialCnt << endl;
    f << "# accept_rate=" << fixed << setprecision(6) << acceptRate << endl;
    f << "# trivial_judge_ms: mean=" << avgTrivial << " median=" << med
      << " p99=" << p99 << " max=" << mx << " total=" << trivialSum << endl;
    f << "# u v trivial(1/0) judge_time_ms" << endl;
    for (const auto &a : log)
        f << a.u << " " << a.v << " " << (a.trivial ? 1 : 0) << " " << a.judge_ms << endl;
    f.close();

    cout << "  [" << op << "] attempts=" << total << " accepted (nontrivial)=" << accepted
         << " trivial=" << trivialCnt << " acceptance=" << fixed << setprecision(4) << acceptRate << endl;
    cout << "  [" << op << "] trivial detection time (ms): mean=" << setprecision(6) << avgTrivial
         << " median=" << med << " p99=" << p99 << " max=" << mx << endl;
}

int main(int argc, const char* argv[])
{
     
    std::ofstream logFile("output.txt");
    TeeBuf teeBuf(std::cout.rdbuf(), logFile.rdbuf());
    std::cout.rdbuf(&teeBuf);

    initFixedSeed();    

     
    system("mkdir -p SampleEdges");
    const string outDir = "SampleEdges/";

    // ============================================================
     
     
    //                 DR=0  DS=1  YT=2  AM=3  DT=4  GH=5  ID=6  DBLP=7  WK=8
     
     
    int  onlyDataset = -1;      
    intV target      = 500;
    intV tryScale    = 50000;
    // ============================================================
     
    if (argc > 1) target      = (intV)atoi(argv[1]);
    if (argc > 2) tryScale    = (intV)atoi(argv[2]);
    if (argc > 3) onlyDataset = atoi(argv[3]);

     
    vector<const char*> name_array(19);
    name_array[0] = "dbpedia-recordlabel.txt";
    name_array[1] = "dbpedia-starring.txt";
    name_array[2] = "youtube-groupmemberships.txt";
    name_array[3] = "actor-movie.txt";
    name_array[4] = "dbpedia-team.txt";
    name_array[5] = "github.txt";
    name_array[6] = "komarix-imdb.txt";
    name_array[7] = "dblp-author.txt";
    name_array[8] = "wiki-en-cat.txt";
    name_array[9] = "livejournal-groupmemberships.txt";
    name_array[10] = "trackers.txt";
    name_array[11] = "flickr-groupmemberships.txt";

    vector<const char*> path_array(19);
    path_array[0] = "data/datasets/full/recordlabel.txt";
    path_array[1] = "data/datasets/full/starring.txt";
    path_array[2] = "data/datasets/full/youtube.txt";
    path_array[3] = "data/datasets/full/actor-movie.txt";
    path_array[4] = "data/datasets/full/team.txt";
    path_array[5] = "data/datasets/full/github.txt";
    path_array[6] = "data/datasets/full/imdb.txt";
    path_array[7] = "data/datasets/full/dblp.txt";
    path_array[8] = "data/datasets/full/WK.txt";
    path_array[9] = "data/datasets/full/livejournal-groupmemberships.txt";
    path_array[10] = "data/datasets/full/trackers.txt";
    path_array[11] = "data/datasets/full/flickr-groupmemberships.txt";

    intV times = 9;
    while (times < 12)
    {
         
        if (onlyDataset >= 0 && (int)times != onlyDataset) { times++; continue; }
         
        Graph G;
        string graphFile = path_array[times];
        int peelSide = 0;
        cout << "\n========== " << name_array[times] << " ==========" << endl;
        cout << graphFile << endl;
        G.read_graph(graphFile, peelSide);
        cout << "edges = " << G.numE << ", Total = " << G.numT
             << ", U = " << G.numU << ", V = " << G.numV << endl;

        vector<intV> labelsToVertex, vertexToLabels;
        G.sort_deg(labelsToVertex);
        invertMap(labelsToVertex, vertexToLabels);
        G.reorder_in_place(vertexToLabels);

        cout << "VmHWM after loading = " << fixed << setprecision(2) << getMemoryVmHWM_MB() << " MB" << endl;

        intV maxAttempts = target * tryScale;

         
        {
            vector<Attempt> log;
            vector<pair<intV,intV>> nontrivial;
            intV attempts = 0;
            while (nontrivial.size() < target && attempts < maxAttempts)
            {
                pair<intV,intV> e = sampleUniformNonEdge(G);    
                if (!isValidSample(G, e)) { attempts++; continue; }
                attempts++;

                double ms = 0.0;
                bool nt = hasButterflyOnEdge(G, e.first, e.second, ms);   
                log.push_back({e.first, e.second, !nt, ms});
                if (nt) nontrivial.push_back(e);

                if (attempts % 2000 == 0)
                    cout << "  insertion progress: attempts=" << attempts << " accepted=" << nontrivial.size() << endl;
            }
            cout << "  insertion sampling completed: attempts=" << attempts << " accepted=" << nontrivial.size() << endl;

             
             
             
             
             
             
             
             
            writeEdgeFiles(G, labelsToVertex, nontrivial,
                           outDir + "edges_ours_nontrivial_ins_" + name_array[times],
                           outDir + "edges_Bai_nontrivial_ins_" + name_array[times]);
            writeStats(outDir + "edges_all_ins_" + name_array[times],
                       name_array[times], "insert", log, (intV)nontrivial.size());
        }

         
        {
            vector<Attempt> log;
            vector<pair<intV,intV>> nontrivial;
            intV attempts = 0;
            while (nontrivial.size() < target && attempts < maxAttempts)
            {
                pair<intV,intV> e = sampleUniformExistEdge(G);   
                if (!isValidSample(G, e)) { attempts++; continue; }
                attempts++;

                double ms = 0.0;
                bool nt = hasButterflyOnEdge(G, e.first, e.second, ms);   
                log.push_back({e.first, e.second, !nt, ms});
                if (nt) nontrivial.push_back(e);

                if (attempts % 2000 == 0)
                    cout << "  deletion progress: attempts=" << attempts << " accepted=" << nontrivial.size() << endl;
            }
            cout << "  deletion sampling completed: attempts=" << attempts << " accepted=" << nontrivial.size() << endl;

             
             
             
             
            writeEdgeFiles(G, labelsToVertex, nontrivial,
                           outDir + "edges_ours_nontrivial_del_" + name_array[times],
                           outDir + "edges_Bai_nontrivial_del_" + name_array[times]);
            writeStats(outDir + "edges_all_del_" + name_array[times],
                       name_array[times], "delete", log, (intV)nontrivial.size());
        }

        cout << "Dataset completed, VmHWM = " << fixed << setprecision(2) << getMemoryVmHWM_MB() << " MB" << endl;
        times++;
    }

    cout << "\nAll completed. Final VmHWM = " << fixed << setprecision(2) << getMemoryVmHWM_MB() << " MB" << endl;

     
    std::cout.flush();
    std::cout.rdbuf(teeBuf.a);    
    logFile.close();
    return 0;
}