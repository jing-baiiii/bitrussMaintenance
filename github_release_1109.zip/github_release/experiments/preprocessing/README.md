# Preprocessing Sources

Formal reproduction reads the frozen graphs and event files listed in `data/inputs.json`; re-sampling is not required. Re-sampling creates a different event order and does not reproduce the published workload.

`normalize.cpp` is the source copy used to normalize GH scalability graphs. It deduplicates edges in the shared-identifier graph, performs BFS two-coloring, assigns separate identifiers to the two partitions, and writes a conversion report. It is not used for ID, whose input already assigns identifiers separately by partition.

```bash
mkdir -p build
g++ -std=c++17 -O3 experiments/preprocessing/normalize.cpp -o build/normalize
build/normalize raw_GH02.txt converted_GH02.txt conversion_report.json
```

`original/` preserves the original sampling program and its direct dependencies. `mainSample.cpp` uses seed `20260923` by default. Formal reproduction uses the frozen event files and hashes in the release. `sample_bipartite_edges.py` is a graph-edge sampling utility and accepts an explicit seed.
