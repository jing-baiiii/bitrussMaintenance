#include <algorithm>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;

int main(int argc,char** argv) {
    try {
        if(argc!=4)throw runtime_error("input output report required");
        if(filesystem::exists(argv[2])||filesystem::exists(argv[3]))throw runtime_error("output exists");
        ifstream input(argv[1]);if(!input)throw runtime_error("missing graph");
        vector<pair<uint32_t,uint32_t>> directed;string line;uint32_t maximum=0;
        while(getline(input,line)) {
            if(line.empty()||line[0]=='%'||line[0]=='#')continue;
            istringstream row(line);uint64_t a,b;string extra;
            if(!(row>>a>>b)||(row>>extra)||max(a,b)>=UINT32_MAX||a==b)throw runtime_error("invalid raw edge");
            directed.emplace_back(a,b);maximum=max(maximum,(uint32_t)max(a,b));
        }
        sort(directed.begin(),directed.end());
        auto unique=directed;unique.erase(std::unique(unique.begin(),unique.end()),unique.end());
        size_t reverse=0,ascending=0;
        for(auto edge:unique){reverse+=binary_search(unique.begin(),unique.end(),make_pair(edge.second,edge.first));ascending+=edge.first<edge.second;}
        vector<pair<uint32_t,uint32_t>> edges=unique;
        for(auto& edge:edges)if(edge.first>edge.second)swap(edge.first,edge.second);
        sort(edges.begin(),edges.end());edges.erase(std::unique(edges.begin(),edges.end()),edges.end());
        vector<vector<uint32_t>> adjacency(maximum+1);
        for(auto edge:edges){adjacency[edge.first].push_back(edge.second);adjacency[edge.second].push_back(edge.first);}
        vector<int8_t> color(maximum+1,-1);size_t components=0;uint32_t sides[2]={0,0};
        vector<uint32_t> mapping(maximum+1);
        for(uint32_t v=0;v<=maximum;++v)if(!adjacency[v].empty()&&color[v]<0) {
            ++components;queue<uint32_t> todo;todo.push(v);color[v]=0;
            while(!todo.empty()){
                auto u=todo.front();todo.pop();mapping[u]=sides[color[u]]++;
                for(auto w:adjacency[u]) {
                    if(color[w]<0){color[w]=1-color[u];todo.push(w);}
                    else if(color[w]==color[u])throw runtime_error("raw common-ID graph is not bipartite");
                }
            }
        }
        ofstream output(argv[2]);output<<"% bip unweighted\n";
        for(auto edge:edges){if(color[edge.first])swap(edge.first,edge.second);output<<mapping[edge.first]<<' '<<mapping[edge.second]<<'\n';}
        ofstream report(argv[3]);
        report<<"{\"input_rows\":"<<directed.size()<<",\"distinct_directed_pairs\":"<<unique.size()
              <<",\"pairs_with_reverse\":"<<reverse<<",\"ascending_pairs\":"<<ascending
              <<",\"undirected_edges\":"<<edges.size()<<",\"active_left\":"<<sides[0]<<",\"active_right\":"<<sides[1]
              <<",\"components\":"<<components<<",\"bipartite\":true,\"conversion\":\"common vertex IDs; deduplicate undirected edges; BFS two-color then map each partition separately\"}\n";
        if(!output||!report)throw runtime_error("write failure");
        cout<<"NORMALIZE82_PASS rows="<<directed.size()<<" reverse="<<reverse<<" edges="<<edges.size()<<endl;
    }catch(const exception& e){cerr<<"NORMALIZE82_FAIL "<<e.what()<<endl;return 1;}
}
