import csv
import gzip
import hashlib
import json
import math
import statistics as st
import sys
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
METHODS=['BM','SA','SAP','SAP+']

def rows(path):
    with path.open() as f:return list(csv.DictReader(f,delimiter='\t'))

def write(path,data):
    if not data:return
    with path.open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)

def stats(values):
    values=sorted(values);a=(len(values)-1)*.99;i=int(a)
    return dict(mean=st.mean(values),geometric_mean=math.exp(st.mean(map(math.log,values))) if min(values)>0 else 0,
                median=st.median(values),p99=values[i]+(values[min(i+1,len(values)-1)]-values[i])*(a-i),maximum=max(values))

def event_medians(data,method=None):
    groups=defaultdict(list);pairs={}
    for r in data:
        if method and r['method']!=method:continue
        k=int(r['event_id']);groups[k].append(float(r['time_ms']))
        pair=tuple(sorted((int(r['u']),int(r['v']))))
        assert pairs.get(k,pair)==pair;pairs[k]=pair
    assert len(groups)==500
    return {k:st.median(v) for k,v in groups.items()},pairs

def main():
    run=Path(sys.argv[1]).resolve();out=run/'summary';out.mkdir(exist_ok=True)
    timing=[];top=[];ratios=[];all_candidates=[];mechanisms=[];tiers=[];queries=[];query_ratios=[];fixed=[];resources=[];checks=[]
    refs=json.loads((ROOT/'data/reference/manifest.json').read_text())
    inputs=json.loads((ROOT/'data/inputs.json').read_text())
    datasets={item['code']:item['dataset'] for item in inputs}
    codes={item['dataset']:item['code'] for item in inputs}
    for folder in sorted(run.iterdir()):
        if not folder.is_dir() or not (folder/'status.json').exists():continue
        status=json.loads((folder/'status.json').read_text());assert status['failures']==0
        checks.append(dict(configuration=folder.name,status=status))
        if folder.name.endswith('_time'):
            exp,ds,dr,_=folder.name.split('_');raw=rows(folder/'events.tsv')
            ref=next(r for r in refs if r['experiment']==exp and r['dataset']==datasets.get(ds,ds) and r['direction']==dr)
            path=ROOT/ref['file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==ref['sha256']
            base,pairs=event_medians(rows(path));values={'Baseline':base}
            for m in METHODS:
                values[m],current=event_medians(raw,m);assert current==pairs
            ranked=sorted(base,key=base.get,reverse=True)[:10]
            for m,v in values.items():
                timing.append(dict(experiment=exp,dataset=ds,direction=dr,method=m,**stats(v.values())))
                top.append(dict(experiment=exp,dataset=ds,direction=dr,method=m,mean_ms=st.mean(v[k] for k in ranked)))
            means={m:st.mean(v.values()) for m,v in values.items()}
            for previous,current in zip(['Baseline']+METHODS,METHODS):
                ratios.append(dict(experiment=exp,dataset=ds,direction=dr,previous=previous,method=current,
                                   adjacent_speedup=means[previous]/means[current],baseline_speedup=means['Baseline']/means[current]))
            if exp=='E1':
                costs=0.;n=0;accepted=[]
                detector=ROOT/f'data/detection/{codes.get(ds,ds)}_{dr[:3]}.txt'
                if not detector.exists():detector=detector.with_suffix('.txt.gz')
                opener=gzip.open if detector.suffix=='.gz' else open
                with opener(detector,'rt') as stream:
                    for line in stream:
                        if not line.strip() or line.startswith('#'):continue
                        u,v,flag,cost=line.split();n+=1;costs+=float(cost)
                        if flag=='0':accepted.append(tuple(sorted((int(u),int(v)))))
                assert accepted==[pairs[k] for k in range(500)]
                totals={m:costs/n+sum(v.values())/n for m,v in values.items()}
                for m in values:
                    all_candidates.append(dict(dataset=ds,direction=dr,method=m,candidates=n,detector_mean_ms=costs/n,
                        weighted_maintenance_ms=sum(values[m].values())/n,aggregate_mean_ms=totals[m],baseline_speedup=totals['Baseline']/totals[m]))
                count_folder=run/f'E1_{ds}_{dr}_count'
                if not (count_folder/'status.json').exists():continue
                counted=rows(count_folder/'counts.tsv');counts=defaultdict(list)
                candidate={}
                for r in counted:
                    counts[r['method'],r['metric']].append(int(r['value']))
                    metric='candidates' if dr=='insert' else 'checkedPairs' if r['method']=='SAP+' else 'C'
                    if r['metric']==metric:candidate[r['method'],int(r['event_id'])]=int(r['value'])
                for (m,metric),v in counts.items():mechanisms.append(dict(dataset=ds,direction=dr,method=m,metric=metric,mean=st.mean(v)))
                buckets=defaultdict(list)
                for k,v in values['SAP+'].items():
                    c=candidate['SAP+',k];label='0-10' if c<=10 else '11-100' if c<=100 else '101-1000' if c<=1000 else '>1000'
                    buckets[label].append(v)
                for label,v in buckets.items():tiers.append(dict(dataset=ds,direction=dr,group=label,events=len(v),time_share=sum(v)/sum(values['SAP+'].values()),**stats(v)))
        elif folder.name.startswith('index_'):
            _,ds,dr=folder.name.split('_');group=defaultdict(list)
            for r in rows(folder/'queries.tsv'):group[int(r['step']),r['kind'],int(r['query'])].append(float(r['time_ms'])*1000)
            sets=defaultdict(list)
            for (step,kind,q),v in group.items():assert len(v)==3;sets[step,kind].append(st.median(v))
            for (step,kind),v in sets.items():queries.append(dict(dataset=ds,direction=dr,step=step,kind=kind,unit='microseconds',**stats(v)))
            structures=rows(folder/'structures.tsv')
            for step in sorted({key[0] for key in sets}):
                m=next(r for r in structures if int(r['step'])==step and r['kind']=='maintained')
                r=next(r for r in structures if int(r['step'])==step and r['kind']=='rebuilt')
                query_ratios.append(dict(dataset=ds,direction=dr,step=step,
                    mean_time_ratio=st.mean(sets[step,'maintained'])/st.mean(sets[step,'rebuilt']),
                    blooms_ratio=int(m['blooms'])/int(r['blooms']),paths_ratio=int(m['paths'])/int(r['paths']),
                    capacity_ratio=int(m['index_requested_capacity_bytes'])/int(r['index_requested_capacity_bytes'])))
        elif folder.name.startswith('fixed_vertex_'):
            groups=defaultdict(list)
            for r in rows(folder/'events.tsv'):groups[int(r['event'])].append(float(r['time_ms']))
            assert len(groups)==1000 and all(len(v)==3 for v in groups.values()) and status['full_static_checkpoints']==5
            structures=rows(folder/'structures.tsv');last={r['kind']:r for r in structures if r['step']=='1000'}
            fixed.append(dict(dataset=folder.name.split('_')[-1],butterfly_changing_events=status['butterfly_changing_events'],
                final_mean_visit_ratio=float(last['maintained']['mean_path_visits'])/float(last['rebuilt']['mean_path_visits']),
                static_checkpoints=status['full_static_checkpoints'],**stats(st.median(v) for v in groups.values())))
        elif folder.name.startswith(('memory_','allocation_','alloc_')):
            raw=rows(folder/'events.tsv');assert len(raw)==500
            cap=rows(folder/'capacities.tsv')
            allocation=folder.name.startswith(('allocation_','alloc_'))
            resources.append(dict(configuration=folder.name,measurement='allocation' if allocation else 'rss',
                mean_peak_rss_mib=None if allocation else st.mean(float(r['peak_rss_kib']) for r in raw)/1024,
                mean_index_capacity_mib=st.mean(float(r['index_peak_bytes']) for r in cap)/1024**2 if allocation else None,
                mean_h_capacity_mib=st.mean(float(r['h_peak_bytes']) for r in cap)/1024**2 if allocation else None,
                initialization_ms=status['initialization_total_ms'],index_ms=status['index_ms'],peel_ms=status['peel_ms']))
    for name,data in [('timing',timing),('top10',top),('speedups',ratios),('all_candidates',all_candidates),('mechanisms',mechanisms),('event_groups',tiers),('queries',queries),('query_ratios',query_ratios),('fixed_vertex',fixed),('resources',resources)]:write(out/(name+'.csv'),data)
    (out/'validation.json').write_text(json.dumps(checks,indent=2)+'\n')
    print('Summarized',len(checks),'successful configurations; baseline timings are archived references.')

if __name__=='__main__':main()
