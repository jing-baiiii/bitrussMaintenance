"""Split a release by dataset while preserving paths relative to the root."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser(description='Package the code and datasets separately')
    parser.add_argument('output', type=Path)
    parser.add_argument('--part-mib', type=int, default=20, help='Split large archives into parts of this size in MiB (default: 20)')
    args = parser.parse_args()
    if args.part_mib < 1:
        parser.error('part size must be positive')
    output = args.output.resolve()
    if output == ROOT or ROOT in output.parents:
        parser.error('archive output directory must be outside github_release')
    output.mkdir(parents=True, exist_ok=False)
    groups = {'code': []}
    for source in sorted(ROOT.rglob('*')):
        if not source.is_file():
            continue
        relative = source.relative_to(ROOT)
        if relative.parts[0] == 'build' or '__pycache__' in relative.parts or source.suffix == '.pyc':
            continue
        if relative.parts[0] != 'data':
            group = 'code'
        elif relative.parts[1] == 'datasets' and relative.parts[2] == 'full':
            group = source.stem
        elif relative.parts[1] == 'datasets' and relative.parts[2] == 'scale':
            group = source.stem.replace('_normalized', '')
        else:
            group = 'data_support'
        groups.setdefault(group, []).append(source)
    packages = []
    for group, sources in groups.items():
        target = output / f'{group}.zip'
        with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for source in sources:
                archive.write(source, source.relative_to(ROOT))
        with zipfile.ZipFile(target) as archive:
            if archive.testzip() is not None:
                raise RuntimeError('archive checksum validation failed: ' + target.name)
        record = dict(file=target.name, bytes=target.stat().st_size,
                      sha256=hashlib.sha256(target.read_bytes()).hexdigest())
        if target.stat().st_size > args.part_mib * 1024 * 1024:
            parts = []
            with target.open('rb') as stream:
                while block := stream.read(args.part_mib * 1024 * 1024):
                    part = output / (target.name + f'.part{len(parts) + 1:03d}')
                    part.write_bytes(block)
                    parts.append(dict(file=part.name, bytes=len(block),
                                      sha256=hashlib.sha256(block).hexdigest()))
            record['parts'] = parts
            target.unlink()
        packages.append(record)
    (output / 'packages.json').write_text(json.dumps(packages, ensure_ascii=False, indent=2) + '\n')
    (output / 'README.txt').write_text(
        'All files preserve paths relative to the release root.\n'
        'Extract regular ZIP files into the same root directory. Merge split parts by number before extraction.\n'
        'Linux example: cat data_support.zip.part* > data_support.zip\n'
        'Windows Command Prompt example: copy /b data_support.zip.part* data_support.zip\n'
        'After merging, the SHA-256 must match the corresponding value in packages.json.\n'
        'Uploading a ZIP does not expand source files on GitHub; extract it before uploading files for web browsing.\n')
    print(json.dumps(packages, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
