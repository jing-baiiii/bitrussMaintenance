"""Recompute submitted table outputs using only packaged records; no timing runs."""
import csv
import gzip
import hashlib
import json
import math
import re
import statistics as st
from collections import defaultdict
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PAPER = ROOT / 'data/results/paper'
PROV = ROOT / 'data/results/provenance'
OUT = ROOT / 'data/results/tables'
NAMES = dict(zip(['recordlabel', 'starring', 'youtube', 'github', 'team', 'actor-movie', 'imdb', 'WK', 'dblp'],
                 ['DR', 'DS', 'YT', 'GH', 'DT', 'AM', 'ID', 'WK', 'DB']))
METHODS = ['BAI', 'BM', 'SA', 'SAP', 'SAP+']
DIRECTIONS = ['insert', 'delete']
TABLE_MAP = {r['name']: r for r in json.loads((PROV / 'table_map.json').read_text())}
REPORT = []


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(path, delimiter='\t'):
    with path.open() as f:
        return list(csv.DictReader(f, delimiter=delimiter))


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(data[0]))
        w.writeheader()
        w.writerows(data)


def stats(values):
    v = sorted(values)
    at = (len(v) - 1) * .99
    i = int(at)
    return dict(mean=st.mean(v), geometric_mean=math.exp(st.mean(map(math.log, v))) if min(v) > 0 else 0,
                median=st.median(v), p99=v[i] + (v[min(i + 1, len(v) - 1)] - v[i]) * (at - i), maximum=max(v))


def event_medians(raw, method=None):
    groups, pairs, repeats = defaultdict(list), {}, defaultdict(set)
    for r in raw:
        if method and r['method'] != method:
            continue
        i = int(r['event_id'])
        pair = tuple(sorted((int(r['u']), int(r['v']))))
        assert pairs.get(i, pair) == pair
        pairs[i] = pair
        groups[i].append(float(r['time_ms']))
        repeats[i].add(r['replicate'])
    assert set(groups) == set(range(500))
    assert all(len(v) == 3 for v in groups.values()) and all(len(v) == 3 for v in repeats.values())
    return {i: st.median(v) for i, v in groups.items()}, pairs


def numeric_rows(path):
    result = []
    for line in path.read_text().splitlines():
        if '&' not in line or not re.search(r'\\textsf\{(?:DR|DS|YT|GH|DT|AM|ID|WK|DB)\}|^(?:DR|DS|YT|GH|DT|AM|ID|WK|DB|GM)\s*&|^\s*&\s*Rebuilt', line):
            continue
        values = []
        for cell in line.split('&')[1:]:
            cell = re.sub(r'\\mathrm\{e\}\{(-?\d+)\}', r'e\1', cell)
            cell = cell.replace(',', '').replace('$', '').replace('\\', '').strip()
            if not cell or not re.fullmatch(r'[\d.eE+()/ %\-]+', cell):
                continue
            for match in re.finditer(r'\d+(?:\.\d+)?(?:e[+-]?\d+)?', cell):
                token = match[0]
                mantissa, _, exponent = token.lower().partition('e')
                decimals = len(mantissa.partition('.')[2])
                tolerance = .50001 * 10 ** (int(exponent or 0) - decimals) if '.' in mantissa or exponent else 1e-8
                values.append((float(token), tolerance, token))
        result.append(values)
    return result


def save(name, data, displayed, sources, version, note=''):
    entry = TABLE_MAP[name]
    folder = ROOT / entry['directory']
    snapshot = folder / 'submitted_table.tex'
    assert sha(snapshot) == entry['snapshot_sha256']
    expected = numeric_rows(snapshot)
    errors = []
    if len(expected) != len(displayed):
        errors.append(f'Row count: manuscript {len(expected)}, recomputed {len(displayed)}')
    compared = 0
    for i, (cells, computed) in enumerate(zip(expected, displayed), 1):
        if len(cells) != len(computed):
            errors.append(f'Row {i} numeric cell count: manuscript {len(cells)}, recomputed {len(computed)}')
            continue
        for j, ((value, tolerance, token), actual) in enumerate(zip(cells, computed), 1):
            compared += 1
            if abs(value - actual) > tolerance + abs(actual) * 1e-12:
                errors.append(f'Row {i}, cell {j}: manuscript {token}, recomputed {actual}')
    write(folder / 'result.csv', data)
    unique = sorted(set(sources) | {snapshot})
    bindings = [dict(file=str(p.relative_to(ROOT)), sha256=sha(p)) for p in unique]
    evidence = dict(table=entry['table'], name=name, version=version, note=note,
                    sources=bindings, rows=len(data), compared_numeric_cells=compared,
                    submitted_display_matches=not errors, errors=errors)
    (folder / 'sources.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n')
    latest_matches = not errors
    if name == 'top10':
        lookup = {(r['dataset'], r['direction'], r['method']): r for r in data}
        lines = []
        for line in snapshot.read_text().splitlines():
            match = re.search(r'\\textsf\{(DR|DS|YT|GH|DT|AM|ID|WK|DB)\}\s*&\s*(Ins\.|Del\.)', line)
            if match:
                code, dr = match[1], 'insert' if match[2] == 'Ins.' else 'delete'
                cells = [f'{lookup[code, dr, "BAI"]["mean_ms"]:.2f}']
                cells += [f'{lookup[code, dr, m]["mean_ms"]:.2f}/{lookup[code, dr, m]["previous_method_speedup"]:.2f}' for m in METHODS[1:]]
                line = '\\textsf{' + code + '} & ' + match[2] + ' & ' + ' & '.join(cells) + r'\\'
            lines.append(line)
        latest = folder / 'latest_table.tex'
        latest.write_text('\n'.join(lines) + '\n')
        latest_rows = numeric_rows(latest)
        latest_matches = len(latest_rows) == len(displayed) and all(
            len(a) == len(b) and all(abs(v - x) <= t + abs(x) * 1e-12 for (v, t, _), x in zip(a, b))
            for a, b in zip(latest_rows, displayed))
        evidence['latest_table'] = str(latest.relative_to(ROOT))
        evidence['latest_display_matches'] = latest_matches
        (folder / 'sources.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n')
    REPORT.append(dict(table=entry['table'], name=name, version=version, rows=len(data),
                       result=str((folder / 'result.csv').relative_to(ROOT)),
                       sources=str((folder / 'sources.json').relative_to(ROOT)),
                       compared_numeric_cells=compared, display_matches=not errors, latest_display_matches=latest_matches))
    if errors:
        print(entry['table'], name, *errors[:8], sep='\n')


def main():
    timing_sources, count_sources, detection_sources = [], [], []
    T, E, W, impact, detectors, all_costs, accepted = {}, {}, {}, {}, [], [], {}
    references = json.loads((ROOT / 'data/reference/manifest.json').read_text())
    time_rows, scale_rows = [], []
    for ref in references:
        ds, dr, exp = ref['dataset'], ref['direction'], ref['experiment']
        path = ROOT / ref['file']
        assert sha(path) == ref['sha256']
        values, pairs = event_medians(read(path))
        E[ds, dr, 'BAI'] = values
        T[ds, dr, 'BAI'] = stats(values.values())
        folder = PAPER / f'{exp}_{ds}_{dr}_time'
        raw = read(folder / 'events.tsv')
        assert json.loads((folder / 'status.json').read_text())['failures'] == 0
        for m in METHODS[1:]:
            values, current = event_medians(raw, m)
            assert pairs == current
            E[ds, dr, m], T[ds, dr, m] = values, stats(values.values())
        dest = time_rows if exp == 'E1' else scale_rows
        for m in METHODS:
            dest.append(dict(dataset=NAMES.get(ds, ds), direction=dr, method=m, unit='ms', **T[ds, dr, m]))
        if exp != 'E1':
            continue
        timing_sources += [path, folder / 'events.tsv', folder / 'input.json', folder / 'status.json']
        by_id = {int(r['event_id']): r for r in raw if r['method'] == 'SAP+'}
        impact[ds, dr] = sum(int(r['changed_edges']) > (1 if dr == 'insert' else 0) for r in by_id.values()) / 5
        counter = PAPER / f'E1_{ds}_{dr}_count'
        assert json.loads((counter / 'status.json').read_text())['failures'] == 0
        count_sources += [counter / name for name in ('counts.tsv', 'events.tsv', 'status.json', 'input.json')]
        for r in read(counter / 'counts.tsv'):
            key = ds, dr, r['method'], int(r['event_id']), r['metric']
            assert key not in W
            W[key] = int(r['value'])
        metric = 'candidates' if dr == 'insert' else 'C'
        assert all(W[ds, dr, 'BM', i, metric] == W[ds, dr, 'SA', i, metric] for i in range(500))
        path = ROOT / f'data/detection/{NAMES[ds]}_{dr[:3]}.txt'
        if not path.exists():
            path = path.with_suffix('.txt.gz')
        detection_sources.append(path)
        n, costs, sequence = [0, 0], [Decimal(0), Decimal(0)], []
        opener = gzip.open if path.suffix == '.gz' else open
        with opener(path, 'rt') as f:
            for line in f:
                if not line.strip() or line.startswith('#'):
                    continue
                u, v, flag, elapsed = line.split()
                flag = int(flag)
                assert flag in (0, 1) and Decimal(elapsed) >= 0
                n[flag] += 1
                costs[flag] += Decimal(elapsed)
                if flag == 0:
                    sequence.append(tuple(sorted((int(u), int(v)))))
        assert n[0] == 500 and sequence == [pairs[i] for i in range(500)]
        total, detection = sum(n), float(sum(costs)) / sum(n)
        accepted[ds, dr] = 500 / total * 100
        totals = {m: detection + sum(E[ds, dr, m].values()) / total for m in METHODS}
        detectors.append(dict(dataset=NAMES[ds], direction=dr, candidates=total, nontrivial=500, trivial=n[1],
                              accept_percent=500 / total * 100, detector_total_ms=str(sum(costs)),
                              detector_mean_ms=detection, trivial_contribution_ms=float(costs[1]) / total,
                              nontrivial_contribution_ms=float(costs[0]) / total,
                              sap_plus_detector_share_percent=100 * detection / totals['SAP+']))
        for m in METHODS:
            all_costs.append(dict(dataset=NAMES[ds], direction=dr, method=m, candidates=total,
                                  detector_mean_ms=detection, maintenance_total_ms=sum(E[ds, dr, m].values()),
                                  weighted_maintenance_ms=sum(E[ds, dr, m].values()) / total,
                                  aggregate_mean_ms=totals[m], baseline_speedup=totals['BAI'] / totals[m]))
    def count(ds, dr, m, metric):
        return st.mean(W[ds, dr, m, i, metric] for i in range(500))
    def speed(ds, dr, first, second):
        return T[ds, dr, first]['mean'] / T[ds, dr, second]['mean']
    def gm(values):
        return math.exp(st.mean(map(math.log, values)))

    static = PROV / 'submitted_dataset_statistics.csv'
    dataset_rows = read(static, ',')
    save('datasets', dataset_rows, [[int(v) for k, v in r.items() if k != 'dataset'] for r in dataset_rows],
         [static], 'Static graph statistics', 'phi_mean_displayed follows the precision shown in the manuscript table.')
    acceptance = [dict(dataset=NAMES[ds], direction=dr, accept_percent=accepted[ds, dr],
                       changed_existing_edge_percent=impact[ds, dr]) for ds in NAMES for dr in DIRECTIONS]
    display = [[accepted[ds, dr] for dr in DIRECTIONS] + [impact[ds, dr] for dr in DIRECTIONS] for ds in NAMES]
    save('acceptance', acceptance, display, timing_sources + detection_sources, 'Timing outputs and frozen candidate-detection records')
    speedups, display = [], []
    for dr in DIRECTIONS:
        for ds in NAMES:
            vals = [speed(ds, dr, 'BAI', m) for m in METHODS[1:]]
            display.append(vals)
            speedups += [dict(dataset=NAMES[ds], direction=dr, method=m, speedup=v) for m, v in zip(METHODS[1:], vals)]
        vals = [gm([speed(ds, dr, 'BAI', m) for ds in NAMES]) for m in METHODS[1:]]
        display.append(vals)
        speedups += [dict(dataset='GM', direction=dr, method=m, speedup=v) for m, v in zip(METHODS[1:], vals)]
    save('speedup', speedups, display, timing_sources, 'Proposed-method timing outputs and Bai baseline records')
    for dr in DIRECTIONS:
        display = []
        for methods in [['BAI'], ['BM', 'SA'], ['SAP', 'SAP+']]:
            display += [[v for m in methods for v in T[ds, dr, m].values()] for ds in NAMES]
        save('time_' + dr, [r for r in time_rows if r['direction'] == dr], display,
             [p for p in timing_sources if f'_{dr}_' in str(p)], 'Proposed-method timing outputs and Bai baseline records',
             'Three repetitions are reduced to a median per event; five statistics are computed over 500 events. P99 uses linear interpolation. Unit: milliseconds.')
    ac = {(r['dataset'], r['direction'], r['method']): r for r in all_costs}
    dc = {(r['dataset'], r['direction']): r for r in detectors}
    display = []
    for dr in DIRECTIONS:
        for ds in NAMES.values():
            display.append([dc[ds, dr]['detector_mean_ms']] + [ac[ds, dr, m]['aggregate_mean_ms'] for m in METHODS]
                           + [ac[ds, dr, 'SAP+']['baseline_speedup']])
    save('all_candidates', all_costs, display, timing_sources + detection_sources, 'All-candidate two-stage workflow estimate',
         '(sum of detection times for all legal candidates + sum of maintenance times for 500 accepted events) / number of legal candidates; aggregate_mean_ms is the estimated cost and baseline_speedup is the corresponding cost ratio.')

    work_sources, closure, display = [], [], []
    records = json.loads((ROOT / 'data/reference/resource_work_manifest.json').read_text())
    ops = {(r['dataset'], r['direction']): r for r in records if r['mode'] == 'ops'}
    for ds in NAMES:
        numbers = []
        for dr, site in [('insert', 1), ('delete', 15)]:
            folder = ROOT / ops[ds, dr]['folder']
            work_sources += [folder / f for f in ('counts.tsv', 'events.tsv', 'status.json', 'historical_record.json')]
            by = defaultdict(list)
            for r in read(folder / 'counts.tsv'):
                by[r['metric']].append(int(r['value']))
            hit, miss = [st.mean(by[f'closure_{metric}_site{site}_total']) for metric in ('hit', 'miss')]
            numbers += [hit + miss, 100 * miss / (hit + miss)]
            closure.append(dict(dataset=NAMES[ds], direction=dr, native_site=site, mean_hit=hit, mean_miss=miss,
                                mean_lookups=hit + miss, miss_percent=100 * miss / (hit + miss)))
        display.append(numbers)
    save('closure', closure, display, work_sources, 'Bai baseline operation counts', 'Insertion uses native site 1 and deletion uses native site 15; values are checked against the submitted table.')
    algebra, pruning, persistent, ad, pd, hd = [], [], [], [], [], []
    for dr in DIRECTIONS:
        for ds, code in NAMES.items():
            bm, sa = ('pathPairProbes', 'algebraReads') if dr == 'insert' else ('supportScans', 'supportScans')
            vals = [count(ds, dr, 'BM', bm), count(ds, dr, 'SA', sa)]
            vals += [T[ds, dr, m][stat] for stat in ('mean', 'p99') for m in ('BM', 'SA')]
            algebra.append(dict(zip(['dataset', 'direction', 'bm_work', 'sa_work', 'bm_mean_ms', 'sa_mean_ms', 'bm_p99_ms', 'sa_p99_ms'], [code, dr] + vals)))
            ad.append(vals)
            c, scan = ('candidates', 'supportWedgeScans') if dr == 'insert' else ('C', 'supportScans')
            vals = [count(ds, dr, 'SA', c) / count(ds, dr, 'SAP', c), count(ds, dr, 'SA', scan) / count(ds, dr, 'SAP', scan)]
            filter_value = count(ds, dr, 'SAP', 'pruningMemberships') if dr == 'delete' else None
            tail = [T[ds, dr, m]['mean'] for m in ('SA', 'SAP')] + [speed(ds, dr, 'SA', 'SAP')]
            pruning.append(dict(zip(['dataset', 'direction', 'candidate_ratio', 'scan_ratio', 'filter_memberships', 'sa_mean_ms', 'sap_mean_ms', 'speedup'], [code, dr] + vals + [filter_value] + tail)))
            pd.append(vals + ([filter_value] if filter_value is not None else []) + tail)
            if dr == 'insert':
                pairs = [('SAP', 'supportInitializations'), ('SAP+', 'supportInitializations'), ('SAP', 'supportWedgeScans'),
                         ('SAP+', 'supportWedgeScans'), ('SAP+', 'hWedgeScans')]
                vals = [count(ds, dr, m, metric) for m, metric in pairs]
                vals.append(count(ds, dr, 'SAP+', 'hInitialWrites') + count(ds, dr, 'SAP+', 'hPromotionWrites'))
                keys = ['sap_temp_init', 'sap_plus_temp_init', 'sap_temp_scan', 'sap_plus_temp_scan', 'promotion_scan', 'h_increments']
            else:
                pairs = [('SAP', 'supportInitializations'), ('SAP', 'supportScans'), ('SAP+', 'initialScans'),
                         ('SAP+', 'cascadeScans'), ('SAP+', 'recomputeScans'), ('SAP+', 'recomputeWrites')]
                vals = [count(ds, dr, m, metric) for m, metric in pairs]
                keys = ['sap_temp_init', 'sap_temp_scan', 'event_scan', 'cascade_scan', 'rebuild_scan', 'rebuild_writes']
            persistent += [dict(dataset=code, direction=dr, metric=k, mean_count=v) for k, v in zip(keys, vals)]
            hd.append(vals)
    save('algebra', algebra, ad, count_sources + timing_sources, 'Formal operation counts and timing')
    save('pruning', pruning, pd, count_sources + timing_sources, 'Formal operation counts and timing')
    save('persistent', persistent, hd, count_sources, 'Formal operation counts', 'SAP+ deletion reuses persistent support; structural-zero fields are identified in the metric definitions.')
    top, detail, display, tiers, td = [], [], [], [], []
    for ds, code in NAMES.items():
        for dr in DIRECTIONS:
            selected = sorted(E[ds, dr, 'BAI'], key=E[ds, dr, 'BAI'].get, reverse=True)[:10]
            means = {m: st.mean(E[ds, dr, m][i] for i in selected) for m in METHODS}
            numbers = [means['BAI']]
            for j, m in enumerate(METHODS):
                ratio = means[METHODS[j - 1]] / means[m] if j else None
                top.append(dict(dataset=code, direction=dr, method=m, mean_ms=means[m], previous_method_speedup=ratio))
                if j:
                    numbers += [means[m], ratio]
                detail += [dict(dataset=code, direction=dr, rank=rank, event_id=i, method=m,
                                event_median_ms=E[ds, dr, m][i]) for rank, i in enumerate(selected, 1)]
            display.append(numbers)
    save('top10', top, display, timing_sources, 'Proposed-method timing outputs ranked by Bai baseline cost', 'All five methods use the same ten event IDs for each graph and direction. Selected IDs and event medians are in selected_events.csv.')
    write(ROOT / TABLE_MAP['top10']['directory'] / 'selected_events.csv', detail)
    for dr in DIRECTIONS:
        for ds, code in NAMES.items():
            groups = [[] for _ in range(4)]
            for i in range(500):
                c = W[ds, dr, 'SAP+', i, 'candidates' if dr == 'insert' else 'checkedPairs']
                groups[0 if c <= 10 else 1 if c <= 100 else 2 if c <= 1000 else 3].append(i)
            nums = []
            total = sum(E[ds, dr, 'SAP+'].values())
            for label, group in zip(['0-10', '11-100', '101-1000', '>1000'], groups):
                percent, share = len(group) / 5, 100 * sum(E[ds, dr, 'SAP+'][i] for i in group) / total
                tiers.append(dict(dataset=code, direction=dr, group=label, events=len(group), event_percent=percent, time_share_percent=share))
                if group:
                    nums += [percent, share]
            td.append(nums)
    save('tiers', tiers, td, count_sources + timing_sources, 'Formal operation counts and timing', 'The first manuscript bin, C <= 10, includes events with zero candidates.')

    resources, prep, rd, ip, resource_sources = [], [], [], [], []
    for ds, code in NAMES.items():
        bai = ROOT / next(r['folder'] for r in records if r['mode'] == 'rss' and r['dataset'] == ds)
        memory, alloc = PAPER / f'memory_{ds}_insert', PAPER / f'alloc_{ds}_insert'
        paths = [bai / 'events.tsv', bai / 'status.json', bai / 'historical_record.json', memory / 'events.tsv',
                 memory / 'status.json', memory / 'input.json', alloc / 'capacities.tsv', alloc / 'status.json', alloc / 'input.json']
        resource_sources += paths
        bs, ms = [json.loads((p / 'status.json').read_text()) for p in (bai, memory)]
        rss = []
        for p in (bai, memory):
            peaks = [int(r['peak_rss_kib']) / 1024 for r in read(p / 'events.tsv')]
            assert len(peaks) == 500
            rss.extend([st.mean(peaks), max(peaks)])
        allocated = read(alloc / 'capacities.tsv')
        caps = [st.mean(int(r[key]) for r in allocated) / 1024 ** 2 for key in ('index_peak_bytes', 'h_peak_bytes')]
        vals = rss + caps
        resources.append(dict(zip(['dataset', 'bai_rss_mib', 'bai_rss_max_mib', 'sap_plus_rss_mib', 'sap_plus_rss_max_mib', 'index_capacity_mib', 'h_capacity_mib'], [code] + vals)))
        rd.append(vals)
        vals = [bs['initialization_total_ms'] / 1000, ms['initialization_total_ms'] / 1000, ms['index_ms'] / 1000, ms['peel_ms'] / 1000]
        prep.append(dict(zip(['dataset', 'bai_total_s', 'sap_plus_total_s', 'index_build_s', 'static_peel_s'], [code] + vals)))
        ip.append(vals)
    save('memory', resources, rd, resource_sources, 'Proposed-method measurements and Bai baseline records', 'RSS reports the mean and maximum of 500 event peaks under the independent-insertion protocol; index and h capacities are reported from allocation measurements.')
    save('preparation', prep, ip, resource_sources, 'Proposed-method measurements and Bai baseline records', 'One observation per configuration. Unit: seconds.')

    query_sources, stability, sd, query_stats = [], [], [], []
    for dr in DIRECTIONS:
        for ds, code in NAMES.items():
            folder = PAPER / f'index_{ds}_{dr}'
            query_sources += [folder / name for name in ('queries.tsv', 'structures.tsv', 'status.json', 'input.json')]
            status = json.loads((folder / 'status.json').read_text())
            assert status['failures'] == 0 and status['checkpoint_full_static_checks'] == 4
            groups = defaultdict(list)
            for r in read(folder / 'queries.tsv'):
                groups[int(r['step']), r['kind'], int(r['query'])].append(r)
            by_step = defaultdict(list)
            for (step, kind, q), rows in groups.items():
                assert len(rows) == 3 and {r['repeat'] for r in rows} == {'0', '1', '2'}
                assert len({(r['u'], r['v'], r['path_visits'], r['membership_slots']) for r in rows}) == 1
                by_step[step, kind].append((st.median(float(r['time_ms']) * 1000 for r in rows), int(rows[0]['path_visits'])))
            for (step, kind), values in by_step.items():
                assert len(values) == 500
                query_stats.append(dict(dataset=code, direction=dr, step=step, kind=kind, queries=500,
                                        mean_path_visits=st.mean(v[1] for v in values), **stats(v[0] for v in values)))
            n = status['events']
            structures = {r['kind']: r for r in read(folder / 'structures.tsv') if int(r['step']) == n}
            vr = st.mean(v[1] for v in by_step[n, 'maintained']) / st.mean(v[1] for v in by_step[n, 'rebuilt'])
            qr = st.mean(v[0] for v in by_step[n, 'maintained']) / st.mean(v[0] for v in by_step[n, 'rebuilt'])
            for kind in ('maintained', 'rebuilt'):
                row = structures[kind]
                vals = [int(row['blooms']), int(row['paths']), int(row['index_requested_capacity_bytes']) / 1024 ** 2]
                sd.append(vals + ([vr, qr, 0] if kind == 'maintained' else []))
                stability.append(dict(dataset=code, direction=dr, events=n, kind=kind, blooms=vals[0], paths=vals[1], capacity_mib=vals[2],
                                      mean_visit_ratio=vr if kind == 'maintained' else None, mean_query_time_ratio=qr if kind == 'maintained' else None,
                                      failures=status['failures']))
    save('stability', stability, sd, query_sources, 'Formal accumulating-update experiment', 'Visits is the ratio of mean path visits over sampled queries. Query is the ratio of mean per-edge query medians over three repetitions.')
    lookup = {(r['dataset'], r['direction'], r['step'], r['kind']): r for r in query_stats}
    initial, display, ratios = [], [], defaultdict(list)
    for code in NAMES.values():
        nums = []
        for dr in DIRECTIONS:
            a, b = [lookup[code, dr, 0, k]['mean'] for k in ('maintained', 'rebuilt')]
            nums += [a, b, a / b]
            initial.append(dict(dataset=code, direction=dr, maintained_mean_us=a, rebuilt_mean_us=b, ratio=a / b))
            ratios[dr].append(a / b)
        display.append(nums)
    display.append([gm(ratios[dr]) for dr in DIRECTIONS])
    initial += [dict(dataset='GM', direction=dr, maintained_mean_us=None, rebuilt_mean_us=None, ratio=gm(ratios[dr])) for dr in DIRECTIONS]
    save('query_initial', initial, display, query_sources, 'Derived from query outputs', 'Unit: microseconds. Three repetitions are reduced to a median per query, followed by the mean over 500 edges; GM is the geometric mean across nine dataset ratios.')
    for dr in DIRECTIONS:
        data, display = [], []
        for code in NAMES.values():
            final = max(r['step'] for r in query_stats if r['dataset'] == code and r['direction'] == dr)
            for kind in ('maintained', 'rebuilt'):
                row = lookup[code, dr, final, kind]
                data.append(row)
                display.append([row[k] for k in ('mean', 'median', 'p99', 'maximum')])
        save('query_tail_' + dr, data, display, [p for p in query_sources if f'_{dr}/' in str(p)], 'Derived from query outputs', 'Unit: microseconds.')
    display = [[dc[code, dr][k] for k in ('candidates', 'accept_percent', 'trivial_contribution_ms', 'nontrivial_contribution_ms', 'sap_plus_detector_share_percent')]
               for dr in DIRECTIONS for code in NAMES.values()]
    save('all_candidate_detection', detectors, display, timing_sources + detection_sources, 'All-candidate detection records')
    incidence = []
    for r in dataset_rows:
        m, b = int(r['edges']), int(r['butterflies'])
        incidence.append(dict(dataset=r['dataset'], original_edges=m, butterflies=b, incidence_vertices=m + b, incidence_edges=4 * b))
    save('sun_incidence', incidence, [[r[k] for k in ('original_edges', 'butterflies', 'incidence_vertices', 'incidence_edges')] for r in incidence],
         [static], 'Analytical calculation', 'm+b and 4b count records in the explicit incidence representation.')
    fixed, display, fixed_sources = [], [], []
    for ds, code in NAMES.items():
        folder = ROOT / 'data/results/fixed_vertex' / ds
        fixed_sources += [folder / n for n in ('events.tsv', 'structures.tsv', 'status.json', 'samples_original.tsv')]
        status = json.loads((folder / 'status.json').read_text())
        assert status['events'] == 1000 and status['full_static_checkpoints'] == 5 and status['failures'] == 0
        groups = defaultdict(list)
        for r in read(folder / 'events.tsv'):
            groups[int(r['event'])].append(float(r['time_ms']))
        assert len(groups) == 1000 and all(len(v) == 3 for v in groups.values())
        summary = stats(st.median(v) for v in groups.values())
        pair = {r['kind']: r for r in read(folder / 'structures.tsv') if r['step'] == '1000'}
        ratio = float(pair['maintained']['mean_path_visits']) / float(pair['rebuilt']['mean_path_visits'])
        fixed.append(dict(dataset=code, fixed_left_vertex_original=status['fixed_left_vertex_original'], events=1000,
                          butterfly_changing_events=status['butterfly_changing_events'], final_mean_visit_ratio=ratio,
                          static_checkpoints=5, failures=0, **summary))
        display.append([status['butterfly_changing_events']] + [summary[k] for k in ('mean', 'median', 'p99', 'maximum')] + [ratio])
    save('fixed_vertex', fixed, display, fixed_sources, 'Formal nine-dataset concentrated-insertion experiment', 'The fixed-vertex sequence contains 1,000 events per dataset.')
    scale_dir = OUT / 'Figure_scalability'
    write(scale_dir / 'result.csv', scale_rows)
    bindings = []
    for ref in references:
        if ref['experiment'] == 'E5':
            folder = PAPER / f'E5_{ref["dataset"]}_{ref["direction"]}_time'
            for p in [ROOT / ref['file'], folder / 'events.tsv', folder / 'status.json', folder / 'input.json']:
                bindings.append(dict(file=str(p.relative_to(ROOT)), sha256=sha(p)))
    (scale_dir / 'sources.json').write_text(json.dumps(dict(version='Proposed-method timing outputs and Bai baseline records', sources=bindings), ensure_ascii=False, indent=2) + '\n')
    REPORT.sort(key=lambda r: list(TABLE_MAP).index(r['name']))
    write(OUT / 'index.csv', REPORT)
    (OUT / 'validation.json').write_text(json.dumps(dict(tables=len(REPORT),
        numeric_cells=sum(r['compared_numeric_cells'] for r in REPORT),
        all_display_matches=all(r['display_matches'] for r in REPORT),
        all_latest_display_matches=all(r['latest_display_matches'] for r in REPORT), results=REPORT), ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(dict(tables=len(REPORT), numeric_cells=sum(r['compared_numeric_cells'] for r in REPORT),
                          submitted_table_mismatches=[r['table'] for r in REPORT if not r['display_matches']],
                          all_latest_display_matches=all(r['latest_display_matches'] for r in REPORT)), ensure_ascii=False))
    raise SystemExit(not all(r['latest_display_matches'] for r in REPORT))


if __name__ == '__main__':
    main()
