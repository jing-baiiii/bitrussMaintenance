"""Validate packaged hashes, fixed events, and optional external graph inputs."""
import csv
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def digest(path, compressed=False):
    h = hashlib.sha256()
    opener = gzip.open if compressed else open
    with opener(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    errors = []
    manifest = ROOT / 'MANIFEST.sha256'
    for line in manifest.read_text().splitlines():
        expected, filename = line.split('  ', 1)
        path = ROOT / filename
        if not path.is_file() or digest(path) != expected:
            errors.append('missing file or checksum mismatch: ' + filename)
    inputs = json.loads((ROOT / 'data/inputs.json').read_text())
    external = []
    for item in inputs:
        graph = ROOT / item['graph']
        if not graph.is_file() and not item['bundled']:
            external.append(item['graph'])
        elif not graph.is_file() or digest(graph) != item['graph_sha256']:
            errors.append('invalid graph file: ' + item['graph'])
        for kind, filename in item['samples'].items():
            path = ROOT / filename
            if not path.is_file():
                errors.append('missing event file: ' + filename)
                continue
            events = [line for line in path.read_text().splitlines()
                      if line.strip() and not line.startswith(('#', '%'))]
            if len(events) != 500 or digest(path) != item['samples_sha256'][kind]:
                errors.append('event count or checksum mismatch: ' + filename)
    references = json.loads((ROOT / 'data/reference/manifest.json').read_text())
    for item in references:
        path = ROOT / item['file']
        if digest(path) != item['sha256']:
            errors.append('Bai reference checksum mismatch: ' + item['file'])
        with path.open() as stream:
            rows = list(csv.DictReader(stream, delimiter='\t'))
        if len(rows) != 1500 or len({row['event_id'] for row in rows}) != 500:
            errors.append('Bai reference event-count mismatch: ' + item['file'])
    for item in json.loads((ROOT / 'data/detection/provenance.json').read_text()):
        path = ROOT / item['file']
        if digest(path) != item['sha256'] or digest(path, path.suffix == '.gz') != item['source_sha256']:
            errors.append('detection-record compression checksum mismatch: ' + item['file'])
    table_validation = json.loads((ROOT / 'data/results/tables/validation.json').read_text())
    if table_validation['tables'] != 21 or not table_validation['all_latest_display_matches']:
        errors.append('table results are incomplete or the latest displayed values failed recomputation checks')
    bindings = {}
    for item in table_validation['results']:
        evidence = json.loads((ROOT / item['sources']).read_text())
        for source in evidence['sources']:
            filename, expected = source['file'], source['sha256']
            if filename in bindings and bindings[filename] != expected:
                errors.append('conflicting table-source checksums: ' + filename)
            bindings[filename] = expected
    for filename, expected in bindings.items():
        path = ROOT / filename
        if not path.is_file() or digest(path) != expected:
            errors.append('invalid table-result source: ' + filename)
    for item in json.loads((ROOT / 'data/reference/resource_work_manifest.json').read_text()):
        for filename, expected in item['files'].items():
            path = ROOT / item['folder'] / filename
            if not path.is_file() or digest(path) != expected:
                errors.append('invalid Bai work/resource source: ' + str(path.relative_to(ROOT)))
    for filename in ('measurement_source_bindings.json', 'fixed_vertex_source_bindings.json'):
        for item in json.loads((ROOT / 'data/results/provenance' / filename).read_text()):
            path = ROOT / item['file']
            if not path.is_file() or digest(path) != item['sha256']:
                errors.append('invalid measurement-source or concentrated-insertion source: ' + item['file'])
    oversized = [str(path.relative_to(ROOT)) for path in ROOT.rglob('*')
                 if path.is_file() and 'build' not in path.relative_to(ROOT).parts
                 and path.stat().st_size >= 100 * 1024 * 1024
                 and path != ROOT / 'data/datasets/full/dblp.txt']
    errors += ['file exceeds the standard Git per-file limit: ' + filename for filename in oversized]
    print(json.dumps(dict(status='passed' if not errors else 'failed', input_graphs=len(inputs),
                          fixed_event_files=sum(len(item['samples']) for item in inputs),
                          bai_reference_files=len(references), external_inputs=external,
                          result_tables=table_validation['tables'],
                          submitted_table_discrepancies=[r['table'] for r in table_validation['results'] if not r['display_matches']],
                          all_latest_tables_match=table_validation['all_latest_display_matches'],
                          errors=errors), ensure_ascii=False, indent=2))
    raise SystemExit(bool(errors))


if __name__ == '__main__':
    main()
