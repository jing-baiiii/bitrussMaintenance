"""Run the 52 timing/count configurations using the frozen inputs."""
import argparse
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser(description='Run the nine-graph main and GH/ID scalability experiments')
    parser.add_argument('--datasets', nargs='+', help='Run selected configurations, for example recordlabel GH02')
    parser.add_argument('--events', type=int, default=500)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--cpu', type=int, default=min(os.sched_getaffinity(0)))
    parser.add_argument('--output', type=Path, default=ROOT / 'build/paper_results')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    if not 1 <= args.events <= 500 or args.repeats < 1:
        parser.error('events must be between 1 and 500, and repeats must be positive')
    if args.cpu not in os.sched_getaffinity(0):
        parser.error('the selected CPU is not allowed for this process')
    inputs = json.loads((ROOT / 'data/inputs.json').read_text())
    if args.datasets:
        unknown = set(args.datasets) - {item['dataset'] for item in inputs}
        if unknown:
            parser.error('unknown configuration: ' + ', '.join(sorted(unknown)))
        inputs = [item for item in inputs if item['dataset'] in args.datasets]
    output = args.output.resolve()
    if output.exists():
        parser.error('output directory already exists; choose a new directory')
    jobs = []
    missing = []
    for item in inputs:
        name = item['dataset']
        scale = name.startswith(('GH0', 'ID0'))
        graph = ROOT / item['graph']
        if not graph.is_file():
            missing.append(item['graph'])
        for direction in ('insert', 'delete'):
            samples = ROOT / item['samples'][direction + '_ours']
            if not samples.is_file():
                missing.append(str(samples.relative_to(ROOT)))
            for mode in (['time'] if scale else ['time', 'count']):
                label = f'{"E5" if scale else "E1"}_{name}_{direction}_{mode}'
                command = [str(ROOT / f'build/experiments/{mode}'), str(graph), str(samples),
                           direction, str(args.events), str(args.repeats if mode == 'time' else 1),
                           str(output / label), str(args.cpu)]
                jobs.append((label, command, item))
    if args.dry_run:
        print(json.dumps(dict(configurations=len(jobs), missing=sorted(set(missing)),
                              labels=[job[0] for job in jobs]), ensure_ascii=False, indent=2))
        return
    if missing:
        parser.error('missing inputs: ' + ', '.join(sorted(set(missing))) + '. Download and extract the data archive as described in docs/datasets.md.')
    for item in inputs:
        graph = ROOT / item['graph']
        h = hashlib.sha256()
        with graph.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(block)
        if h.hexdigest() != item['graph_sha256']:
            parser.error('graph checksum mismatch: ' + item['graph'])
        for key, filename in item['samples'].items():
            if hashlib.sha256((ROOT / filename).read_bytes()).hexdigest() != item['samples_sha256'][key]:
                parser.error('event-file checksum mismatch: ' + filename)
    if not all((ROOT / f'build/experiments/{mode}').is_file() for mode in ('time', 'count')):
        subprocess.run(['bash', str(ROOT / 'experiments/scripts/build_drivers.sh')], check=True)
    output.mkdir(parents=True)
    for label, command, item in jobs:
        print('Starting ' + label, flush=True)
        subprocess.run(command, cwd=ROOT, check=True)
        (output / label / 'input.json').write_text(json.dumps(dict(
            graph=item['graph'], graph_sha256=item['graph_sha256'],
            samples=item['samples'][command[3] + '_ours'], cpu=args.cpu,
            events=args.events, repeats=int(command[5])), ensure_ascii=False, indent=2) + '\n')
    if args.events == 500:
        subprocess.run(['python3', str(ROOT / 'experiments/scripts/summarize.py'), str(output)], check=True)
    print(f'Completed {len(jobs)} configurations. Output: {output}')


if __name__ == '__main__':
    main()
