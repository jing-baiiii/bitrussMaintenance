#ifndef INSERTION_ALLOCATION62_H
#define INSERTION_ALLOCATION62_H 
#include <array>
#include <cstdint>
#include <cstdlib>
#include <new>
#include <cstddef>
#include <limits>
namespace allocation62 {
enum Category {Test,Graph,Index,Output,Aux,Idle,Categories};
inline std::array<size_t,Categories> live{},peak{},before{};
inline Category category=Test;inline bool recording=false;
struct Scope {Category old;Scope(Category c):old(category){category=c;}~Scope(){category=old;}};
inline size_t rawAuxPeak=0;
inline void begin(){before=live;peak=live;rawAuxPeak=live[Aux]+live[Idle];recording=true;}
inline void end(){recording=false;}
struct alignas(std::max_align_t) Header {size_t bytes;void* raw;Category category;};
inline void* allocate(size_t bytes,size_t alignment=alignof(std::max_align_t)) {
    if(alignment<alignof(Header))alignment=alignof(Header);
    if(bytes>std::numeric_limits<size_t>::max()-sizeof(Header)-alignment)throw std::bad_alloc();
    void* raw=std::malloc(bytes+sizeof(Header)+alignment);if(!raw)throw std::bad_alloc();
    uintptr_t address=(reinterpret_cast<uintptr_t>(raw)+sizeof(Header)+alignment-1)&~(uintptr_t(alignment)-1);
    auto h=reinterpret_cast<Header*>(address)-1;h->bytes=bytes;h->raw=raw;h->category=category;
    live[category]+=bytes;if(recording&&live[category]>peak[category])peak[category]=live[category];
    if(recording&&live[Aux]+live[Idle]>rawAuxPeak)rawAuxPeak=live[Aux]+live[Idle];
    return reinterpret_cast<void*>(address);
}
inline void release(void* pointer) noexcept {
    if(!pointer)return;auto h=static_cast<Header*>(pointer)-1;
    live[h->category]-=h->bytes;std::free(h->raw);
}
inline void retag(void* pointer,Category destination) {
    if(!pointer)return;auto h=static_cast<Header*>(pointer)-1;
    live[h->category]-=h->bytes;live[destination]+=h->bytes;h->category=destination;
}
}
#ifdef PI62_MEMORY
#define PI62_MEMORY_BLOCK(c,...) do {allocation62::Scope pi62MemoryScope(allocation62::c);__VA_ARGS__;}while(0)
#else
#define PI62_MEMORY_BLOCK(c,...) do {__VA_ARGS__;}while(0)
#endif
#ifdef PI62_MEMORY_IMPLEMENTATION
void* operator new(size_t n){return allocation62::allocate(n);}
void* operator new[](size_t n){return allocation62::allocate(n);}
void operator delete(void* p) noexcept {allocation62::release(p);}
void operator delete[](void* p) noexcept {allocation62::release(p);}
void operator delete(void* p,size_t) noexcept {allocation62::release(p);}
void operator delete[](void* p,size_t) noexcept {allocation62::release(p);}
void* operator new(size_t n,std::align_val_t a){return allocation62::allocate(n,size_t(a));}
void* operator new[](size_t n,std::align_val_t a){return allocation62::allocate(n,size_t(a));}
void operator delete(void* p,std::align_val_t) noexcept {allocation62::release(p);}
void operator delete[](void* p,std::align_val_t) noexcept {allocation62::release(p);}
void operator delete(void* p,size_t,std::align_val_t) noexcept {allocation62::release(p);}
void operator delete[](void* p,size_t,std::align_val_t) noexcept {allocation62::release(p);}
void* operator new(size_t n,const std::nothrow_t&) noexcept {try{return allocation62::allocate(n);}catch(...){return nullptr;}}
void* operator new[](size_t n,const std::nothrow_t&) noexcept {try{return allocation62::allocate(n);}catch(...){return nullptr;}}
void operator delete(void* p,const std::nothrow_t&) noexcept {allocation62::release(p);}
void operator delete[](void* p,const std::nothrow_t&) noexcept {allocation62::release(p);}
#endif
#endif
