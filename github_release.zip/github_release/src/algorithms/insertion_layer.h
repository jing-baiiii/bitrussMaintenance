#ifndef ARRAY_INSERTION_LAYER96_H
#define ARRAY_INSERTION_LAYER96_H 
#include <cstdint>
#include <chrono>
#include <limits>
#include <memory>
#include <map>
#include <unordered_map>
#include <vector>
#include <array>
struct Insertion60Metrics {
    uint64_t firstHop=0, secondHop=0, edgeLookups=0, initialButterflies=0;
    uint64_t masterMembershipScans=0, newBlooms=0, newWedges=0, newMemberships=0;
    uint64_t totalSupportWrites=0, totalSupportLogicalInc=0;
    uint64_t layers=0, candidates=0, candidateUnique=0, closureMemberships=0;
    uint64_t bloomBuilds=0, bloomHits=0, supportWedgeScans=0, supportMemberships=0;
    uint64_t supportInitializations=0, peelPairs=0, batches=0, cascadeGroups=0;
    uint64_t cascadeMemberships=0, cascadeWedgeScans=0, cascadeEffectiveWedges=0;
    uint64_t workSupportWrites=0, workSupportLogicalDec=0;
    uint64_t phiWritesIncludingNew=0, phiWritesExcludingNew=0, promotedEdges=0;
    uint64_t algebraReads=0, pathPairProbes=0, explicitWitnessPairs=0;
    uint64_t eeChecks=0, eeStops=0, eePropagations=0, filterChecks=0, algebraLossGroups=0;
};
#ifdef INSERT60_COUNT
#define I60_COUNT(field,amount) do { if(metrics) metrics->field+=(amount); } while(0)
#else
#define I60_COUNT(field,amount) do {} while(0)
#endif
struct Insertion60Base {
    Graph graph;
    BEGraphLoMem index;
    vector<char> left;
};
struct Insertion60Workspace {
    vector<char> candidate,retired,inBatch,seenEvent;
    vector<uint64_t> support;
    vector<intE> touched,seenTouched;
    void grow(size_t n) {
        candidate.resize(n,0);retired.resize(n,0);inBatch.resize(n,0);
        seenEvent.resize(n,0);support.resize(n,0);
    }
    void clearLayer() {
        for(intE e:touched) {candidate[e]=retired[e]=inBatch[e]=0;support[e]=0;}
        touched.clear();
    }
    void clearEvent() {
        clearLayer();for(intE e:seenTouched)seenEvent[e]=0;seenTouched.clear();
    }
};
class Insertion60State {
public:
    static constexpr intE noEdge=std::numeric_limits<intE>::max();
    using Wedge=pair<intE,intE>;
    using Membership=pair<intB,intE>;
    struct AddedBloom {pair<intV,intV> master;};
    shared_ptr<const Insertion60Base> base;
    vector<intE> phi;
    vector<uint64_t> es;
    vector<pair<intV,intV>> addedEdges;
    unordered_map<intV,vector<pair<intV,intE>>> addedAdj;
    vector<AddedBloom> addedBlooms;
    unordered_map<pair<intV,intV>,intB,pair_hash> addedMaster;
    unordered_map<intB,vector<Wedge>> addedWedges;
    unordered_map<intE,vector<Membership>> addedMemberships;
    Insertion60Workspace workspace;
    Insertion60State(shared_ptr<const Insertion60Base> initial,vector<intE> levels,vector<uint64_t> supports)
        :base(std::move(initial)),phi(std::move(levels)),es(std::move(supports)) {
        if(!base||phi.size()!=base->graph.numE||es.size()!=phi.size()||base->left.size()!=base->graph.numT)
            throw runtime_error("insertion initial state size mismatch");
    }
    size_t edges() const {return phi.size();}
    intB blooms() const {return base->index.numV+(intB)addedBlooms.size();}
    pair<intV,intV> endpoints(intE e) const {
        if(e<base->graph.numE)return base->graph.eIdToV.at(e);
        return addedEdges.at(e-base->graph.numE);
    }
    pair<intV,intV> master(intB b) const {
        if(b<base->index.numV)return base->index.bloomMaster.at(b);
        return addedBlooms.at(b-base->index.numV).master;
    }
    intE findEdge(intV a,intV b,Insertion60Metrics* metrics=nullptr) const {
        I60_COUNT(edgeLookups,1);
        const auto& adjacent=base->graph.adj.at(a);
        auto it=lower_bound(adjacent.begin(),adjacent.end(),b);
        if(it!=adjacent.end()&&*it==b)return base->graph.eId[a][it-adjacent.begin()];
        auto extra=addedAdj.find(a);
        if(extra!=addedAdj.end()) {
            const auto& list=extra->second;
            auto pos=lower_bound(list.begin(),list.end(),b,[](auto entry,intV vertex){return entry.first<vertex;});
            if(pos!=list.end()&&pos->first==b)return pos->second;
        }
        return noEdge;
    }
    template<class Fn> void neighbors(intV a,Fn&& fn) const {
        for(size_t i=0;i<base->graph.adj[a].size();++i)fn(base->graph.adj[a][i],base->graph.eId[a][i]);
        auto extra=addedAdj.find(a);if(extra!=addedAdj.end())for(auto entry:extra->second)fn(entry.first,entry.second);
    }
    template<class Fn> void wedges(intB b,Fn&& fn) const {
        if(b<base->index.numV) {
            const auto& ix=base->index;
            for(intB i=ix.bloomVI[b];i<ix.bloomVI[b]+ix.bloomDegree[b];++i)fn(ix.bloomEI[i]);
        }
        auto extra=addedWedges.find(b);if(extra!=addedWedges.end())for(auto entry:extra->second)fn(entry);
    }
    template<class Fn> void memberships(intE e,Fn&& fn) const {
        if(e<base->graph.numE) {
            const auto& ix=base->index;
            for(intB i=ix.edgeVI[e];i<ix.edgeVI[e+1];++i)if(ix.edgeEI[i].first>=0)fn(ix.edgeEI[i]);
        }
        auto extra=addedMemberships.find(e);if(extra!=addedMemberships.end())for(auto entry:extra->second)fn(entry);
    }
    intE insert(intV u,intV v,Insertion60Metrics* metrics=nullptr,
                bool sapFilters=false,bool earlyEviction=false,bool supportAlgebra=false,
                double* maintenanceMs=nullptr) {
        if(u>=base->graph.numT||v>=base->graph.numT||base->left[u]==base->left[v])
            throw runtime_error("insertion endpoints outside fixed bipartition");
        if(findEdge(u,v,metrics)!=noEdge)throw runtime_error("insertion edge already exists");
        if(edges()>=noEdge)throw overflow_error("edge id exhausted");
        auto _mt0=std::chrono::steady_clock::now();
        const intE inserted=edges();
        addedEdges.push_back({u,v});phi.push_back(0);es.push_back(0);
        auto addNeighbor=[&](intV a,intV b) {
            auto& list=addedAdj[a];auto it=lower_bound(list.begin(),list.end(),b,[](auto e,intV x){return e.first<x;});
            list.insert(it,{b,inserted});
        };
        addNeighbor(u,v);addNeighbor(v,u);
        workspace.grow(edges());
        struct Growth {Wedge current,prior;intB bloom=-1;};
        map<pair<intV,intV>,Growth> growth;
        map<intE,vector<intE>> roots;
        neighbors(u,[&](intV otherV,intE edge2) {
            I60_COUNT(firstHop,1);if(otherV==v)return;
            neighbors(v,[&](intV otherU,intE edge3) {
                I60_COUNT(secondHop,1);if(otherU==u)return;
                intE edge4=findEdge(otherU,otherV,metrics);if(edge4==noEdge)return;
                I60_COUNT(initialButterflies,1);
                array<intE,4> butterfly={inserted,edge2,edge3,edge4};
                for(intE e:butterfly) {
                    if(es[e]==std::numeric_limits<uint64_t>::max())throw overflow_error("total support overflow");
                    ++es[e];I60_COUNT(totalSupportWrites,1);I60_COUNT(totalSupportLogicalInc,1);
                    if(phi[e]==noEdge)throw overflow_error("layer exhausted");
                    roots[phi[e]+1].push_back(e);
                }
                intV minimum=min(min(u,v),min(otherU,otherV));
                bool masterU=minimum==u||minimum==otherU;
                pair<intV,intV> key=masterU?minmax(u,otherU):minmax(v,otherV);
                Wedge current={inserted,masterU?edge3:edge2};
                Wedge prior=masterU?Wedge{edge2,edge4}:Wedge{edge3,edge4};
                auto found=growth.find(key);
                if(found!=growth.end()) {
                    if(found->second.current!=current)throw runtime_error("inconsistent new wedge");
                    if(found->second.bloom<0&&minmax(found->second.prior.first,found->second.prior.second)!=minmax(prior.first,prior.second))
                        throw runtime_error("missing old bloom with multiple prior paths");
                    return;
                }
                intB b=-1;
                auto fresh=addedMaster.find(key);if(fresh!=addedMaster.end())b=fresh->second;
                if(b<0)memberships(prior.first,[&](Membership entry) {
                    I60_COUNT(masterMembershipScans,1);auto m=master(entry.first);
                    if(min(m.first,m.second)==key.first&&max(m.first,m.second)==key.second)b=entry.first;
                });
                growth.emplace(key,Growth{current,prior,b});
            });
        });
        auto addWedge=[&](intB b,Wedge w) {
            addedWedges[b].push_back(w);addedMemberships[w.first].push_back({b,w.second});
            addedMemberships[w.second].push_back({b,w.first});
            I60_COUNT(newWedges,1);I60_COUNT(newMemberships,2);
        };
        for(auto& item:growth) {
            auto& g=item.second;
            if(g.bloom<0) {
                g.bloom=blooms();addedBlooms.push_back({{item.first.second,item.first.first}});
                addedMaster.emplace(item.first,g.bloom);addWedge(g.bloom,g.prior);I60_COUNT(newBlooms,1);
            }
            addWedge(g.bloom,g.current);
        }
        if(maintenanceMs) *maintenanceMs=std::chrono::duration<double,std::milli>(
            std::chrono::steady_clock::now()-_mt0).count();
        auto& work=workspace;
        while(!roots.empty()) {
            auto first=roots.begin();const intE k=first->first;
            vector<intE> seeds=std::move(first->second);roots.erase(first);I60_COUNT(layers,1);
            vector<intE> candidates;
            unordered_map<intB,uint64_t> good;
            unordered_map<intB,char> expanded;
            bool discovering=true;
            auto eligible=[&](intE e) {return phi[e]>=k||(phi[e]==k-1&&(!sapFilters||es[e]>=k));};
            auto activeWedge=[&](Wedge w) {
                auto live=[&](intE edge){return eligible(edge)&&!work.retired[edge]&&(discovering||phi[edge]>=k||work.candidate[edge]);};
                return live(w.first)&&live(w.second);
            };
            auto admit=[&](intE e) {
                if(sapFilters)I60_COUNT(filterChecks,1);
                if(phi[e]!=k-1||(sapFilters&&es[e]<k)||work.candidate[e])return;
                work.candidate[e]=1;work.touched.push_back(e);candidates.push_back(e);I60_COUNT(candidates,1);
                if(!work.seenEvent[e]) {work.seenEvent[e]=1;work.seenTouched.push_back(e);I60_COUNT(candidateUnique,1);}
            };
            auto ensureGood=[&](intB b) {
                auto known=good.find(b);
                if(known!=good.end())return known->second;
                uint64_t count=0;
                wedges(b,[&](Wedge w){I60_COUNT(supportWedgeScans,1);if(activeWedge(w))++count;});
                good.emplace(b,count);I60_COUNT(bloomBuilds,1);
                return count;
            };
            for(intE e:seeds)admit(e);
            for(size_t position=0;position<candidates.size();++position) {
                intE e=candidates[position];
                if(earlyEviction) {
                    I60_COUNT(eeChecks,1);
                    uint64_t workingSupport=0;
                    memberships(e,[&](Membership entry) {
                        if(!eligible(entry.second))return;
                        uint64_t paths=supportAlgebra?ensureGood(entry.first):0;
                        if(!supportAlgebra)wedges(entry.first,[&](Wedge w){if(activeWedge(w))++paths;});
                        if(paths)workingSupport+=paths-1;
                    });
                    if(workingSupport<k) {I60_COUNT(eeStops,1);continue;}
                    I60_COUNT(eePropagations,1);
                }
                memberships(e,[&](Membership entry) {
                    I60_COUNT(closureMemberships,1);
                    if(!eligible(entry.second))return;
                    if(supportAlgebra) {
                        if(expanded[entry.first]) {I60_COUNT(bloomHits,1);return;}
                        uint64_t count=ensureGood(entry.first);vector<intE> reached;
                        wedges(entry.first,[&](Wedge w) {
                            if(!activeWedge(w))return;
                            if(phi[w.first]==k-1)reached.push_back(w.first);
                            if(phi[w.second]==k-1)reached.push_back(w.second);
                        });
                        expanded[entry.first]=1;
                        if(count>=2)for(intE x:reached)admit(x);
                    } else {
                        vector<Wedge> active;
                        wedges(entry.first,[&](Wedge w){
                            I60_COUNT(supportWedgeScans,1);
                            if(activeWedge(w))active.push_back(w);
                        });
                        if(active.size()>=2)for(Wedge w:active) {
                            if(phi[w.first]==k-1)admit(w.first);
                            if(phi[w.second]==k-1)admit(w.second);
                        }
                    }
                });
            }
            discovering=false;good.clear();
            vector<intE> current;
            for(intE e:candidates) {
                uint64_t support=0;
                memberships(e,[&](Membership entry) {
                    I60_COUNT(supportMemberships,1);if(!activeWedge({e,entry.second}))return;
                    if(supportAlgebra) {
                        uint64_t count=ensureGood(entry.first);I60_COUNT(algebraReads,1);
                        if(count) {
                            if(support>std::numeric_limits<uint64_t>::max()-(count-1))throw overflow_error("work support overflow");
                            support+=count-1;
                        }
                    } else {
                        wedges(entry.first,[&](Wedge w) {
                            I60_COUNT(pathPairProbes,1);
                            if(activeWedge(w)&&w.first!=e&&w.second!=e) {
                                if(support==std::numeric_limits<uint64_t>::max())throw overflow_error("work support overflow");
                                ++support;
                            }
                        });
                    }
                });
                work.support[e]=support;I60_COUNT(supportInitializations,1);
                if(support<k)current.push_back(e);
            }
            while(!current.empty()) {
                I60_COUNT(batches,1);I60_COUNT(peelPairs,current.size());
                for(intE e:current)work.inBatch[e]=1;
                unordered_map<intB,uint64_t> broken;
                for(intE e:current)memberships(e,[&](Membership entry) {
                    I60_COUNT(cascadeMemberships,1);
                    intE twin=entry.second;
                    if(!activeWedge({e,twin})||(work.inBatch[twin]&&e>twin))return;
                    if(supportAlgebra)++broken[entry.first];
                    else broken.emplace(entry.first,0);
                });
                vector<intE> next;
                for(auto item:broken) {
                    I60_COUNT(cascadeGroups,1);
                    vector<Wedge> active;
                    wedges(item.first,[&](Wedge w){I60_COUNT(cascadeWedgeScans,1);if(activeWedge(w))active.push_back(w);});
                    I60_COUNT(cascadeEffectiveWedges,active.size());
                    if(!supportAlgebra) {
                        for(size_t i=0;i<active.size();++i)for(size_t j=i+1;j<active.size();++j) {
                            const Wedge a=active[i],b=active[j];
                            if(!(work.inBatch[a.first]||work.inBatch[a.second]||work.inBatch[b.first]||work.inBatch[b.second]))continue;
                            I60_COUNT(explicitWitnessPairs,1);
                            for(intE edge:{a.first,a.second,b.first,b.second}) {
                                if(phi[edge]!=k-1||!work.candidate[edge]||work.inBatch[edge]||work.retired[edge])continue;
                                if(work.support[edge]==0)throw runtime_error("work support underflow");
                                uint64_t before=work.support[edge];--work.support[edge];
                                I60_COUNT(workSupportWrites,1);I60_COUNT(workSupportLogicalDec,1);
                                if(before>=k&&work.support[edge]<k)next.push_back(edge);
                            }
                        }
                    } else {
                        I60_COUNT(algebraLossGroups,1);
                        uint64_t& count=good.at(item.first);uint64_t d=item.second;
                        if(count<d)throw runtime_error("invalid batch path loss");
                        for(Wedge w:active) {
                            uint64_t loss=(work.inBatch[w.first]||work.inBatch[w.second])?count-1:d;
                            if(loss==0)continue;
                            for(intE edge:{w.first,w.second}) {
                                if(!work.candidate[edge]||work.inBatch[edge]||work.retired[edge])continue;
                                if(work.support[edge]<loss)throw runtime_error("work support underflow");
                                uint64_t before=work.support[edge];work.support[edge]-=loss;
                                I60_COUNT(workSupportWrites,1);I60_COUNT(workSupportLogicalDec,loss);
                                if(before>=k&&work.support[edge]<k)next.push_back(edge);
                            }
                        }
                        count-=d;
                    }
                }
                for(intE e:current) {work.retired[e]=1;work.inBatch[e]=0;}
                current=std::move(next);
            }
            for(intE e:candidates)if(!work.retired[e]) {
                phi[e]=k;I60_COUNT(phiWritesIncludingNew,1);
                if(e!=inserted)I60_COUNT(phiWritesExcludingNew,1);
                I60_COUNT(promotedEdges,1);
                if(k==noEdge)throw overflow_error("layer exhausted");
                roots[k+1].push_back(e);
            }
            work.clearLayer();
        }
        work.clearEvent();return inserted;
    }
};
#undef I60_COUNT
#endif
