#ifndef ARRAY_BMD_PERSISTENT_H
#define ARRAY_BMD_PERSISTENT_H 
#include <map>
#include <limits>
#include <stdexcept>
struct PersistentMetrics {
    long long eeChecks=0,eeStops=0,eePropagations=0;
    long long initialLost=0, initialScans=0, initialMemberships=0;
    long long esWrites=0, esLogical=0, initialWrites=0, initialLogical=0;
    long long initialDeficitTests=0, lowerDeficitTests=0;
    long long checkAttempts=0, checkedPairs=0, keptChecks=0;
    long long pruningMemberships=0, peelPairs=0, phiWrites=0, layers=0, batches=0;
    long long cascadeMemberships=0, cascadeScans=0, cascadeApplyWedges=0, cascadeGroups=0;
    long long cascadeWrites=0, cascadeLogical=0, recomputeWrites=0;
    long long recomputeMemberships=0, recomputeScans=0, recomputeBuilds=0, recomputeHits=0;
    long long structuralMemberships=0, cleanupWrites=0;
    size_t residentBytes=0;
};
#ifdef ABP_COUNT_OPS
#define PERSIST_COUNT(field,amount) do { if(metrics) metrics->field += (amount); } while(0)
#else
#define PERSIST_COUNT(field,amount) do {} while(0)
#endif
struct PersistentWorkspace {
    vector<intB> bound, good;
    vector<intE> checkedLevel, cacheLevel, touched;
    vector<intB> touchedBlooms;
    vector<char> edgeTouched, scheduled, peeling, bloomSeen;
    void prepare(size_t n,size_t b,bool witness=false) {
        if(witness) bound.resize(n,-1);
        checkedLevel.resize(n,ABP_NOE);
        edgeTouched.resize(n,0); scheduled.resize(n,0); peeling.resize(n,0);
        good.resize(b,0); cacheLevel.resize(b,ABP_NOE); bloomSeen.resize(b,0);
    }
    size_t bytes() const {
        return (bound.capacity()+good.capacity()+touchedBlooms.capacity())*sizeof(intB)
            +(checkedLevel.capacity()+cacheLevel.capacity()+touched.capacity())*sizeof(intE)
            +edgeTouched.capacity()+scheduled.capacity()+peeling.capacity()+bloomSeen.capacity();
    }
};
static void buildPersistentSupport(const BEGraphLoMem& index,const vector<intE>& phi,vector<intB>& support) {
    vector<intE> wedgeLevels(index.bloomEI.size(),0);
    for(intB b=0;b<index.numV;++b) {
        const auto start=index.bloomVI[b], end=start+index.bloomDegree[b];
        for(intB j=start;j<end;++j) {
            const auto q=index.bloomEI[j]; wedgeLevels[j]=min(phi[q.first],phi[q.second]);
        }
        sort(wedgeLevels.begin()+start,wedgeLevels.begin()+end,greater<intE>());
    }
    support.assign(phi.size(),0);
    for(intE e=0;e<phi.size();++e) for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
        const auto item=index.edgeEI[i]; const intB b=item.first;
        if(b<0||phi[item.second]<phi[e]) continue;
        const auto first=wedgeLevels.begin()+index.bloomVI[b], last=first+index.bloomDegree[b];
        const intB g=upper_bound(first,last,phi[e],greater<intE>())-first;
        if(g>0) {
            if(support[e]>numeric_limits<intB>::max()-(g-1)) throw overflow_error("persistent support overflow");
            support[e]+=g-1;
        }
    }
}
static void arrayBMDPersistent(BEGraphLoMem& index,vector<intE>& phi,vector<intE>& es,
                               vector<intB>& support,intE deleted,PersistentWorkspace& work,
                               PersistentMetrics* metrics=nullptr,bool verifyBloomWitness=false) {
    if(phi.size()!=es.size()||phi.size()!=support.size()||deleted<0||deleted>=phi.size())
        throw invalid_argument("persistent state dimensions");
    work.prepare(phi.size(),index.bloomDegree.size(),verifyBloomWitness);
    map<intE,vector<intE>,greater<intE>> roots;
    auto touch=[&](intE e) {
        if(!work.edgeTouched[e]) {work.edgeTouched[e]=1;work.touched.push_back(e);}
    };
    auto decrement=[&](intE e,intB loss,bool initial) {
        if(loss<=0) return;
        if(support[e]<loss) throw runtime_error("persistent support underflow");
        support[e]-=loss;
        if(initial) {PERSIST_COUNT(initialWrites,1);PERSIST_COUNT(initialLogical,loss);}
        else {PERSIST_COUNT(cascadeWrites,1);PERSIST_COUNT(cascadeLogical,loss);}
    };
    auto seed=[&](intE e,bool lower=false) {
        if(lower) {PERSIST_COUNT(lowerDeficitTests,1);}
        else {PERSIST_COUNT(initialDeficitTests,1);}
        if(phi[e]>0&&support[e]<(intB)phi[e]&&!work.scheduled[e]) {
            touch(e);work.scheduled[e]=1;roots[phi[e]].push_back(e);
        }
    };
    auto unlink=[&](intE e,intB b) {
        for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
            PERSIST_COUNT(structuralMemberships,1);
            if(index.edgeEI[i].first==b) index.edgeEI[i].first=-1;
        }
    };
    vector<pair<intB,intE>> changing;
    for(intB i=index.edgeVI[deleted];i<index.edgeVI[deleted+1];++i) {
        PERSIST_COUNT(initialMemberships,1);
        if(index.edgeEI[i].first>=0) changing.push_back(index.edgeEI[i]);
    }
    const intE oldLevel=phi[deleted];
    for(auto item:changing) {
        const intB b=item.first; const intE twin=item.second;
        const intB start=index.bloomVI[b],end=start+index.bloomDegree[b];
        intB own=-1,lost=0,twinLoss=0;
        for(intB j=start;j<end;++j) {
            PERSIST_COUNT(initialScans,1);
            const auto q=index.bloomEI[j];
            if(q.first==deleted||q.second==deleted) {own=j;continue;}
            ++lost;--es[q.first];--es[q.second];
            PERSIST_COUNT(esWrites,2);PERSIST_COUNT(esLogical,2);
            const intE level=min(min(oldLevel,phi[twin]),min(phi[q.first],phi[q.second]));
            for(intE e:{q.first,q.second}) if(phi[e]==level) {decrement(e,1,true);seed(e);}
            if(phi[twin]==level) ++twinLoss;
        }
        decrement(twin,twinLoss,true);seed(twin);
        es[twin]-=lost;PERSIST_COUNT(esWrites,1);PERSIST_COUNT(esLogical,lost);
        PERSIST_COUNT(initialLost,lost);
        if(own<0) throw runtime_error("persistent deleted wedge missing");
        swap(index.bloomEI[own],index.bloomEI[end-1]);
        --index.bloomDegree[b];index.bloomWdgCnt[b]=index.bloomDegree[b];
        unlink(deleted,b);unlink(twin,b);
        if(index.bloomDegree[b]<2) {
            for(intB j=start;j<start+index.bloomDegree[b];++j) {
                const auto q=index.bloomEI[j];unlink(q.first,b);unlink(q.second,b);
            }
            index.bloomDegree[b]=index.bloomWdgCnt[b]=0;
        }
    }
    phi[deleted]=0;es[deleted]=0;support[deleted]=0;
    auto protect=[&](intE e,intE level) {
        if(!verifyBloomWitness) return false;
        if(work.bound[e]<0) {
            work.bound[e]=0;
            for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                PERSIST_COUNT(pruningMemberships,1);
                const intB b=index.edgeEI[i].first;
                if(b>=0) work.bound[e]=max(work.bound[e],(intB)index.bloomWdgCnt[b]);
            }
        }
        return work.bound[e]-1>=(intB)level;
    };
    while(!roots.empty()) {
        auto it=roots.begin();const intE level=it->first;
        vector<intE> seeds=move(it->second);roots.erase(it);
        vector<intE> current,next,removed;
        PERSIST_COUNT(layers,1);
        auto activate=[&](intE e) {
            PERSIST_COUNT(checkAttempts,1);
            if(phi[e]!=level||work.peeling[e]) return;
            touch(e);
            if(work.checkedLevel[e]!=level) {work.checkedLevel[e]=level;PERSIST_COUNT(checkedPairs,1);}
            PERSIST_COUNT(eeChecks,1);
            if(support[e]>=(intB)level) {PERSIST_COUNT(keptChecks,1);PERSIST_COUNT(eeStops,1);return;}
            if(protect(e,level)) throw runtime_error("protected edge has deficient persistent support");
            if(!work.scheduled[e]) {work.scheduled[e]=1;next.push_back(e);PERSIST_COUNT(eePropagations,1);}
        };
        for(intE e:seeds) {work.scheduled[e]=0;activate(e);}
        while(!next.empty()) {
            current.clear();current.swap(next);
            for(intE e:current) {work.scheduled[e]=0;work.peeling[e]=1;}
            vector<intB> groups;
            for(intE e:current) for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                PERSIST_COUNT(cascadeMemberships,1);
                const auto item=index.edgeEI[i];const intB b=item.first;
                if(b<0||phi[item.second]<level||work.bloomSeen[b]) continue;
                work.bloomSeen[b]=1;groups.push_back(b);
            }
            PERSIST_COUNT(batches,1);PERSIST_COUNT(peelPairs,current.size());
            for(intB b:groups) {
                PERSIST_COUNT(cascadeGroups,1);
                vector<pair<intE,intE>> active;intB broken=0;
                for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                    PERSIST_COUNT(cascadeScans,1);
                    const auto q=index.bloomEI[j];
                    if(phi[q.first]<level||phi[q.second]<level) continue;
                    active.push_back(q);
                    if(work.peeling[q.first]||work.peeling[q.second]) ++broken;
                }
                const intB g=active.size();
                for(auto q:active) {
                    PERSIST_COUNT(cascadeApplyWedges,1);
                    const intB loss=(work.peeling[q.first]||work.peeling[q.second])?g-1:broken;
                    for(intE e:{q.first,q.second}) if(phi[e]==level&&!work.peeling[e]&&loss>0) {
                        decrement(e,loss,false);activate(e);
                    }
                }
                work.bloomSeen[b]=0;
            }
            for(intE e:current) {
                phi[e]=level-1;work.peeling[e]=0;removed.push_back(e);
                PERSIST_COUNT(phiWrites,1);
            }
        }
        for(intE e:removed) {
            const intE lower=level-1;intB value=0;
            for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                PERSIST_COUNT(recomputeMemberships,1);
                const auto item=index.edgeEI[i];const intB b=item.first;
                if(b<0||phi[item.second]<lower) continue;
                if(work.cacheLevel[b]!=lower) {
                    if(work.cacheLevel[b]==ABP_NOE) work.touchedBlooms.push_back(b);
                    work.cacheLevel[b]=lower;work.good[b]=0;PERSIST_COUNT(recomputeBuilds,1);
                    for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                        PERSIST_COUNT(recomputeScans,1);
                        const auto q=index.bloomEI[j];
                        if(phi[q.first]>=lower&&phi[q.second]>=lower) ++work.good[b];
                    }
                } else PERSIST_COUNT(recomputeHits,1);
                const intB contribution=work.good[b]-1;
                if(contribution<0||value>numeric_limits<intB>::max()-contribution)
                    throw overflow_error("persistent rebuilt support overflow");
                value+=contribution;
            }
            support[e]=value;PERSIST_COUNT(recomputeWrites,1);seed(e,true);
        }
    }
    if(metrics) metrics->residentBytes=work.bytes();
    for(intE e:work.touched) {
        if(verifyBloomWitness) {work.bound[e]=-1;PERSIST_COUNT(cleanupWrites,1);}
        work.checkedLevel[e]=ABP_NOE;
        work.edgeTouched[e]=work.scheduled[e]=work.peeling[e]=0;PERSIST_COUNT(cleanupWrites,4);
    }
    work.touched.clear();
    for(intB b:work.touchedBlooms) {work.cacheLevel[b]=ABP_NOE;PERSIST_COUNT(cleanupWrites,1);}
    work.touchedBlooms.clear();
}
#undef PERSIST_COUNT
#endif
