#ifndef ARRAY_BMD_LAYER96_H
#define ARRAY_BMD_LAYER96_H 
#include "arrayBMDplus.h"
#include <map>
#include <omp.h>
#include <chrono>
struct Layer56Metrics {
    long long C=0, candidateUnique=0, supportInitializations=0, phiWrites=0;
    long long seedAttempts=0, seedLost=0, admissionAttempts=0, protectedAdmissions=0;
    long long pruningMemberships=0, supportMemberships=0, supportScans=0;
    long long bloomBuilds=0, bloomHits=0, cascadeBloomGroups=0, cascadeScans=0;
    long long cascadeApplyWedges=0, supportWrites=0, supportLogicalDec=0;
    long long layers=0, batches=0, commitScans=0, peelPairs=0;
    long long explicitWitnessPairs=0, eeChecks=0, eeStops=0, eePropagations=0, algebraLossGroups=0;
    long long parallelBloomJobs=0, parallelSupportJobs=0;
    size_t residentBytes=0;
};
#ifdef ABP_COUNT_OPS
#define L56_EVENT(field,amount) do { if(metrics) metrics->field += (amount); } while(0)
#else
#define L56_EVENT(field,amount) do {} while(0)
#endif
struct Layer56Workspace {
    vector<intB> support, bound, good;
    vector<intE> edgeLevel, bloomLevel, touched;
    vector<char> edgeTouched, candidateSeen, pending, peeling, candidate, retired, inBatch;
    vector<intB> bloomTouched;
    vector<long long> bloomBatch;
    long long batchEpoch=0;
    void prepare(size_t n, size_t b) {
        if(support.size()<n) {
            support.resize(n,-1); bound.resize(n,-1); edgeLevel.resize(n,ABP_NOE);
            edgeTouched.resize(n,0); candidateSeen.resize(n,0); pending.resize(n,0); peeling.resize(n,0);
            candidate.resize(n,0); retired.resize(n,0); inBatch.resize(n,0);
        }
        if(good.size()<b) {
            good.resize(b,0); bloomLevel.resize(b,ABP_NOE); bloomBatch.resize(b,0);
        }
    }
    size_t bytes() const {
        return (support.capacity()+bound.capacity()+good.capacity())*sizeof(intB)
            +(edgeLevel.capacity()+bloomLevel.capacity()+touched.capacity())*sizeof(intE)
            +(edgeTouched.capacity()+candidateSeen.capacity()+pending.capacity()+peeling.capacity()+candidate.capacity()+retired.capacity()+inBatch.capacity())*sizeof(char)
            +bloomBatch.capacity()*sizeof(long long)+bloomTouched.capacity()*sizeof(intB);
    }
};
static thread_local Layer56Workspace layer56Workspace;
static void arrayBMD_layer(BEGraphLoMem& index, vector<intE>& phi, vector<intE>& es,
                            intE deleted, bool pruning=true, int threads=1,
                            Layer56Metrics* metrics=nullptr, bool memoSupport=true,
                            double* maintenanceMs=nullptr, bool earlyEviction=true) {
    auto& ws=layer56Workspace;
    const intE n=phi.size();
    ws.prepare(n,index.bloomDegree.size());
    map<intE,vector<intE>,greater<intE>> roots;
    const intE deletedLevel=phi[deleted];
    vector<pair<intB,intE>> changing;
    for(intB i=index.edgeVI[deleted];i<index.edgeVI[deleted+1];++i)
        if(index.edgeEI[i].first>=0) changing.push_back(index.edgeEI[i]);
    auto _mt0=std::chrono::steady_clock::now();
    for(auto item:changing) {
        const intB b=item.first; const intE twin=item.second;
        const intB start=index.bloomVI[b], end=start+index.bloomDegree[b];
        intB removedPosition=-1, lost=0;
        for(intB j=start;j<end;++j) {
            L56_EVENT(seedAttempts,1);
            auto wedge=index.bloomEI[j];
            if(wedge.first==deleted||wedge.second==deleted) {removedPosition=j;continue;}
            ++lost; --es[wedge.first]; --es[wedge.second];
            const intE L=min(min(deletedLevel,phi[twin]),min(phi[wedge.first],phi[wedge.second]));
            if(L) for(intE e:{twin,wedge.first,wedge.second}) if(phi[e]==L) roots[L].push_back(e);
        }
        es[twin]-=lost;
        L56_EVENT(seedLost,lost);
        if(removedPosition<0) throw runtime_error("deleted edge has no owning wedge");
        swap(index.bloomEI[removedPosition],index.bloomEI[end-1]);
        --index.bloomDegree[b];
        index.bloomWdgCnt[b]=index.bloomDegree[b];
        abp_removeMembership(index,deleted,b);
        abp_removeMembership(index,twin,b);
        if(index.bloomDegree[b]<=1) {
            for(intB j=start;j<start+index.bloomDegree[b];++j) {
                auto wedge=index.bloomEI[j];
                abp_removeMembership(index,wedge.first,b);
                abp_removeMembership(index,wedge.second,b);
            }
            index.bloomDegree[b]=index.bloomWdgCnt[b]=0;
        }
    }
    es[deleted]=0; phi[deleted]=0;
    if(maintenanceMs) *maintenanceMs=std::chrono::duration<double,std::milli>(
        std::chrono::steady_clock::now()-_mt0).count();
    if(!earlyEviction) {
        while(!roots.empty()) {
            auto it=roots.begin();const intE L=it->first;
            vector<intE> seeds=move(it->second);roots.erase(it);
            vector<intE> candidates;
            L56_EVENT(layers,1);
            auto admit=[&](intE e) {
                if(phi[e]!=L||ws.candidate[e])return;
                ws.candidate[e]=1;candidates.push_back(e);L56_EVENT(C,1);
                if(!ws.edgeTouched[e]){ws.edgeTouched[e]=1;ws.touched.push_back(e);}
                if(!ws.candidateSeen[e])ws.candidateSeen[e]=1;
            };
            for(intE e:seeds)admit(e);
            for(size_t pos=0;pos<candidates.size();++pos) {
                intE e=candidates[pos];
                for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                    L56_EVENT(supportMemberships,1);
                    const auto item=index.edgeEI[i];const intB b=item.first;
                    if(b<0||phi[item.second]<L)continue;
                    vector<pair<intE,intE>> active;
                    for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                        L56_EVENT(supportScans,1);const auto w=index.bloomEI[j];
                        if(phi[w.first]>=L&&phi[w.second]>=L)active.push_back(w);
                    }
                    if(active.size()<2)continue;
                    for(auto w:active){admit(w.first);admit(w.second);}
                }
            }
            for(intE e:candidates) {
                intB value=0;
                for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                    const auto item=index.edgeEI[i];const intB b=item.first;
                    if(b<0||phi[item.second]<L)continue;
                    if(memoSupport) {
                        if(ws.bloomLevel[b]!=L) {
                            if(ws.bloomLevel[b]==ABP_NOE)ws.bloomTouched.push_back(b);
                            ws.bloomLevel[b]=L;ws.good[b]=0;L56_EVENT(bloomBuilds,1);
                            for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                                L56_EVENT(supportScans,1);const auto w=index.bloomEI[j];
                                if(phi[w.first]>=L&&phi[w.second]>=L)++ws.good[b];
                            }
                        }
                        if(ws.good[b]>0)value+=ws.good[b]-1;
                    } else {
                        for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                            L56_EVENT(supportScans,1);const auto w=index.bloomEI[j];
                            if(w.first!=e&&w.second!=e&&phi[w.first]>=L&&phi[w.second]>=L)++value;
                        }
                    }
                }
                ws.support[e]=value;L56_EVENT(supportInitializations,1);
            }
            vector<intE> batch;
            for(intE e:candidates)if(ws.support[e]<(intB)L)batch.push_back(e);
            while(!batch.empty()) {
                ++ws.batchEpoch;L56_EVENT(batches,1);L56_EVENT(peelPairs,batch.size());
                vector<intB> affected;
                for(intE e:batch) {
                    ws.inBatch[e]=ws.peeling[e]=1;
                    for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                        const auto item=index.edgeEI[i];const intB b=item.first;
                        if(b>=0&&phi[item.second]>=L&&ws.bloomBatch[b]!=ws.batchEpoch) {
                            ws.bloomBatch[b]=ws.batchEpoch;affected.push_back(b);
                        }
                    }
                }
                for(intB b:affected) {
                    L56_EVENT(cascadeBloomGroups,1);
                    vector<pair<intE,intE>> active;intB broken=0;
                    for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                        L56_EVENT(cascadeScans,1);const auto w=index.bloomEI[j];
                        if(phi[w.first]<L||phi[w.second]<L)continue;
                        active.push_back(w);
                        if(memoSupport&&(ws.inBatch[w.first]||ws.inBatch[w.second]))++broken;
                    }
                    L56_EVENT(cascadeApplyWedges,active.size());
                    if(!memoSupport) {
                        for(size_t i=0;i<active.size();++i)for(size_t j=i+1;j<active.size();++j) {
                            const auto a=active[i],c=active[j];
                            if(!(ws.inBatch[a.first]||ws.inBatch[a.second]||ws.inBatch[c.first]||ws.inBatch[c.second]))continue;
                            L56_EVENT(explicitWitnessPairs,1);
                            for(intE edge:{a.first,a.second,c.first,c.second}) {
                                if(phi[edge]!=L||!ws.candidate[edge]||ws.inBatch[edge])continue;
                                if(ws.support[edge]==0)throw runtime_error("deletion support underflow");
                                --ws.support[edge];L56_EVENT(supportWrites,1);L56_EVENT(supportLogicalDec,1);
                            }
                        }
                    } else {
                        L56_EVENT(algebraLossGroups,1);
                        const intB g=active.size();
                        for(auto w:active) {
                            const intB loss=(ws.inBatch[w.first]||ws.inBatch[w.second])?g-1:broken;
                            for(intE edge:{w.first,w.second}) {
                                if(phi[edge]!=L||!ws.candidate[edge]||ws.inBatch[edge]||loss==0)continue;
                                if(ws.support[edge]<loss)throw runtime_error("deletion support underflow");
                                ws.support[edge]-=loss;L56_EVENT(supportWrites,1);L56_EVENT(supportLogicalDec,loss);
                            }
                        }
                        ws.good[b]=g-broken;ws.bloomLevel[b]=L;
                    }
                }
                for(intE e:batch) {
                    phi[e]=L-1;ws.retired[e]=1;ws.inBatch[e]=ws.peeling[e]=0;
                    L56_EVENT(phiWrites,1);if(L>1)roots[L-1].push_back(e);
                }
                batch.clear();
                for(intE e:candidates)if(!ws.retired[e]&&ws.support[e]<(intB)L)batch.push_back(e);
            }
            for(intE e:candidates){ws.candidate[e]=ws.retired[e]=ws.inBatch[e]=0;ws.support[e]=-1;}
        }
        if(metrics) {
            size_t unique=0;for(intE e:ws.touched)if(ws.candidateSeen[e])++unique;
            metrics->candidateUnique=unique;metrics->residentBytes=ws.bytes();
        }
        for(intE e:ws.touched) {
            ws.edgeTouched[e]=ws.candidateSeen[e]=0;ws.edgeLevel[e]=ABP_NOE;ws.support[e]=-1;
            ws.bound[e]=-1;ws.pending[e]=ws.peeling[e]=ws.candidate[e]=ws.retired[e]=ws.inBatch[e]=0;
        }
        ws.touched.clear();
        for(intB b:ws.bloomTouched)ws.bloomLevel[b]=ABP_NOE;
        ws.bloomTouched.clear();
        return;
    }
    auto protect=[&](intE e,intE L) {
        if(!pruning) return false;
        if(ws.bound[e]<0) {
            ws.bound[e]=0;
            for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                L56_EVENT(pruningMemberships,1);
                const intB b=index.edgeEI[i].first;
                if(b>=0) ws.bound[e]=max(ws.bound[e],(intB)index.bloomWdgCnt[b]);
            }
        }
        return ws.bound[e]-1>=(intB)L;
    };
    while(!roots.empty()) {
        auto it=roots.begin(); const intE L=it->first;
        vector<intE> initial=move(it->second); roots.erase(it);
        vector<intE> current, next;
        L56_EVENT(layers,1);
        auto activate=[&](intE e) {
            L56_EVENT(admissionAttempts,1);
            if(phi[e]!=L||ws.peeling[e]) return;
            if(!ws.edgeTouched[e]) {
                ws.edgeTouched[e]=1; ws.touched.push_back(e);
            }
            if(ws.edgeLevel[e]!=L) {
                ws.edgeLevel[e]=L; ws.support[e]=-1;
                if(protect(e,L)) {L56_EVENT(protectedAdmissions,1);return;}
                L56_EVENT(C,1);
                ws.candidateSeen[e]=1;
            } else if(protect(e,L)) return;
            L56_EVENT(eeChecks,1);
            if(!ws.pending[e]&&(ws.support[e]<0||ws.support[e]<(intB)L)) {
                ws.pending[e]=1; next.push_back(e);L56_EVENT(eePropagations,1);
            } else {
                L56_EVENT(eeStops,1);
            }
        };
        for(intE e:initial) activate(e);
        while(!next.empty()) {
            current.clear(); current.swap(next);
            vector<intE> need;
            vector<intB> builds;
            for(intE e:current) {
                ws.pending[e]=0;
                if(ws.support[e]>=0) continue;
                need.push_back(e);
                if(!memoSupport) continue;
                for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                    L56_EVENT(supportMemberships,1);
                    const auto item=index.edgeEI[i]; const intB b=item.first;
                    if(b<0||phi[item.second]<L) continue;
                    if(ws.bloomLevel[b]==L) {L56_EVENT(bloomHits,1);continue;}
                    if(ws.bloomLevel[b]==ABP_NOE) ws.bloomTouched.push_back(b);
                    ws.bloomLevel[b]=L; builds.push_back(b);
                    L56_EVENT(bloomBuilds,1);
                    L56_EVENT(supportScans,index.bloomDegree[b]);
                }
            }
            if(threads>1&&builds.size()>=64) L56_EVENT(parallelBloomJobs,builds.size());
#ifndef L56_SINGLE_ONLY
            #pragma omp parallel for num_threads(threads) if(threads>1 && builds.size()>=64) schedule(dynamic,16)
#endif
            for(size_t bi=0;bi<builds.size();++bi) {
                const intB b=builds[bi]; intB g=0;
                for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                    auto wedge=index.bloomEI[j];
                    if(phi[wedge.first]>=L&&phi[wedge.second]>=L) ++g;
                }
                ws.good[b]=g;
            }
            L56_EVENT(supportInitializations,need.size());
            if(threads>1&&need.size()>=64) L56_EVENT(parallelSupportJobs,need.size());
            vector<long long> explicitScans;
#ifdef ABP_COUNT_OPS
            if(!memoSupport) explicitScans.resize(need.size(),0);
#endif
#ifndef L56_SINGLE_ONLY
            #pragma omp parallel for num_threads(threads) if(threads>1 && need.size()>=64) schedule(dynamic,16)
#endif
            for(size_t ei=0;ei<need.size();++ei) {
                const intE e=need[ei]; intB s=0;
                for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                    const auto item=index.edgeEI[i];
                    if(item.first<0||phi[item.second]<L) continue;
                    if(memoSupport) s+=ws.good[item.first]-1;
                    else {
                        const intB b=item.first;
                        for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                            auto wedge=index.bloomEI[j];
#ifdef ABP_COUNT_OPS
                            ++explicitScans[ei];
#endif
                            if(wedge.first!=e&&wedge.second!=e&&phi[wedge.first]>=L&&phi[wedge.second]>=L) ++s;
                        }
                    }
                }
                ws.support[e]=s;
            }
            for(auto count:explicitScans) L56_EVENT(supportScans,count);
            L56_EVENT(supportMemberships, [&](){long long total=0;for(intE e:need)total+=index.edgeVI[e+1]-index.edgeVI[e];return total;}());
            vector<intE> peel;
            vector<intB> affected;
            ++ws.batchEpoch;
            for(intE e:current) if(ws.support[e]<(intB)L) {
                peel.push_back(e); ws.peeling[e]=1;
                for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                    const auto item=index.edgeEI[i]; const intB b=item.first;
                    if(b>=0&&phi[item.second]>=L&&ws.bloomBatch[b]!=ws.batchEpoch) {
                        ws.bloomBatch[b]=ws.batchEpoch; affected.push_back(b);
                    }
                }
            }
            if(peel.empty()) continue;
            L56_EVENT(batches,1);
            for(intB b:affected) {
                L56_EVENT(algebraLossGroups,1);
                L56_EVENT(cascadeBloomGroups,1);
                vector<pair<intE,intE>> active;
                intB broken=0;
                for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                    L56_EVENT(cascadeScans,1);
                    auto wedge=index.bloomEI[j];
                    if(phi[wedge.first]<L||phi[wedge.second]<L) continue;
                    active.push_back(wedge);
                    if(ws.peeling[wedge.first]||ws.peeling[wedge.second]) ++broken;
                }
                const intB g=active.size();
                for(auto wedge:active) {
                    L56_EVENT(cascadeApplyWedges,1);
                    const intB loss=(ws.peeling[wedge.first]||ws.peeling[wedge.second])?g-1:broken;
                    for(intE e:{wedge.first,wedge.second}) if(phi[e]==L&&!ws.peeling[e]&&loss>0) {
                        if(ws.edgeLevel[e]==L&&ws.support[e]>=0) {
                            ws.support[e]-=loss;
                            L56_EVENT(supportWrites,1); L56_EVENT(supportLogicalDec,loss);
                        }
                        activate(e);
                    }
                }
                if(ws.bloomLevel[b]==ABP_NOE) ws.bloomTouched.push_back(b);
                ws.good[b]=g-broken; ws.bloomLevel[b]=L;
            }
            for(intE e:peel) {
                phi[e]=L-1; ws.peeling[e]=0;
                L56_EVENT(phiWrites,1);
                if(L>1) roots[L-1].push_back(e);
            }
        }
    }
    if(metrics) {
        size_t unique=0;
        for(intE e:ws.touched) if(ws.candidateSeen[e]) ++unique;
        metrics->candidateUnique=unique;
        metrics->residentBytes=ws.bytes();
    }
    for(intE e:ws.touched) {
        ws.edgeTouched[e]=ws.candidateSeen[e]=0; ws.edgeLevel[e]=ABP_NOE; ws.support[e]=-1;
        ws.bound[e]=-1; ws.pending[e]=ws.peeling[e]=0;
    }
    ws.touched.clear();
    for(intB b:ws.bloomTouched) ws.bloomLevel[b]=ABP_NOE;
    ws.bloomTouched.clear();
}
#undef L56_EVENT
#endif
