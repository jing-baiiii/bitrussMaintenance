#ifndef graph_h
#define graph_h 
#include "utils.h"
using namespace std;
typedef unsigned int intV;
typedef unsigned int intE;
typedef long long int intB;
inline long long g_blooms_visited = 0;
inline long long g_butterflies_accessed = 0;
inline void resetStructAccessCounters() { g_blooms_visited = 0; g_butterflies_accessed = 0; }
#define CL_SIZE 1
typedef struct BEGraphLoMem
{
    intE numU;
    intB numV;
    intB numE;
    std::vector<intB> edgeVI;
    std::vector<intB> bloomVI;
    std::vector<intE> edgeDegree;
    std::vector<intE> bloomDegree;
    std::vector<intE> bloomWdgCnt;
    std::vector<std::pair<intV,intV>> bloomMaster;
    std::vector<std::pair<intB, intE>> edgeEI;
    std::vector<std::pair<intE, intE>> bloomEI;
} BEGraphLoMem;
typedef struct BVGraphLoMem
{
    intV numU;
    intB numV;
    intB numE;
    std::vector<intV> verVI;
    std::vector<intB> bloomVI;
    std::vector<intE> verDegree;
    std::vector<intV> bloomDegree;
    std::vector<intE> bloomWdgCnt;
    std::vector<std::pair<intV, intV>> bloomMaster;
    std::vector<intB> verEI;
    std::vector<intV> bloomEI;
    std::vector<bool> isNull_bloom;
} BVGraphLoMem;
typedef struct SearchVerIndex
{
    std::vector<intB> A_deg_offset;
    std::vector<intB> B_offset;
    std::vector<intV> block_ver;
} SearchVerIndex;
typedef struct peelTipIndex
{
    std::vector<intB> tipValue;
    std::vector<intV> vCoVertex;
    std::vector<intB> vCoValue;
    std::vector<intV> uCoVertex;
    std::vector<intB> uCoValue;
} peelTipIndex;
struct pair_hash
{
    template<class T1, class T2>
    std::size_t operator() (const std::pair<T1, T2>& p) const
    {
        auto h1 = std::hash<T1>{}(p.first);
        auto h2 = std::hash<T2>{}(p.second);
        return h1 ^ h2;
    }
};
typedef struct Edge {
    intB bitrussness;
    unordered_map<pair<intV, intV>, intE, pair_hash> blooms;
}Edge;
typedef struct Bloom
{
    intV uid;
    intV wid;
    intB bloomWdgCnt;
    unordered_set<intV> Wedges;
}Bloom;
typedef struct Edge_vec {
    intB bitrussness;
    vector<pair<pair<intV, intV>, intE>> blooms;
    void reserve_blooms(size_t expected_size) {
        blooms.reserve(expected_size);
    }
    intE findBloomTwin(const pair<intV, intV>& bloomPair) const {
        for (const auto& item : blooms) {
            if (item.first == bloomPair) {
                return item.second;
            }
        }
        return -1;
    }
    void addBloomPair(const pair<intV, intV>& bloomPair, intE twinEdge) {
        blooms.push_back({bloomPair, twinEdge});
    }
    void removeBloomPair(const pair<intV, intV>& bloomPair) {
        auto it = remove_if(blooms.begin(), blooms.end(),
            [&bloomPair](const auto& item) { return item.first == bloomPair; });
        blooms.erase(it, blooms.end());
    }
}Edge_vec;
typedef struct Bloom_vec
{
    intV uid;
    intV wid;
    intB bloomWdgCnt;
    vector<intV> Wedges;
    void reserve_wedges(size_t expected_size) {
        Wedges.reserve(expected_size);
    }
    void insertWedge(intV v) {
        if (find(Wedges.begin(), Wedges.end(), v) == Wedges.end()) {
            Wedges.push_back(v);
        }
    }
    void eraseWedge(intV v) {
        auto it = remove(Wedges.begin(), Wedges.end(), v);
        Wedges.erase(it, Wedges.end());
    }
    bool containsWedge(intV v) const {
        return find(Wedges.begin(), Wedges.end(), v) != Wedges.end();
    }
    size_t size() const {
        return Wedges.size();
    }
}Bloom_vec;
class Graph
{
private:
    std::vector<uint8_t> deleted;
    void remove_duplicates();
public:
    intV numU;
    intV numV;
    intV numT;
    intE numE;
    intB sumB;
    intV numTT;
    intE max_deg_U;
    intE max_deg_V;
    intV i_U;
    intV i_V;
    intV *ranks;
    intB maxBitrussness;
    std::vector<std::vector<intV>> adj;
    std::vector<std::vector<intE>> eId;
    std::vector<intV> deg;
    std::vector<intV> verDeg;
    std::vector<intV> uLabels;
    std::vector<intV> vLabels;
    std::vector<intV> small_bNum;
    std::vector<bool> weight;
    std::vector<bool> uORv;
    std::vector<pair<intV, intV>> edgeArray;
    std::unordered_map<pair<intV, intV>, intE, pair_hash> edgeToId;
    vector<std::pair<intV, intV>> eIdToV;
    Graph(): numV(0), numU(0), numT(0), numE(0), sumB(0), max_deg_U(0), max_deg_V(0), i_U(0), i_V(0) {}
    Graph(intV V, intV U, intE E): numV(V), numU(U), numT(U+V), numE(E)
    {
        adj.resize(numT);
        uLabels.resize(numU);
        vLabels.resize(numV);
        deg.resize(numT, 0);
        deleted.resize(numT, 0);
        weight.resize(numT, true);
        uORv.resize(numT,false);
        edgeArray.resize(numE);
    }
    inline std::vector<intV>& get_neigh(intV v, intV &degV);
    inline std::vector<intV>& get_neigh_verDeg(intV v, intV &degV);
    inline intV& get_rank(intV v);
    inline void set_rank(vector<intV> &verToLab);
    void sort_adj();
    void sort_adj(std::vector<intV> &priority);
    void sort_deg(std::vector<intV> &opList);
    void sort_label(std::vector<intV> &labToVer, std::vector<intV> &verToLab);
    void sort_bfl(std::vector<intV> &sortedLabels, vector<intB> &butterflyCnt);
    void reorder(std::vector<intV> &newLabels, Graph &outG);
    void reorder_in_place(std::vector<intV> &newLabels);
    void copy(Graph &outG);
    void read_graph(std::string &filename, int peelSide);
    void read_graph_bin(std::string &filename, int peelSide);
    void reformat_graph(Graph &G, vector<bool> &removed, vector<intV> &labToVer);
    inline bool is_deleted(intV v);
    inline bool U_or_V(intV v);
    inline void delete_vertex(intV v);
    inline void restore_vertex(intV v);
    inline void delete_edges();
    inline void restore_edges();
    inline void del_neigh(bool *removed, intV vertex, intV other);
    inline void assign_weight(intV bflThre_l, intV bflThre_r, vector<intB> &butterflyCnt, vector<bool> &weight, vector<intV> &labToVer);
    inline bool whether_change_weight(intV &n, intV vertex, intV bflThre_l, intV bflThre_r, vector<intB> &butterflyCnt, bool *weight, vector<intV> &labToVer);
    inline void get_true_neigh(intV v, intV &degV, bool *weight, vector<intV> &true_adj);
    void get_labels(std::vector<intV> &labels, int side);
    void dump_graph();
    void print_graph();
    void print_orderedGraph(vector<intV> &labalsToVertex, vector<intV> &vertexToLabals);
    ~Graph() {
        for (intV i=0; i<numT; i++)
            free_vec(adj[i]);
        free_vec(adj);
        free_vec(deg);
        free_vec(uLabels);
        free_vec(vLabels);
        free_vec(eId);
        free_vec(deleted);
        free_vec(weight);
    }
};
void Graph::reformat_graph(Graph &G, vector<bool> &removed, vector<intV> &labToVer)
{
    Graph g;
    vector<bool> temp_uORv;
    temp_uORv.resize(numT,false);
    vector<intV> newlabToOldlab(numT);
    sort_deg(newlabToOldlab);
    vector<intV> oldlabToNewlab(numT,0);
    for(intV i = 0; i < numT; i++)
    {
        oldlabToNewlab[newlabToOldlab[i]] = i;
    }
    vector<intV> temp_labToVer(numT);
    for(intV i = 0; i < numT; i++)
    {
        temp_labToVer[i] = labToVer[newlabToOldlab[i]];
    }
    labToVer.swap(temp_labToVer);
    vector<intV> ().swap(temp_labToVer);
    vector<bool> ().swap(temp_uORv);
    vector<vector<intV>> newAdj;
    newAdj.resize(numT);
    for(intV i = 0; i < numT; i++)
    {
        if(!removed[i])
        {
            vector<intV> new_vec(G.deg[i]);
            intV idx = 0;
            for(intV j = 0; j < adj[i].size(); j++)
            {
                if(!removed[adj[i][j]])
                {
                    new_vec[idx++] = oldlabToNewlab[adj[i][j]];
                }
            }
            newAdj[oldlabToNewlab[i]].resize(new_vec.size());
            newAdj[oldlabToNewlab[i]].swap(new_vec);
        }
    }
    vector<intV> ().swap(oldlabToNewlab);
    for(intV i = 0; i < G.numT; i++)
    {
        adj[i].clear();
        adj[i].swap(newAdj[i]);
        vector<intV> ().swap(newAdj[i]);
    }
    G.sort_adj();
    vector<intV> newDeg (numT);
    for(intV i = 0; i < numT; i++)
    {
        newDeg[i] = deg[newlabToOldlab[i]];
    }
    deg.swap(newDeg);
}
void Graph::read_graph(std::string &filename, int peelSide)
{
    FILE* fp = fopen(filename.c_str(), "r");
    if (fp==NULL)
    {
        fputs("file error\n", stderr);
        exit(EXIT_FAILURE);
    }
    printf("reading....\n");
    fpos_t position;
    char buf[256];
    fgetpos(fp, &position);
    fgets(buf, sizeof(buf), fp);
    while((buf[0]=='%') && !feof(fp))
    {
        fgetpos(fp, &position);
        fgets(buf, sizeof(buf), fp);
    }
    if (feof(fp))
        return;
    fsetpos(fp, &position);
    std::vector<std::pair<intV, intV>> edges;
    intV u, v;
    intE e = 0;
    while(!feof(fp))
    {
        if (fscanf(fp, "%d", &u) <= 0)
            break;
        if (fscanf(fp, "%d", &v) <= 0)
            break;
        if (peelSide==1)
            std::swap(u, v);
        numU = std::max(u+1, numU);
        numV = std::max(v+1, numV);
        edges.push_back(std::make_pair(u, v));
        e++;
    }
    fclose(fp);
    cout << "e = " << e << endl;
    numT = numU + numV;
    uLabels.resize(numU);
    for (intV i=0; i<numU; i++)
        uLabels[i] = i;
    vLabels.resize(numV);
    for (intV i=0; i<numV; i++)
        vLabels[i] = i+numU;
    adj.resize(numT);
    intE numEdgesRead = edges.size();
    for (intE i=0; i<numEdgesRead; i++)
    {
        u = edges[i].first; v = edges[i].second+numU;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    deleted.resize(numT, false);
    weight.resize(numT, true);
    uORv.resize(numT,false);
    remove_duplicates();
}
inline std::vector<intV>& Graph::get_neigh(intV v, intV &degV)
{
    degV = deg[v];
    return adj[v];
}
inline void Graph::get_true_neigh(intV v, intV &degV, bool *weight, vector<intV> &true_adj)
{
    degV = deg[v];
    intV deg = 0;
    for(intV i = 0; i < degV; i++)
    {
        if(weight[adj[v][i]] == true)
        {
            true_adj.push_back(adj[v][i]);
            deg++;
        }
    }
    degV = deg;
}
inline std::vector<intV>& Graph::get_neigh_verDeg(intV v, intV &degV)
{
    degV = verDeg[v];
    return adj[v];
}
inline intV& Graph::get_rank(intV v)
{
    return ranks[v];
}
inline void Graph::del_neigh(bool *removed, intV vertex, intV other)
{
    if(!removed[other])
        deg[other]--;
    for(auto it = adj[other].begin(); it != adj[other].end();)
    {
        if(*it == vertex)
        {
            it = adj[other].erase(it);
            break;
        }
        it++;
    }
}
inline void Graph::assign_weight(intV bflThre_l, intV bflThre_r, vector<intB> &butterflyCnt, vector<bool> &weight, vector<intV> &labToVer)
{
    cout << "assign_weight..............." << endl;
    intV toRemove = 0;
    for(intV i = 0; i < numT; i++)
    {
        if((labToVer[i] < numU && butterflyCnt[i] < bflThre_l) || (labToVer[i] >= numU && butterflyCnt[i] < bflThre_r))
        {
            weight[i] = false;
            toRemove++;
        }
        else
        {
            weight[i] = true;
        }
    }
    cout << "end of assign_weight..............." << endl;
    cout << "To remove vertex_num = " << toRemove << endl;
}
inline bool Graph::whether_change_weight(intV &n, intV vertex, intV bflThre_l, intV bflThre_r, vector<intB> &butterflyCnt, bool *weight, vector<intV> &labToVer)
{
    if((weight[vertex] == true && labToVer[vertex] < numU && butterflyCnt[vertex] < bflThre_l) || (weight[vertex] == true && labToVer[vertex] >= numU && butterflyCnt[vertex] < bflThre_r))
     {
         weight[vertex] = false;
         n++;
         return true;
     }
    else
        return false;
}
void Graph::remove_duplicates()
{
    deg.resize(numT);
    verDeg.resize(numT);
    sort_adj();
    for (intV i=0; i<numT; i++)
    {
        intV numNeigh = 0;
        for (intV j=0; j<adj[i].size(); j++)
        {
            if (j==0)
                numNeigh++;
            else if (adj[i][j] != adj[i][j-1])
                numNeigh++;
        }
        deg[i] = numNeigh;
        if(numNeigh!=adj[i].size())
        {
            std::vector<intV> vec(numNeigh);
            numNeigh = 0;
            for (intV j=0; j<adj[i].size(); j++)
            {
                if (j==0)
                    vec[numNeigh++] = adj[i][j];
                else if (adj[i][j] != adj[i][j-1])
                    vec[numNeigh++] = adj[i][j];
            }
            vec.swap(adj[i]);
        }
    }
    intE tempE = 0;
    for (intV i=0; i<numT; i++)
    {
        tempE += deg[i];
       if(i<numU)
       {
           if(deg[i] > max_deg_U)
           {
               i_U = i;
               max_deg_U = deg[i];
           }
       }
       else
       {
           if(deg[i] > max_deg_V)
           {
               i_V = i;
               max_deg_V = deg[i];
           }
       }
    }
   printf("\nmax_deg_U = %u, from: %d, max_deg_V = %u, from: %d\n", max_deg_U, i_U, max_deg_V, i_V);
    numE = tempE/2;
}
void Graph::sort_adj()
{
    for (intV i=0; i<numT; i++)
        std::stable_sort(adj[i].begin(), adj[i].end());
}
void Graph::sort_adj(std::vector<intV> &priority)
{
    for (intV i=0; i<numT; i++)
        serial_sort_kv(adj[i], priority);
}
void Graph::sort_deg(std::vector<intV> &sortedLabels)
{
    sortedLabels.resize(numT);
    for (intV i=0; i<numT; i++)
        sortedLabels[i] = i;
    serial_sort_kv(sortedLabels, deg);
}
void Graph::sort_label(std::vector<intV> &labToVer, std::vector<intV> &verToLab)
{
}
void Graph::sort_bfl(std::vector<intV> &sortedLabels, vector<intB> &butterflyCnt)
{
    sortedLabels.resize(numT);
    vector<intB> bfl(numT);
    for (intV i=0; i<numT; i++)
    {
        sortedLabels[i] = i;
        bfl[i] = butterflyCnt[i];
    }
    serial_sort_kv(sortedLabels, bfl);
}
void Graph::reorder_in_place(std::vector<intV> &newLabels)
{
    std::vector<std::vector<intV>> adjNew (numT);
    std::vector<intV> uNew (numU);
    std::vector<intV> vNew (numV);
    std::vector<intV> degNew (numT);
    std::vector<uint8_t> delNew (numT);
    for (intV i=0; i<numU; i++)
        uNew[i] = newLabels[uLabels[i]];
    for (intV i=0; i<numV; i++)
        vNew[i] = newLabels[vLabels[i]];
    sort_indices(uNew, std::less<intV>());
    sort_indices(vNew, std::less<intV>());
    for (intV i=0; i<numT; i++)
    {
        intV numNeigh = adj[i].size();
        adjNew[newLabels[i]].swap(adj[i]);
        for (intV j=0; j<numNeigh; j++)
            adjNew[newLabels[i]][j] = newLabels[adjNew[newLabels[i]][j]];
        degNew[newLabels[i]] = deg[i];
        delNew[newLabels[i]] = deleted[i];
    }
    uNew.swap(uLabels);
    vNew.swap(vLabels);
    adjNew.swap(adj);
    degNew.swap(deg);
    delNew.swap(deleted);
    sort_adj();
}
inline bool Graph::is_deleted(intV v)
{
    return ((deleted[v]==1) ? true : false);
}
inline void Graph::delete_vertex(intV v)
{
    deleted[v] = 1;
}
inline void Graph::restore_vertex(intV v)
{
    deleted[v] = 0;
}
void Graph::print_graph()
{
    printf("print graph.................\n");
    cout << "numU = " << numU << ", numV = " << numV << ", numT = " << numT << ", numE = " << numE << endl;
    cout << "degree: " << endl;
    intV from_U = -1;
    intV from_V = -1;
    for (intV i=0; i<numT; i++)
    {
        if(i<numU && (deg[uLabels[i]]>max_deg_U))
        {
            max_deg_U = deg[uLabels[i]];
            from_U = uLabels[i];
        }
        if(i<numV && (deg[vLabels[i]]>max_deg_V))
        {
            from_V = vLabels[i];
            max_deg_V = deg[vLabels[i]];
        }
        cout << "deg[" << i << "] = " << deg[i] << " ";
    }
    cout << endl;
    printf("\nmax_deg_U = %u, from: %d,  max_deg_V = %u, from: %d\n", max_deg_U, from_U, max_deg_V, from_V);
    printf("\nadj:\n");
    for (intV i=0; i<numT; i++)
    {
        for (intV j=0; j<deg[i]; j++)
            printf("(%d,%d); ", i, adj[i][j]);
    }
    printf("\nuLabels\n");
    for(intV i = 0; i < numU; i++)
    {
        printf("%d ", uLabels[i]);
    }
    printf("\nvLabels\n");
    for(intV i = 0; i < numV; i++)
    {
        printf("%d ", vLabels[i]);
    }
    printf("\n");
}
void Graph::print_orderedGraph(vector<intV> &labalsToVertex, vector<intV> &vertexToLabals)
{
    printf("print the orderedGraph..................\n");
    printf("print the vertices after sort_deg: \n");
    for(intV i = 0; i < numT; i++)
    {
        printf("%d:%d ", labalsToVertex[i], vertexToLabals[labalsToVertex[i]]);
    }
    printf("\n");
    print_graph();
}
#endif
