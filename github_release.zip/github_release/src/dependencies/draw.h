#ifndef DRAW_H
#define DRAW_H 
#include "graph.h"
#include <fstream>
#include <unordered_map>
#include <algorithm>
#include <cstdlib>
void plot_degree_distribution(Graph &G, const std::string &output_filename = "degree_distribution") {
    std::unordered_map<intV, intV> degree_count;
    for (intV i = 0; i < G.numT; i++) {
        if (!G.is_deleted(i)) {
            intV degree = G.deg[i];
            degree_count[degree]++;
        }
    }
    std::string data_filename = output_filename + ".dat";
    std::ofstream data_file(data_filename);
    if (!data_file.is_open()) {
        std::cerr << "Unable to create data file: " << data_filename << std::endl;
        return;
    }
    std::vector<intV> degrees;
    for (auto &pair : degree_count) {
        degrees.push_back(pair.first);
    }
    std::sort(degrees.begin(), degrees.end());
    for (intV degree : degrees) {
        data_file << degree << " " << degree_count[degree] << std::endl;
    }
    data_file.close();
    std::string script_filename = output_filename + ".gnuplot";
    std::ofstream script_file(script_filename);
    if (!script_file.is_open()) {
        std::cerr << "Unable to create gnuplot script: " << script_filename << std::endl;
        return;
    }
    script_file << "set terminal pdfcairo enhanced font 'Arial,12'" << std::endl;
    script_file << "set output '" << output_filename << ".pdf'" << std::endl;
    script_file << "set title 'Vertex Degree Distribution'" << std::endl;
    script_file << "set xlabel 'Degree'" << std::endl;
    script_file << "set ylabel 'Number of Vertices'" << std::endl;
    script_file << "set grid" << std::endl;
    script_file << "plot '" << data_filename << "' with lines title 'Degree Distribution' linewidth 2" << std::endl;
    script_file << "exit" << std::endl;
    script_file.close();
    std::string command = "gnuplot " + script_filename;
    int result = system(command.c_str());
    if (result != 0) {
        std::cerr << "gnuplot command failed; install gnuplot" << std::endl;
        return;
    }
    std::cout << "Degree distribution plot written to: " << output_filename << ".pdf" << std::endl;
}
void plot_edge_support_distribution(const std::vector<intE> &tipVal, const std::string &output_filename = "edge_support_distribution") {
    std::unordered_map<intE, intE> support_count;
    for (intE i = 0; i < tipVal.size(); i++) {
        intE support = tipVal[i];
        support_count[support]++;
    }
    std::string data_filename = output_filename + ".dat";
    std::ofstream data_file(data_filename);
    if (!data_file.is_open()) {
        std::cerr << "Unable to create data file: " << data_filename << std::endl;
        return;
    }
    std::vector<intE> supports;
    for (auto &pair : support_count) {
        supports.push_back(pair.first);
    }
    std::sort(supports.begin(), supports.end());
    for (intE support : supports) {
        data_file << support << " " << support_count[support] << std::endl;
    }
    data_file.close();
    std::string script_filename = output_filename + ".gnuplot";
    std::ofstream script_file(script_filename);
    if (!script_file.is_open()) {
        std::cerr << "Unable to create gnuplot script: " << script_filename << std::endl;
        return;
    }
    script_file << "set terminal pdfcairo enhanced font 'Arial,12'" << std::endl;
    script_file << "set output '" << output_filename << ".pdf'" << std::endl;
    script_file << "set title 'Edge Support Distribution'" << std::endl;
    script_file << "set xlabel 'Support (Number of Butterflies)'" << std::endl;
    script_file << "set ylabel 'Number of Edges'" << std::endl;
    script_file << "set grid" << std::endl;
    script_file << "plot '" << data_filename << "' with lines title 'Edge Support Distribution' linewidth 2" << std::endl;
    script_file << "exit" << std::endl;
    script_file.close();
    std::string command = "gnuplot " + script_filename;
    int result = system(command.c_str());
    if (result != 0) {
        std::cerr << "gnuplot command failed; install gnuplot" << std::endl;
        return;
    }
    std::cout << "Edge support distribution plot written to: " << output_filename << ".pdf" << std::endl;
}
void plot_edge_support_cumulative_distribution(const std::vector<intE> &tipVal, const std::string &output_filename = "edge_support_cumulative_distribution") {
    std::unordered_map<intE, intE> support_count;
    intE total_edges = tipVal.size();
    for (intE i = 0; i < tipVal.size(); i++) {
        intE support = tipVal[i];
        support_count[support]++;
    }
    std::vector<intE> supports;
    for (auto &pair : support_count) {
        supports.push_back(pair.first);
    }
    std::sort(supports.begin(), supports.end());
    std::vector<double> cumulative_distribution;
    intE cumulative_count = 0;
    for (intE support : supports) {
        cumulative_count += support_count[support];
        double cumulative_ratio = static_cast<double>(cumulative_count) / total_edges;
        cumulative_distribution.push_back(cumulative_ratio);
    }
    std::string data_filename = output_filename + ".dat";
    std::ofstream data_file(data_filename);
    if (!data_file.is_open()) {
        std::cerr << "Unable to create data file: " << data_filename << std::endl;
        return;
    }
    for (int i = 0; i < supports.size(); i++) {
        data_file << supports[i] << " " << cumulative_distribution[i] << std::endl;
    }
    data_file.close();
    std::string script_filename = output_filename + ".gnuplot";
    std::ofstream script_file(script_filename);
    if (!script_file.is_open()) {
        std::cerr << "Unable to create gnuplot script: " << script_filename << std::endl;
        return;
    }
    script_file << "set terminal pdfcairo enhanced font 'Arial,12'" << std::endl;
    script_file << "set output '" << output_filename << ".pdf'" << std::endl;
    script_file << "set title 'Edge Support Cumulative Distribution'" << std::endl;
    script_file << "set xlabel 'Support (Number of Butterflies)'" << std::endl;
    script_file << "set ylabel 'Cumulative Percentage of Edges'" << std::endl;
    script_file << "set yrange [0:1]" << std::endl;
    script_file << "set format y \"%.2f\"" << std::endl;
    script_file << "set grid" << std::endl;
    script_file << "plot '" << data_filename << "' with lines title 'Cumulative Distribution' linewidth 2" << std::endl;
    script_file << "exit" << std::endl;
    script_file.close();
    std::string command = "gnuplot " + script_filename;
    int result = system(command.c_str());
    if (result != 0) {
        std::cerr << "gnuplot command failed; install gnuplot" << std::endl;
        return;
    }
    std::cout << "Edge support CDF plot written to: " << output_filename << ".pdf" << std::endl;
}
void plot_multi_edge_support_cumulative_distribution(
    const std::vector<std::vector<intE>> &tipVal_list,
    const std::vector<std::string> &dataset_names,
    const std::string &output_filename = "multi_edge_support_cumulative_distribution") {
    if (tipVal_list.size() != dataset_names.size()) {
        std::cerr << "Dataset count and name count differ" << std::endl;
        return;
    }
    int num_datasets = tipVal_list.size();
    std::vector<std::map<intE, double>> cumulative_distributions(num_datasets);
    for (int i = 0; i < num_datasets; i++) {
        const std::vector<intE> &tipVal = tipVal_list[i];
        std::unordered_map<intE, intE> support_count;
        intE total_edges = tipVal.size();
        for (intE j = 0; j < tipVal.size(); j++) {
            intE support = tipVal[j];
            support_count[support]++;
        }
        std::vector<intE> supports;
        for (auto &pair : support_count) {
            supports.push_back(pair.first);
        }
        std::sort(supports.begin(), supports.end());
        intE cumulative_count = 0;
        for (intE support : supports) {
            cumulative_count += support_count[support];
            double cumulative_ratio = static_cast<double>(cumulative_count) / total_edges;
            cumulative_distributions[i][support] = cumulative_ratio;
        }
    }
    std::string data_filename = output_filename + ".dat";
    std::ofstream data_file(data_filename);
    if (!data_file.is_open()) {
        std::cerr << "Unable to create data file: " << data_filename << std::endl;
        return;
    }
    std::set<intE> all_supports;
    for (int i = 0; i < num_datasets; i++) {
        for (auto &pair : cumulative_distributions[i]) {
            all_supports.insert(pair.first);
        }
    }
    for (intE support : all_supports) {
        data_file << support;
        for (int i = 0; i < num_datasets; i++) {
            if (cumulative_distributions[i].count(support)) {
                data_file << " " << cumulative_distributions[i][support];
            } else {
                auto it = cumulative_distributions[i].lower_bound(support);
                if (it != cumulative_distributions[i].begin()) {
                    --it;
                    data_file << " " << it->second;
                } else {
                    data_file << " 0";
                }
            }
        }
        data_file << std::endl;
    }
    data_file.close();
    std::string script_filename = output_filename + ".gnuplot";
    std::ofstream script_file(script_filename);
    if (!script_file.is_open()) {
        std::cerr << "Unable to create gnuplot script: " << script_filename << std::endl;
        return;
    }
    script_file << "set terminal pdfcairo enhanced font 'Arial,12'" << std::endl;
    script_file << "set output '" << output_filename << ".pdf'" << std::endl;
    script_file << "set title 'Bitrussness Cumulative Distribution'" << std::endl;
    script_file << "set xlabel 'Bitrussness'" << std::endl;
    script_file << "set ylabel 'Cumulative Percentage of Edges'" << std::endl;
    script_file << "set logscale x" << std::endl;
    script_file << "set yrange [0:1]" << std::endl;
    script_file << "set format y \"%.2f\"" << std::endl;
    script_file << "set grid" << std::endl;
    const std::vector<std::string> colors = {"red", "blue", "green", "purple", "orange", "cyan", "magenta", "yellow"};
    script_file << "plot ";
    for (int i = 0; i < num_datasets; i++) {
        if (i > 0) {
            script_file << ", ";
        }
        std::string color = colors[i % colors.size()];
        script_file << "'" << data_filename << "' using 1:" << (i + 2)
                   << " with lines title '" << dataset_names[i] << "' linewidth 2 lc rgb '" << color << "'";
    }
    script_file << std::endl;
    script_file << "exit" << std::endl;
    script_file.close();
    std::string command = "gnuplot " + script_filename;
    int result = system(command.c_str());
    if (result != 0) {
        std::cerr << "gnuplot command failed; install gnuplot" << std::endl;
        return;
    }
    std::cout << "Multi-dataset edge support CDF written to: " << output_filename << ".pdf" << std::endl;
}
#endif
