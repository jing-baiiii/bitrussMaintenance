#ifndef KHeap_h
#define KHeap_h 
#include <vector>
#include <algorithm>
#include <limits>
template<typename V, typename K, unsigned k = 4> class KHeap {
    size_t size;
    size_t invalid;
    std::vector<V> heap;
    std::vector<size_t> heap_pos;
    std::vector<K> key;
    void swap(size_t i, size_t j) {
        std::swap(heap_pos[heap[i]], heap_pos[heap[j]]);
        std::swap(heap[i], heap[j]);
    }
    size_t kid(size_t i) const {
        size_t c0 = i*k+1, m = 0;
        for (size_t j = 1; j < k && c0 + j < size; ++j)
            if (key[heap[c0 + j]] < key[heap[c0 + m]]) m = j;
        return c0 + m;
    }
    void fixup(size_t i) {
        size_t c;
        while(i*k + 1 < size && key[heap[i]] > key[heap[(c=kid(i))]]) { swap(i, c); i = c; }
        while(i > 0 && key[heap[i]] < key[heap[(i-1)/k]]) { swap(i, (i-1)/k); i = (i-1)/k; }
    }
public:
    KHeap(size_t n) : size(0), invalid(std::numeric_limits<size_t>::max()), heap(n), heap_pos(n, invalid), key(n) {}
    bool empty() const { return size == 0; }
    std::pair<V, K> top() const { return std::make_pair(heap[0], key[heap[0]]); }
    V pop() { std::pair<V, K> kvp = top(); V v = kvp.first; extract(v); return v; }
    void update(V v, K kk) {
        if (heap_pos[v] == invalid) { heap_pos[v] = size++; heap[heap_pos[v]] = v; }
        key[v] = kk;
        fixup(heap_pos[v]);
    }
    void extract(V v) {
        if (heap_pos[v] == invalid) return;
        if (heap_pos[v] < --size) {
            size_t pos = heap_pos[v];
            swap(pos, size);
            fixup(pos);
        }
        heap_pos[v] = invalid;
    }
    void clear() {
        for (size_t i = 0; i < size; ++i) heap_pos[heap[i]] = invalid;
        size = 0;
    }
};
template<typename V, typename K, unsigned k = 4> class KHeap_large {
    size_t size;
    size_t invalid;
    std::vector<V> heap;
    std::vector<size_t> heap_pos;
    std::vector<K> key;
    void swap(size_t i, size_t j) {
        std::swap(heap_pos[heap[i]], heap_pos[heap[j]]);
        std::swap(heap[i], heap[j]);
    }
    size_t kid(size_t i) const {
        size_t c0 = i*k+1, m = 0;
        for (size_t j = 1; j < k && c0 + j < size; ++j)
            if (key[heap[c0 + j]] > key[heap[c0 + m]]) m = j;
        return c0 + m;
    }
    void fixup(size_t i) {
        size_t c;
        while(i*k + 1 < size && key[heap[i]] < key[heap[(c=kid(i))]]) { swap(i, c); i = c; }
        while(i > 0 && key[heap[i]] > key[heap[(i-1)/k]]) { swap(i, (i-1)/k); i = (i-1)/k; }
    }
public:
    KHeap_large(size_t n) : size(0), invalid(std::numeric_limits<size_t>::max()), heap(n), heap_pos(n, invalid), key(n) {}
    bool empty() const { return size == 0; }
    std::pair<V, K> top() const { return std::make_pair(heap[0], key[heap[0]]); }
    V pop() { std::pair<V, K> kvp = top(); V v = kvp.first; extract(v); return v; }
    void update(V v, K kk) {
        if (heap_pos[v] == invalid) { heap_pos[v] = size++; heap[heap_pos[v]] = v; }
        key[v] = kk;
        fixup(heap_pos[v]);
    }
    void extract(V v) {
        if (heap_pos[v] == invalid) return;
        if (heap_pos[v] < --size) {
            size_t pos = heap_pos[v];
            swap(pos, size);
            fixup(pos);
        }
        heap_pos[v] = invalid;
    }
    void clear() {
        for (size_t i = 0; i < size; ++i) heap_pos[heap[i]] = invalid;
        size = 0;
    }
};
#endif
