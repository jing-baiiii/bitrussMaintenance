#ifndef THRESHOLD_FILTERED_EDGE_HEAP_VEC_H
#define THRESHOLD_FILTERED_EDGE_HEAP_VEC_H 
#include <iostream>
#include "arrayOpsCount.h"
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <limits>
#include <utility>
#include "graph.h"
class ThresholdFilteredEdgeHeap_vec {
private:
    std::vector<std::pair<intE, intB>> edges;
    std::unordered_map<intE, size_t> edgeIndexMap;
    bool isSorted;
    intB minWeight;
    bool minWeightValid;
    void updateMinWeight() {
        if (edges.empty()) {
            minWeightValid = false;
            return;
        }
        minWeight = std::numeric_limits<intB>::max();
        for (const auto& [edgeId, weight] : edges) {
            OPS_ALG();
            if (weight < minWeight) {
                minWeight = weight;
            }
        }
        minWeightValid = true;
    }
    void ensureSorted() {
        if (!isSorted) {
            std::unordered_map<intE, size_t> oldMap = edgeIndexMap;
            std::sort(edges.begin(), edges.end(),
                     [](const auto& a, const auto& b) { OPS_ALG(); return a.second < b.second; });
            for (size_t i = 0; i < edges.size(); i++) {
                OPS_ALG();
                edgeIndexMap[edges[i].first] = i;
            }
            isSorted = true;
        }
    }
public:
    ThresholdFilteredEdgeHeap_vec() : isSorted(false), minWeightValid(false) {}
    void addEdge(intE edgeId, intB weight) {
        auto it = edgeIndexMap.find(edgeId);
        if (it != edgeIndexMap.end()) {
            removeEdge(edgeId);
        }
        edges.emplace_back(edgeId, weight);
        edgeIndexMap[edgeId] = edges.size() - 1;
        isSorted = false;
        if (!minWeightValid || weight < minWeight) {
            minWeight = weight;
            minWeightValid = true;
        }
    }
    intB getWeight(intE edgeId) const {
        auto it = edgeIndexMap.find(edgeId);
        if (it == edgeIndexMap.end()) {
            throw std::runtime_error("Edge not found");
        }
        return edges[it->second].second;
    }
    bool tryGetWeight(intE edgeId, intB& weight) const {
        auto it = edgeIndexMap.find(edgeId);
        if (it == edgeIndexMap.end()) {
            return false;
        }
        weight = edges[it->second].second;
        return true;
    }
    void updateEdgeWeight(intE edgeId, intB newWeight) {
        auto it = edgeIndexMap.find(edgeId);
        if (it == edgeIndexMap.end()) {
            throw std::runtime_error("Edge not found");
        }
        size_t index = it->second;
        intB oldWeight = edges[index].second;
        edges[index].second = newWeight;
        isSorted = false;
        if (oldWeight == minWeight) {
            updateMinWeight();
        }
        if (!minWeightValid || newWeight < minWeight) {
            minWeight = newWeight;
            minWeightValid = true;
        }
    }
    void removeEdge(intE edgeId) {
        auto it = edgeIndexMap.find(edgeId);
        if (it == edgeIndexMap.end()) {
            return;
        }
        size_t index = it->second;
        intB weight = edges[index].second;
        if (index < edges.size() - 1) {
            intE lastEdgeId = edges.back().first;
            edges[index] = edges.back();
            edgeIndexMap[lastEdgeId] = index;
        }
        edges.pop_back();
        edgeIndexMap.erase(it);
        isSorted = false;
        if (weight == minWeight) {
            updateMinWeight();
        }
    }
    std::vector<intE> getEdgesLessOrEqual(intB threshold) {
        ensureSorted();
        std::vector<intE> result;
        auto it = std::upper_bound(edges.begin(), edges.end(), threshold,
                                 [](intB val, const auto& pair) { return val < pair.second; });
        for (auto edgeIt = edges.begin(); edgeIt != it; ++edgeIt) {
            result.push_back(edgeIt->first);
        }
        return result;
    }
    std::vector<intE> removeAllEdgesLessOrEqual(intB threshold) {
        ensureSorted();
        std::vector<intE> removedEdges;
        auto it = std::upper_bound(edges.begin(), edges.end(), threshold,
                                 [](intB val, const auto& pair) { return val < pair.second; });
        for (auto edgeIt = edges.begin(); edgeIt != it; ++edgeIt) {
            OPS_ALG();
            removedEdges.push_back(edgeIt->first);
            edgeIndexMap.erase(edgeIt->first);
        }
        edges.erase(edges.begin(), it);
        for (size_t i = 0; i < edges.size(); i++) {
            OPS_ALG();
            edgeIndexMap[edges[i].first] = i;
        }
        updateMinWeight();
        isSorted = edges.empty() || edges.size() == 1;
        return removedEdges;
    }
    std::vector<intE> getEdgesGreaterThan(intB threshold) {
        ensureSorted();
        std::vector<intE> result;
        auto it = std::upper_bound(edges.begin(), edges.end(), threshold,
                                 [](intB val, const auto& pair) { return val < pair.second; });
        for (auto edgeIt = it; edgeIt != edges.end(); ++edgeIt) {
            result.push_back(edgeIt->first);
        }
        return result;
    }
    std::vector<std::pair<intE, intB>> getAllEdgesWithWeights() const {
        return edges;
    }
    bool contains(intE edgeId) const {
        return edgeIndexMap.find(edgeId) != edgeIndexMap.end();
    }
    intB getMinWeight() const {
        if (!minWeightValid) {
            throw std::runtime_error("Heap is empty");
        }
        return minWeight;
    }
    std::vector<intE> getAllEdges() const {
        std::vector<intE> result;
        result.reserve(edges.size());
        for (const auto& edge : edges) {
            result.push_back(edge.first);
        }
        return result;
    }
    bool hasEdgesLessOrEqual(intB threshold) const {
        if (!minWeightValid) {
            return false;
        }
        return minWeight <= threshold;
    }
    void printAllEdges() const {
        std::cout << "ThresholdFilteredEdgeHeap contains " << edges.size() << " edges:" << std::endl;
        if (edges.empty()) {
            std::cout << "  empty heap" << std::endl;
            return;
        }
        for (const auto& [edgeId, weight] : edges) {
            std::cout << "  edge ID: " << edgeId << ", weight: " << weight << std::endl;
        }
    }
    void printAllEdgesFile(std::ostream& os = std::cout) const {
        os << "ThresholdFilteredEdgeHeap contains " << edges.size() << " edges:" << std::endl;
        if (edges.empty()) {
            os << "  empty heap" << std::endl;
            return;
        }
        for (const auto& [edgeId, weight] : edges) {
            os << "  edge ID: " << edgeId << ", weight: " << weight << std::endl;
        }
    }
    size_t size() const {
        return edges.size();
    }
    void clear() {
        edges.clear();
        edgeIndexMap.clear();
        isSorted = false;
        minWeightValid = false;
    }
};
#endif
