#ifndef statistics_h
#define statistics_h 
#include "graph.h"
#include <iomanip>
void print_statistiics(Graph &G, vector<intB> &butterflyCnt, intV &bflThre_l, intV &bflThre_r)
{
    printf("\nprint some statistics................\n");
    printf("G.numE = %d, G.numT = %d, G.numU = %d. G.numV = %d\n", G.numE, G.numT, G.numU, G.numV);
    intV bflThre = min(bflThre_l,bflThre_r);
    printf("bflThre_l = %d, bflThre_r = %d, bflThre_min = %d\n", bflThre_l, bflThre_r, bflThre);
    intE max_deg_U = 0;
    intE max_deg_V = 0;
    intV i_U = -1;
    intV i_V = -1;
    intV remained_U = 0;
    intV remained_V = 0;
    vector<intV> labelsToVertex (G.numT);
    G.small_bNum.clear();
    for(intV i = 0; i < G.numT; i++)
    {
        if(i < G.numU)
        {
            labelsToVertex[G.uLabels[i]] = i;
        }
        else
        {
            labelsToVertex[G.vLabels[i - G.numU]] = i + G.numU;
        }
    }
    for (intV i=0; i<G.numT; i++)
    {
        if(labelsToVertex[i]<G.numU)
        {
            if(G.deg[i] != 0) remained_U++;
            if(G.deg[i] > max_deg_U)
            {
                i_U = i;
                max_deg_U = G.deg[i];
            }
        }
        else
        {
            if(G.deg[i] != 0) remained_V++;
            if(G.deg[i] > max_deg_V)
            {
                i_V = i;
                max_deg_V = G.deg[i];
            }
        }
    }
    printf("max_deg_U = %u, from: %d, max_deg_V = %u, from: %d\n", max_deg_U, i_U, max_deg_V, i_V);
    printf("remained_vertices = %d, remained_U = %d, remained_V: %d\n", remained_U+remained_V, remained_U, remained_V);
    for (intV i = 0; i < G.numT; i++)
    {
        if((G.deg[i] != 0) && (butterflyCnt[i] < bflThre))
        {
            G.small_bNum.push_back(i);
        }
    }
    if(!G.small_bNum.size())
    {
        printf("There is no result that meets the bflThre and degThre!\n");
        return;
    }
    printf("vertex: %d, who has the max deg in U, butterfly num is: %lld;\nvertex: %d, who has the max deg in V, butterfly num is: %lld\n", i_U, butterflyCnt[i_U], i_V, butterflyCnt[i_V]);
    intE sumDeg = 0;
    intE maxDeg = 0;
    for(intV i = 0; i < G.small_bNum.size(); i++)
    {
        sumDeg = sumDeg + G.deg[G.small_bNum[i]];
        maxDeg = max(maxDeg,G.deg[G.small_bNum[i]]);
    }
    printf("the number of vertices (whose bNum is smaller than %u) is: %lu, they have an average degree: %lu, the max degree: %u\n", bflThre, G.small_bNum.size(), sumDeg/G.small_bNum.size(), maxDeg);
    G.small_bNum.clear();
    for (intV i = 0; i < G.numT; i++)
    {
        if((G.deg[i] != 0) && (butterflyCnt[i] == 0))
        {
            G.small_bNum.push_back(i);
        }
    }
    if(!G.small_bNum.size())
    {
        printf("There is no result that meets the bflThre and degThre!\n");
        return;
    }
    sumDeg = 0;
    maxDeg = 0;
    for(intV i = 0; i < G.small_bNum.size(); i++)
    {
        sumDeg = sumDeg + G.deg[G.small_bNum[i]];
        maxDeg = max(maxDeg,G.deg[G.small_bNum[i]]);
    }
    printf("the number of vertices (whose bNum is 0) is: %lu, they have an average degree: %lu, the max degree: %u\n", G.small_bNum.size(), sumDeg/G.small_bNum.size(), maxDeg);
}
void print_vec(vector<intV> vec)
{
    intB sum = 0;
    intB count = 0;
    intB max = 0;
    for(intV i = 0; i < vec.size(); i++)
    {
        if(vec[i])
        {
            sum +=vec[i];
            count++;
            if(vec[i] > max)
            {
                max = vec[i];
            }
        }
    }
    cout << "max = " << max<< ", sum = " << sum;
    printf("\n");
}
void print_vec(vector<intB> vec)
{
    printf("\nprint this vector: (i,vec[i])\n");
    intB sum = 0;
    for(intV i = 0; i < vec.size(); i++)
    {
       printf("(%d,%lld), ",i,vec[i]);
        sum +=vec[i];
    }
    cout << endl<< "sum = " << sum<< ", vec.size = " << vec.size();
    printf("\n");
}
void print_vec(vector<bool> vec)
{
    printf("\nprint this vector: (i,vec[i])\n");
    intB sum = 0;
    intV count = 0;
    for(intV i = 0; i < vec.size(); i++)
    {
        if(vec[i])
        {
            sum +=vec[i];
            count ++;
        }
    }
    cout << endl<< "sum = " << sum<< ", ver_sum = " << count;
    printf("\n");
}
void print_vec_vec(vector<vector<intV>> vec, intV length)
{
    printf("\nprint this vector<vector< >>: (i,vec[i][j])\n");
    for(intV i = 0; i < length; i++)
    {
        for(intV j = 0; j < vec[i].size(); j++)
        {
            printf("(%d,%d), ",i,vec[i][j]);
        }
        cout << "vec[" << i << "].capacity = " << vec[i].capacity() << endl;
    }
    printf("\n");
}
void print_array(intV *array, intV length)
{
    printf("\nprint this array: (i,array[i]), length of %d\n", length);
    for(intV i = 0; i < length; i++)
    {
    }
    printf("\n");
}
void print_array_all(intV *array, intV length)
{
    printf("\nprint this array: (i,array[i]), length of %d\n", length);
    for(intV i = 0; i < length; i++)
    {
        printf("[%d] = %d, ",i,array[i]);
    }
    printf("\n");
}
void print_array(bool *array, intV length)
{
    printf("\nprint this array: (i,array[i]), length of %d\n",length);
    for(intV i = 0; i < length; i++)
    {
    }
    printf("\n");
}
void print_array_all(bool *array, intV length)
{
    printf("\nprint this array: (i,array[i]), length of %d\n",length);
    for(intV i = 0; i < length; i++)
    {
        printf("[%d] = %d, ",i,array[i]);
    }
    printf("\n");
}
void print_vec_all(vector<intB> vec)
{
    printf("\nprint this vector: (i,vec[i])\n");
    intB sum = 0;
    for(intV i = 0; i < vec.size(); i++)
    {
       printf("(%d,%lld), ",i,vec[i]);
        sum +=vec[i];
    }
    cout << endl<< "sum = " << sum<< ", vec.size = " << vec.size();
    printf("\n");
}
void print_vec_all(vector<intV> vec)
{
    printf("\nprint this vector: (i,vec[i])\n");
    intB sum = 0;
    intB count = 0;
    for(intV i = 0; i < vec.size(); i++)
    {
       printf("(%d,%d), ",i,vec[i]);
        if(vec[i])
        {
            sum +=vec[i];
            count++;
        }
    }
    cout << endl<< "sum = " << sum<< ", vec.size = " << vec.size();
    printf("\n");
}
void print_vec_all(vector<bool> vec)
{
    printf("\nprint this vector: (i,vec[i])\n");
    intB sum = 0;
    for(intV i = 0; i < vec.size(); i++)
    {
       cout<< "(" << i << "," << vec[i] << "), ";
        sum +=vec[i];
    }
    cout << endl<< "sum = " << sum<< ", vec.size = " << vec.size();
    printf("\n");
}
void print_sumB(vector<intB> &butterflyCnt, intV length)
{
    printf("\nprint statistics of butterfly: \n");
    intB sum = 0;
    intB max = 0;
    intB min = butterflyCnt[0];
    intV max_ver = 0;
    intV min_ver = 0;
    intV ver_sum = 0;
    intV ver_erro = 0;
    for (intV i = 0; i < length; i++)
    {
        sum += butterflyCnt[i];
        if(butterflyCnt[i]!=0)
            ver_sum++;
        if(butterflyCnt[i] < 0)
            ver_erro++;
        if (max < butterflyCnt[i])
        {
            max = butterflyCnt[i];
            max_ver = i;
        }
        if (min > butterflyCnt[i])
        {
            min = butterflyCnt[i];
            min_ver = i;
        }
    }
    cout << "maxButterfly = " << max << ", from: " << max_ver << endl;
    cout << "minButterfly = " << min << ", from: " << min_ver << endl;
    cout << "sumButterfly = " << sum/4 << endl;
    cout << "ver_sum = " << ver_sum << endl;
    cout << "ver_erro = " << ver_erro << endl;
    cout << "length = " << length << endl;
}
void print_statisticsOfNewGraph(Graph &G)
{
    intE edge_sum = 0;
    for(intV i = 0; i < G.numT; i++)
    {
        edge_sum += G.adj[i].size();
    }
    cout << "Total edges in the new graph: " << edge_sum << endl;
}
void print_vec_pair (vector<pair<intB, intE>> &vec_pair)
{
    cout << endl;
    for(auto i : vec_pair)
    {
        cout << "vec_pair: (" << i.first << "," << i.second << ")"<< endl;
    }
    cout << "vec_pair.size = " << vec_pair.size() << endl;
}
void print_vec_pair (vector<pair<intE, intE>> &vec_pair)
{
    cout << endl;
    for(auto i : vec_pair)
    {
        cout << "vec_pair: (" << i.first << "," << i.second << ")"<< endl;
    }
    cout << "vec_pair.size = " << vec_pair.size() << endl;
}
void print_BEIndex_graph(BEGraphLoMem &BEG)
{
    cout << endl <<"print index (BEG).........................." << endl;
    cout << "numU (edges of G) = " << BEG.numU << ", numV (blooms) = " << BEG.numV << ", numE (edges in BE Index) = " << BEG.numE << endl;
    cout << "edgeVI (edgeID, offsets for U):";
    print_vec(BEG.edgeVI);
    cout << "edgeEI (edges from U(offset) to V(i.second) / (bloom ID, neighbor edge ID)):";
    print_vec_pair(BEG.edgeEI);
    cout << "bloomVI (offsets for V):";
    print_vec(BEG.bloomVI);
    cout << "bloomEI (edges to V to U (transpose of edgeEI), the twin pair in blooms):";
    print_vec_pair(BEG.bloomEI);
    cout << "edgeDegree:";
    print_vec(BEG.edgeDegree);
    cout << "bloomDegree:";
    print_vec(BEG.bloomDegree);
    cout << "bloomWdgCnt:";
    print_vec(BEG.bloomWdgCnt);
}
void print_BVIndex_graph(BVGraphLoMem &BVG)
{
    cout << endl <<"print index (BVG).........................." << endl;
    cout << "numU (vertices of G) = " << BVG.numU << ", numV (blooms) = " << BVG.numV << ", numE (edges in BV Index) = " << BVG.numE << endl;
    cout << "verVI (verID, offsets for U): " << BVG.verVI.size()<<endl;
    cout << "verEI (vertices from U(offset) to bloom ID: "<< BVG.verEI.size()<<endl;
    cout << "bloomVI (offsets for V): "<<BVG.bloomVI.size()<<endl;
    cout << "bloomEI (which vertices are in the blooms): " << BVG.bloomEI.size()<<endl;
    cout << "bloomMaster ((ver, ver), they are the two master vertices of the bloom):";
    print_vec_pair(BVG.bloomMaster);
}
void print_SVIndex(SearchVerIndex &SVI)
{
    cout << "print SearchVerIndex..................." << endl;
    cout << "A_deg_offset:";
    print_vec(SVI.A_deg_offset);
    cout << "B_offset:";
    print_vec(SVI.B_offset);
    cout << "block_ver:";
    print_vec(SVI.block_ver);
}
void print_PTIndex(peelTipIndex &PTI)
{
    cout <<endl<< "print peelTipIndex......................." << endl;
    cout << "tipValue:";
    print_vec_all(PTI.tipValue);
    cout << "print vCoVertex:";
    print_vec_all(PTI.vCoVertex);
    cout << "print vCoValue:";
    print_vec_all(PTI.vCoValue);
    cout << "print uCovertex:";
    print_vec_all(PTI.uCoVertex);
    cout << "print uCoValue:";
    print_vec_all(PTI.uCoValue);
}
pair<intV,intV> insertEdge(Graph &G)
{
    vector<intV> uOrder(G.numU);
    for(intV i = 0; i < G.numU; i++) uOrder[i] = i;
    for(intV i = G.numU - 1; i > 0; i--)
    {
        intV j = rand() % (i + 1);
        swap(uOrder[i], uOrder[j]);
    }
    for(intV oi = 0; oi < G.numU; oi++)
    {
        intV u = G.uLabels[uOrder[oi]];
        if(G.deg[u] < 1) continue;
        for(intV i = 0; i < G.deg[u]; i++)
        {
            intV vp = G.adj[u][i];
            for(intV j = 0; j < G.deg[vp]; j++)
            {
                intV up = G.adj[vp][j];
                if(up == u) continue;
                if(G.deg[up] < 2) continue;
                for(intV k = 0; k < G.deg[up]; k++)
                {
                    intV v = G.adj[up][k];
                    if(v == vp) continue;
                    if(!isVertexInSet(G.adj[u], static_cast<unsigned int>(v)))
                    {
                        cout << "insertEdge: new edge u=" << u
                            << " v=" << v << " u'=" << up
                            << " v'=" << vp << endl;
                        return make_pair(u, v);
                    }
                }
            }
        }
    }
    cout << "insertEdge: no eligible edge found, returning dummy pair" << endl;
    return make_pair(G.numT, G.numT);
}
pair<intV, intV> removeEdge(Graph &G)
{
    vector<intV> uOrder(G.numU);
    for(intV i = 0; i < G.numU; i++) uOrder[i] = i;
    for(intV i = G.numU - 1; i > 0; i--)
    {
        intV j = rand() % (i + 1);
        swap(uOrder[i], uOrder[j]);
    }
    for(intV oi = 0; oi < G.numU; oi++)
    {
        intV u = G.uLabels[uOrder[oi]];
        if(G.deg[u] < 2) continue;
        for(intV i = 0; i < G.deg[u]; i++)
        {
            intV v = G.adj[u][i];
            if(G.deg[v] < 2) continue;
            for(intV j = 0; j < G.deg[v]; j++)
            {
                intV up = G.adj[v][j];
                if(up == u) continue;
                if(G.deg[up] < 2) continue;
                intV x = 0, y = 0;
                while(x < G.deg[u] && y < G.deg[up])
                {
                    if(G.adj[u][x] == G.adj[up][y])
                    {
                        if(G.adj[u][x] != v)
                        {
                            cout << "removeEdge: butterfly edge u=" << u
                                 << " v=" << v << " u'=" << up
                                 << " v'=" << G.adj[u][x] << endl;
                            return make_pair(u, v);
                        }
                        x++; y++;
                    }
                    else if(G.adj[u][x] < G.adj[up][y])
                        x++;
                    else
                        y++;
                }
            }
        }
    }
    cout << "removeEdge: no butterfly edge found, returning random existing edge" << endl;
    while(1)
    {
        intV pos = rand() % G.numU;
        intV u = G.uLabels[pos];
        if(G.deg[u] < 1) continue;
        intV posv = rand() % G.deg[u];
        intV v = G.adj[u][posv];
        return make_pair(u, v);
    }
}
bool readBloomStatsAndMaxBloom(const string &beIndexFile, int &bloomCount, intV &maxWedgeSize, vector<intV> &maxBloomWedges, ofstream &outFile, pair<intV,intV> *maxBloomMaster = nullptr)
{
    ifstream inFile(beIndexFile);
    if(!inFile.is_open())
    {
        cerr << "readBloomStatsAndMaxBloom: cannot open file " << beIndexFile << endl;
        outFile << "readBloomStatsAndMaxBloom: cannot open file " << beIndexFile << endl;
        return false;
    }
    inFile >> bloomCount;
    unordered_map<int, int> cntFreq;
    maxWedgeSize = 0;
    maxBloomWedges.clear();
    for(int i = 0; i < bloomCount; i++)
    {
        intV uid, wid;
        int bloomWdgCnt;
        inFile >> uid >> wid >> bloomWdgCnt;
        intV wedgeSize;
        inFile >> wedgeSize;
        vector<intV> wedges(wedgeSize);
        for(int j = 0; j < wedgeSize; j++)
            inFile >> wedges[j];
        cntFreq[bloomWdgCnt]++;
        if(wedgeSize > maxWedgeSize)
        {
            maxWedgeSize = wedgeSize;
            maxBloomWedges = wedges;
            if(maxBloomMaster)
                *maxBloomMaster = make_pair(uid, wid);
        }
    }
    inFile.close();
    cout << "========== BEIndex Bloom Statistics ==========" << endl;
    outFile << "========== BEIndex Bloom Statistics ==========" << endl;
    cout << "Total blooms: " << bloomCount << endl;
    outFile << "Total blooms: " << bloomCount << endl;
    vector<pair<int, int>> cntVec(cntFreq.begin(), cntFreq.end());
    sort(cntVec.begin(), cntVec.end(), [](const auto &a, const auto &b){ return a.first > b.first; });
    cout << "Top 10 largest bloomCnt:" << endl;
    outFile << "Top 10 largest bloomCnt:" << endl;
    int topN = min(10, (int)cntVec.size());
    for(int i = 0; i < topN; i++)
    {
        double ratio = (double)cntVec[i].second / bloomCount * 100.0;
        cout << "  bloomCnt=" << cntVec[i].first << ": count=" << cntVec[i].second
             << ", ratio=" << fixed << setprecision(2) << ratio << "%" << endl;
        outFile << "  bloomCnt=" << cntVec[i].first << ": count=" << cntVec[i].second
             << ", ratio=" << fixed << setprecision(2) << ratio << "%" << endl;
    }
    if(cntFreq.count(2)){
        cout << "bloomCnt=2: count=" << cntFreq[2] << ", ratio=" << fixed << setprecision(2)
             << (double)cntFreq[2] / bloomCount * 100.0 << "%" << endl;
        outFile << "bloomCnt=2: count=" << cntFreq[2] << ", ratio=" << fixed << setprecision(2)
             << (double)cntFreq[2] / bloomCount * 100.0 << "%" << endl;}
    else{
        cout << "bloomCnt=2: count=0, ratio=0.00%" << endl;
        outFile << "bloomCnt=2: count=0, ratio=0.00%" << endl;}
    if(cntFreq.count(3)){
        cout << "bloomCnt=3: count=" << cntFreq[3] << ", ratio=" << fixed << setprecision(2)
             << (double)cntFreq[3] / bloomCount * 100.0 << "%" << endl;
        outFile << "bloomCnt=3: count=" << cntFreq[3] << ", ratio=" << fixed << setprecision(2)
             << (double)cntFreq[3] / bloomCount * 100.0 << "%" << endl;}
    else{
        cout << "bloomCnt=3: count=0, ratio=0.00%" << endl;
        outFile << "bloomCnt=3: count=0, ratio=0.00%" << endl;}
    cout << "=============================================" << endl;
    outFile << "=============================================" << endl;
    return true;
}
void insertEdgesRandomSingleVer(Graph &G, const string &beIndexFile, vector<pair<intV,intV>> &insData, intV batchSize, ofstream &outFile)
{
    int bloomCount = 0;
    intV maxWedgeSize = 0;
    vector<intV> maxBloomWedges;
    readBloomStatsAndMaxBloom(beIndexFile, bloomCount, maxWedgeSize, maxBloomWedges, outFile);
    intV pos = rand() % G.numU;
    intV u = G.uLabels[pos];
    cout << "insertEdgesRandom: u = " << u << ", deg[u] = " << G.deg[u] << endl;
    outFile << "insertEdgesRandom: u = " << u << ", deg[u] = " << G.deg[u] << endl;
    unordered_set<intV> uNeighbors;
    for(intV i = 0; i < G.deg[u]; i++)
        uNeighbors.insert(G.adj[u][i]);
    vector<intV> nonNeighbors;
    nonNeighbors.reserve(G.numV - G.deg[u]);
    for(intV i = 0; i < G.numV; i++)
    {
        intV v = G.vLabels[i];
        if(uNeighbors.find(v) == uNeighbors.end())
            nonNeighbors.push_back(v);
    }
    intV available = nonNeighbors.size();
    if(available < batchSize)
    {
        cout << "insertEdgesRandom: only " << available << " non-neighbors available (< " << batchSize << "), using all" << endl;
        batchSize = available;
    }
    intV actualBatch = batchSize;
    for(intV i = nonNeighbors.size() - 1; i > 0 && actualBatch > 0; i--)
    {
        intV j = rand() % (i + 1);
        swap(nonNeighbors[i], nonNeighbors[j]);
        actualBatch--;
    }
    intV startIdx = nonNeighbors.size() - batchSize;
    insData.reserve(insData.size() + batchSize);
    for(intV i = startIdx; i < nonNeighbors.size(); i++)
        insData.push_back(make_pair(u, nonNeighbors[i]));
    cout << "insertEdgesRandom: generated " << batchSize << " edges for u=" << u << endl;
}
void insertEdgesFromLargestBloom(Graph &G, const string &beIndexFile, vector<pair<intV,intV>> &insData, intV batchSize, ofstream &outFile)
{
    ifstream inFile(beIndexFile);
    if(!inFile.is_open())
    {
        cerr << "insertEdgesFromLargestBloom: cannot open file " << beIndexFile << endl;
        return;
    }
    int bloomCount;
    inFile >> bloomCount;
    unordered_map<int, int> cntFreq;
    int maxWedgeSize = 0;
    vector<intV> maxBloomWedges;
    for(int i = 0; i < bloomCount; i++)
    {
        intV uid, wid;
        int bloomWdgCnt;
        inFile >> uid >> wid >> bloomWdgCnt;
        int wedgeSize;
        inFile >> wedgeSize;
        vector<intV> wedges(wedgeSize);
        for(int j = 0; j < wedgeSize; j++)
            inFile >> wedges[j];
        cntFreq[bloomWdgCnt]++;
        if(wedgeSize > maxWedgeSize)
        {
            maxWedgeSize = wedgeSize;
            maxBloomWedges = wedges;
        }
    }
    inFile.close();
    cout << "========== BEIndex Bloom Statistics ==========" << endl;
    outFile << "========== BEIndex Bloom Statistics ==========" << endl;
    cout << "Total blooms: " << bloomCount << endl;
    outFile << "Total blooms: " << bloomCount << endl;
    vector<pair<int, int>> cntVec(cntFreq.begin(), cntFreq.end());
    sort(cntVec.begin(), cntVec.end(), [](const auto &a, const auto &b){ return a.first > b.first; });
    cout << "Top 10 largest bloomCnt:" << endl;
    outFile << "Top 10 largest bloomCnt:" << endl;
    int topN = min(10, (int)cntVec.size());
    for(int i = 0; i < topN; i++)
    {
        double ratio = (double)cntVec[i].second / bloomCount * 100.0;
        cout << "  bloomCnt=" << cntVec[i].first << ": count=" << cntVec[i].second
             << ", ratio=" << fixed << setprecision(2) << ratio << "%" << endl;
        outFile << "  bloomCnt=" << cntVec[i].first << ": count=" << cntVec[i].second
             << ", ratio=" << fixed << setprecision(2) << ratio << "%" << endl;
    }
    if(cntFreq.count(2)){
        cout << "bloomCnt=2: count=" << cntFreq[2] << ", ratio=" << fixed << setprecision(2)
             << (double)cntFreq[2] / bloomCount * 100.0 << "%" << endl;
        outFile << "bloomCnt=2: count=" << cntFreq[2] << ", ratio=" << fixed << setprecision(2)
             << (double)cntFreq[2] / bloomCount * 100.0 << "%" << endl;}
    else{
        cout << "bloomCnt=2: count=0, ratio=0.00%" << endl;
        outFile << "bloomCnt=2: count=0, ratio=0.00%" << endl;}
    if(cntFreq.count(3)){
        cout << "bloomCnt=3: count=" << cntFreq[3] << ", ratio=" << fixed << setprecision(2)
             << (double)cntFreq[3] / bloomCount * 100.0 << "%" << endl;
        outFile << "bloomCnt=3: count=" << cntFreq[3] << ", ratio=" << fixed << setprecision(2)
             << (double)cntFreq[3] / bloomCount * 100.0 << "%" << endl;}
    else{
        cout << "bloomCnt=3: count=0, ratio=0.00%" << endl;
        outFile << "bloomCnt=3: count=0, ratio=0.00%" << endl;}
    cout << "=============================================" << endl;
    outFile << "=============================================" << endl;
    if(maxBloomWedges.empty())
    {
        cerr << "insertEdgesFromLargestBloom: no wedge found in largest bloom" << endl;
        outFile << "insertEdgesFromLargestBloom: no wedge found in largest bloom" << endl;
        return;
    }
    intV u = maxBloomWedges[rand() % maxBloomWedges.size()];
    bool uIsU;
    {
        unordered_set<intV> uSet(G.uLabels.begin(), G.uLabels.end());
        uIsU = (uSet.find(u) != uSet.end());
    }
    const vector<intV> &oppLabels = uIsU ? G.vLabels : G.uLabels;
    cout << "insertEdgesFromLargestBloom: largest bloom wedgeSize=" << maxWedgeSize
         << ", selected u=" << u << " (side=" << (uIsU?"U":"V") << "), deg[u]=" << G.deg[u]
         << ", opposite side size=" << oppLabels.size() << endl;
    outFile << "insertEdgesFromLargestBloom: largest bloom wedgeSize=" << maxWedgeSize
         << ", selected u=" << u << " (side=" << (uIsU?"U":"V") << "), deg[u]=" << G.deg[u]
         << ", opposite side size=" << oppLabels.size() << endl;
    unordered_set<intV> uNeighbors;
    for(intV i = 0; i < G.deg[u]; i++)
        uNeighbors.insert(G.adj[u][i]);
    vector<intV> nonNeighbors;
    nonNeighbors.reserve(oppLabels.size() > (size_t)G.deg[u] ? oppLabels.size() - G.deg[u] : 0);
    for(size_t i = 0; i < oppLabels.size(); i++)
    {
        intV v = oppLabels[i];
        if(uNeighbors.find(v) == uNeighbors.end())
            nonNeighbors.push_back(v);
    }
    intV available = nonNeighbors.size();
    if(available < batchSize)
    {
        cout << "insertEdgesFromLargestBloom: only " << available << " non-neighbors available (< " << batchSize << "), using all" << endl;
        outFile << "insertEdgesFromLargestBloom: only " << available << " non-neighbors available (< " << batchSize << "), using all" << endl;
        batchSize = available;
    }
    intV actualBatch = batchSize;
    for(intV i = nonNeighbors.size() - 1; i > 0 && actualBatch > 0; i--)
    {
        intV j = rand() % (i + 1);
        swap(nonNeighbors[i], nonNeighbors[j]);
        actualBatch--;
    }
    intV startIdx = nonNeighbors.size() - batchSize;
    insData.reserve(insData.size() + batchSize);
    for(intV i = startIdx; i < nonNeighbors.size(); i++)
        insData.push_back(make_pair(u, nonNeighbors[i]));
    cout << "insertEdgesFromLargestBloom: generated " << batchSize << " edges for u=" << u << endl;
    outFile << "insertEdgesFromLargestBloom: generated " << batchSize << " edges for u=" << u << endl;
}
void insertEdgesFromMedianDegreeU(Graph &G, const string &beIndexFile, vector<pair<intV,intV>> &insData, intV batchSize, ofstream &outFile)
{
    int bloomCount = 0;
    intV maxWedgeSize = 0;
    vector<intV> maxBloomWedges;
    readBloomStatsAndMaxBloom(beIndexFile, bloomCount, maxWedgeSize, maxBloomWedges, outFile);
    if(G.numU == 0)
    {
        cerr << "insertEdgesFromMedianDegreeU: no U-side vertex" << endl;
        outFile << "insertEdgesFromMedianDegreeU: no U-side vertex" << endl;
        return;
    }
    vector<pair<intV, intV>> degU;
    degU.reserve(G.numU);
    for(intV i = 0; i < G.numU; i++)
    {
        intV u = G.uLabels[i];
        degU.push_back(make_pair(G.deg[u], u));
    }
    intV mid = G.numU / 2;
    nth_element(degU.begin(), degU.begin() + mid, degU.end(),
                [](const pair<intV, intV> &a, const pair<intV, intV> &b){ return a.first < b.first; });
    intV medianDeg = degU[mid].first;
    intV u = degU[mid].second;
    cout << "insertEdgesFromMedianDegreeU: medianDeg=" << medianDeg
         << ", selected u=" << u << ", deg[u]=" << G.deg[u] << endl;
    outFile << "insertEdgesFromMedianDegreeU: medianDeg=" << medianDeg
         << ", selected u=" << u << ", deg[u]=" << G.deg[u] << endl;
    unordered_set<intV> uNeighbors;
    for(intV i = 0; i < G.deg[u]; i++)
        uNeighbors.insert(G.adj[u][i]);
    vector<intV> nonNeighbors;
    nonNeighbors.reserve(G.numV - G.deg[u]);
    for(intV i = 0; i < G.numV; i++)
    {
        intV v = G.vLabels[i];
        if(uNeighbors.find(v) == uNeighbors.end())
            nonNeighbors.push_back(v);
    }
    intV available = nonNeighbors.size();
    if(available < batchSize)
    {
        cout << "insertEdgesFromMedianDegreeU: only " << available << " non-neighbors available (< " << batchSize << "), using all" << endl;
        outFile << "insertEdgesFromMedianDegreeU: only " << available << " non-neighbors available (< " << batchSize << "), using all" << endl;
        batchSize = available;
    }
    intV actualBatch = batchSize;
    for(intV i = nonNeighbors.size() - 1; i > 0 && actualBatch > 0; i--)
    {
        intV j = rand() % (i + 1);
        swap(nonNeighbors[i], nonNeighbors[j]);
        actualBatch--;
    }
    intV startIdx = nonNeighbors.size() - batchSize;
    insData.reserve(insData.size() + batchSize);
    for(intV i = startIdx; i < nonNeighbors.size(); i++)
        insData.push_back(make_pair(u, nonNeighbors[i]));
    cout << "insertEdgesFromMedianDegreeU: generated " << batchSize << " edges for u=" << u << endl;
    outFile << "insertEdgesFromMedianDegreeU: generated " << batchSize << " edges for u=" << u << endl;
}
void removeEdgesFromLargestBloom(Graph &G, const string &beIndexFile, vector<pair<intV,intV>> &delData, intV batchSize, ofstream &outFile)
{
    int bloomCount = 0;
    intV maxWedgeSize = 0;
    vector<intV> maxBloomWedges;
    pair<intV, intV> maxBloomMaster;
    readBloomStatsAndMaxBloom(beIndexFile, bloomCount, maxWedgeSize, maxBloomWedges, outFile, &maxBloomMaster);
    intV u = maxBloomMaster.first;
    intV other = maxBloomMaster.second;
    if(G.deg[other] > G.deg[u])
        u = other;
    cout << "removeEdgesFromLargestBloom: largest bloom wedgeSize=" << maxWedgeSize
         << ", masters=(" << maxBloomMaster.first << "," << maxBloomMaster.second << ")"
         << ", selected u=" << u << ", deg[u]=" << G.deg[u] << endl;
    outFile << "removeEdgesFromLargestBloom: largest bloom wedgeSize=" << maxWedgeSize
         << ", masters=(" << maxBloomMaster.first << "," << maxBloomMaster.second << ")"
         << ", selected u=" << u << ", deg[u]=" << G.deg[u] << endl;
    vector<intV> neighbors(G.deg[u]);
    for(intV i = 0; i < G.deg[u]; i++)
        neighbors[i] = G.adj[u][i];
    intV available = neighbors.size();
    if(available < batchSize)
    {
        cout << "removeEdgesFromLargestBloom: only " << available << " neighbors available (< " << batchSize << "), deleting all" << endl;
        outFile << "removeEdgesFromLargestBloom: only " << available << " neighbors available (< " << batchSize << "), deleting all" << endl;
        batchSize = available;
    }
    if(batchSize == 0)
    {
        cout << "removeEdgesFromLargestBloom: no edges to delete for u=" << u << endl;
        outFile << "removeEdgesFromLargestBloom: no edges to delete for u=" << u << endl;
        return;
    }
    intV actualBatch = batchSize;
    for(intV i = neighbors.size() - 1; i > 0 && actualBatch > 0; i--)
    {
        intV j = rand() % (i + 1);
        swap(neighbors[i], neighbors[j]);
        actualBatch--;
    }
    intV startIdx = neighbors.size() - batchSize;
    delData.reserve(delData.size() + batchSize);
    for(intV i = startIdx; i < neighbors.size(); i++)
        delData.push_back(make_pair(u, neighbors[i]));
    cout << "removeEdgesFromLargestBloom: selected " << batchSize << " edges for deletion from u=" << u << endl;
    outFile << "removeEdgesFromLargestBloom: selected " << batchSize << " edges for deletion from u=" << u << endl;
}
void removeEdgesFromMedianDegreeU(Graph &G, const string &beIndexFile, vector<pair<intV,intV>> &delData, intV batchSize, ofstream &outFile)
{
    int bloomCount = 0;
    intV maxWedgeSize = 0;
    vector<intV> maxBloomWedges;
    readBloomStatsAndMaxBloom(beIndexFile, bloomCount, maxWedgeSize, maxBloomWedges, outFile);
    if(G.numU == 0)
    {
        cerr << "removeEdgesFromMaxDegreeU: no U-side vertex" << endl;
        outFile << "removeEdgesFromMaxDegreeU: no U-side vertex" << endl;
        return;
    }
    vector<pair<intV, intV>> degU;
    degU.reserve(G.numU);
    for(intV i = 0; i < G.numU; i++)
    {
        intV u = G.uLabels[i];
        degU.push_back(make_pair(G.deg[u], u));
    }
    intV mid = G.numU / 2;
    nth_element(degU.begin(), degU.begin() + mid, degU.end(),
                [](const pair<intV, intV> &a, const pair<intV, intV> &b){ return a.first < b.first; });
    intV medianDeg = degU[mid].first;
    intV u = degU[mid].second;
    cout << "removeEdgesFromMaxDegreeU: medianDeg=" << medianDeg
         << ", selected u=" << u << ", deg[u]=" << G.deg[u] << endl;
    outFile << "removeEdgesFromMaxDegreeU: medianDeg=" << medianDeg
         << ", selected u=" << u << ", deg[u]=" << G.deg[u] << endl;
    vector<intV> neighbors(G.deg[u]);
    for(intV i = 0; i < G.deg[u]; i++)
        neighbors[i] = G.adj[u][i];
    intV available = neighbors.size();
    if(available < batchSize)
    {
        cout << "removeEdgesFromMaxDegreeU: only " << available << " neighbors available (< " << batchSize << "), deleting all" << endl;
        outFile << "removeEdgesFromMaxDegreeU: only " << available << " neighbors available (< " << batchSize << "), deleting all" << endl;
        batchSize = available;
    }
    if(batchSize == 0)
    {
        cout << "removeEdgesFromMaxDegreeU: no edges to delete for u=" << u << endl;
        outFile << "removeEdgesFromMaxDegreeU: no edges to delete for u=" << u << endl;
        return;
    }
    intV actualBatch = batchSize;
    for(intV i = neighbors.size() - 1; i > 0 && actualBatch > 0; i--)
    {
        intV j = rand() % (i + 1);
        swap(neighbors[i], neighbors[j]);
        actualBatch--;
    }
    intV startIdx = neighbors.size() - batchSize;
    delData.reserve(delData.size() + batchSize);
    for(intV i = startIdx; i < neighbors.size(); i++)
        delData.push_back(make_pair(u, neighbors[i]));
    cout << "removeEdgesFromMaxDegreeU: selected " << batchSize << " edges for deletion from u=" << u << endl;
    outFile << "removeEdgesFromMaxDegreeU: selected " << batchSize << " edges for deletion from u=" << u << endl;
}
#endif
