#ifndef ARRAY_OPS_COUNT_H
#define ARRAY_OPS_COUNT_H 
#ifdef ABP_COUNT_OPS
inline long long g_ops_alg = 0;
inline long long g_ops_touch = 0;
inline long long g_ops_alloc = 0;
  #define OPS_ALG() (++g_ops_alg)
  #define OPS_ALG_N(k) (g_ops_alg += (long long)(k))
  #define OPS_TOUCH() (++g_ops_touch)
  #define OPS_ALLOC_N(k) (g_ops_alloc += (long long)(k))
inline void ops_reset(){ g_ops_alg = 0; g_ops_touch = 0; g_ops_alloc = 0; }
#else
  #define OPS_ALG() ((void)0)
  #define OPS_ALG_N(k) ((void)0)
  #define OPS_TOUCH() ((void)0)
  #define OPS_ALLOC_N(k) ((void)0)
#endif
#endif
