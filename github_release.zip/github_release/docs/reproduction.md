# Reproduction Guide

## Environment

Use Linux, Bash, g++, C++17, and OpenMP. The benchmark programs pin themselves to the requested CPU. Choose a CPU permitted by the process affinity mask.

## Build and Verify

```bash
bash experiments/scripts/build_drivers.sh
build/experiments/verify_oracle
```

The oracle exhaustively checks all 3-by-3 bipartite graphs and also tests randomized cumulative update sequences with fixed seed `10720261027`.

## Full Campaign

```bash
bash experiments/scripts/run_all.sh 500 3 2 build/results
```

The runner executes 26 configurations:

- 2 complete graphs (DR and GH) × 2 update directions × timing and operation counts: 8 runs.
- 4 GH scale graphs × 2 update directions × timing: 8 runs.
- 2 complete graphs × insertion RSS, allocation, and index-query runs, plus deletion index-query runs: 8 runs.
- 2 complete graphs × 1,000 fixed-vertex accumulating insertions: 2 runs.

The independent small-graph oracle runs before these configurations. The final Python summarizer validates statuses and event matching and writes CSV files under `summary/`. Python 3 needs no third-party packages. If the CPU argument is omitted, the runner selects the first CPU permitted by process affinity.

`data/reference/` supplies archived Bai PI*/PR* event timings, not a baseline executable. These fixed measurements allow baseline-ranked top-ten event selection, speedup calculations, and all-candidate accounting alongside fresh measurements of the four indexed methods. The latter uses the archived presence-detector observations under `data/detection/` and is a sum of separately measured components. It excludes trivial-event graph commits. This release does not perform a fresh Bai execution or a joint all-candidate end-to-end timing run.

`experiments/src/fixed_vertex.cpp` runs three 1,000-event timing sequences and a separate static validation sequence. It uses seed `20260923`, includes trivial insertions, and validates full labels, total supports, and persistent supports at 0, 100, 250, 500, and 1,000 insertions. Output folders contain `samples_original.tsv`, `events.tsv`, `structures.tsv`, and `status.json`. The published nine-dataset results are separate from the two runnable bundled datasets.

Timing uses three repetitions by default. Operation counts use one repetition. Each result is written to a separate directory under the requested output directory. Use a new output directory for every campaign.

## One Run

```bash
bash experiments/scripts/run_one.sh <time|count> <graph> <samples> <insert|delete> [events] [repeats] [cpu] [output-directory]
```

For example:

```bash
bash experiments/scripts/run_one.sh time data/datasets/full/recordlabel.txt data/samples/full/recordlabel_insert.txt insert 500 3 2 build/recordlabel_insert
```

The graph and sample files are included in this release. Full-graph workloads are in `data/samples/full/`; scale workloads are in `data/samples/scale/`. The complete `recordlabel.txt` graph is the DR dataset; `github.txt` is the GH dataset. The scale files are GH02, GH04, GH06, and GH08.

Samples use the internal vertex IDs stored in each graph representation. Each timing event starts from the original graph state, while index experiments apply unique sampled updates cumulatively. Repeated deletion rows are deduplicated by the index driver; the timing driver processes each row as an independent event.
