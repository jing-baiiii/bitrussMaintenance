# Reproduction Guide

## Environment

Use Linux, Bash, g++, C++17, and OpenMP. The benchmark programs pin themselves to the requested CPU. Choose a CPU permitted by the process affinity mask.

## Build and Verify

```bash
bash experiments/scripts/build_drivers.sh
build/experiments/verify_oracle
```

The oracle exhaustively checks all 3-by-3 bipartite graphs and also tests randomized cumulative update sequences with fixed seed `10720261027`.

## Full Campaign

```bash
bash experiments/scripts/run_all.sh 500 3 2 build/results
```

The runner executes 88 configurations:

- 9 full graphs × 2 update directions × timing and operation counts: 36 runs.
- 8 scale graphs × 2 update directions × timing: 16 runs.
- 9 full graphs × insertion RSS, allocation, and index-query runs, plus deletion index-query runs: 36 runs.

Timing uses three repetitions by default. Operation counts use one repetition. Each result is written to a separate directory under the requested output directory. Use a new output directory for every campaign.

## One Run

```bash
bash experiments/scripts/run_one.sh <time|count> <graph> <samples> <insert|delete> [events] [repeats] [cpu] [output-directory]
```

For example:

```bash
bash experiments/scripts/run_one.sh time data/datasets/full/recordlabel.txt data/samples/full/recordlabel_insert.txt insert 500 3 2 build/recordlabel_insert
```

The graph and sample files are included in this release. Full-graph workloads are in `data/samples/full/`; scale workloads are in `data/samples/scale/`.
