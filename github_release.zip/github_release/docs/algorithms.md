# Algorithm and Function Map

All methods share the same graph representation, BEIndex, event order, and layer-processing framework.

| Method | Mechanisms |
| --- | --- |
| BM | Dynamic BEIndex maintenance and layer-by-layer candidate traversal |
| SA | BM plus support algebra |
| SAP | SA plus support/bloom-number pruning and EE |
| SAP+ | SAP plus persistent support `h` |

## Insertion

`src/algorithms/insertion_layer.h` defines `Insertion60State::insert`. The experiment driver calls it for BM, SA, and SAP. Its `supportAlgebra` option is enabled for SA and SAP; `sapFilters` and `earlyEviction` are enabled for SAP. `src/algorithms/insertion_persistent.h` defines `Insertion68State::insert`, which maintains `h` and implements SAP+.

## Deletion

`src/algorithms/deletion_layer.h` defines `arrayBMD_layer`. The driver selects BM, SA, or SAP through its support-algebra, pruning, and early-eviction options. `src/algorithms/deletion_persistent.h` defines `buildPersistentSupport` and `arrayBMDPersistent`; together they initialize and maintain `h` for SAP+.

## Drivers

- `experiments/src/main.cpp`: timing and operation-count runs for all four methods.
- `experiments/src/memory.cpp`: per-event process RSS measurement for SAP+ insertion.
- `experiments/src/index.cpp`: maintained-versus-rebuilt index queries and checkpoints.
- `experiments/src/verify.cpp`: exhaustive and seeded randomized static-oracle checks.
- `experiments/src/instrumented/`: allocation-instrumented insertion headers used by the allocation and index-query drivers.

`src/algorithms/allocation.h` provides allocation categories and tracking scopes.
