# Bitruss Maintenance Experiments

This release contains the four strict maintenance algorithms, all experiment drivers, the complete graph and update-sample inputs, and scripts to build and run the full 88-configuration campaign.

## Requirements

- Linux
- Bash
- g++ with C++17 and OpenMP support
- A CPU index allowed by the current process affinity mask

No external data download or Python package is required.

## Build

```bash
bash experiments/scripts/build_drivers.sh
```

The script builds the time, operation-count, memory, allocation, index-query, and oracle-verification executables under `build/experiments/`.

## Run All Experiments

```bash
bash experiments/scripts/run_all.sh [events] [time-repeats] [cpu] [output-directory]
```

Defaults are 500 events, 3 time repetitions, CPU 2, and `build/results`. The campaign contains 88 configurations: 36 full-graph timing/count runs, 16 scale timing runs, and 36 memory/allocation/index-query runs. Count runs use one repetition. The output directory must be new for each campaign.

To run one configuration:

```bash
bash experiments/scripts/run_one.sh time data/datasets/full/recordlabel.txt data/samples/full/recordlabel_insert.txt insert 500 3 2 build/one_run
```

The output directory must not already exist.

## Algorithms

- BM dynamically maintains BEIndex and traverses candidates layer by layer.
- SA adds support algebra to BM.
- SAP adds support/bloom-number pruning and EE to SA.
- SAP+ adds persistent support `h` to SAP.

The insertion and deletion kernels are in `src/algorithms/`. The exact function-to-method mapping and reproduction protocol are documented in `docs/algorithms.md` and `docs/reproduction.md`.

## Inputs

`data/datasets/full/` contains the nine full graphs. `data/datasets/scale/` contains the eight scale graphs. `data/samples/full/` contains the fixed 500-event insert/delete workloads; `data/samples/scale/` contains the fixed scale workloads. The oracle verifier uses seed `10720261027`; experiment workloads are fixed files and use no runtime sampling seed.
