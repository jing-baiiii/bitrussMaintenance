# Bitruss Maintenance Experiments

This release contains the four layer-by-layer maintenance algorithms, experiment drivers, the DR and GH complete graph inputs, and four GH scalability inputs. ID is not bundled. All runs use paths relative to this directory.

## Requirements

- Linux
- Bash
- g++ with C++17 and OpenMP support
- Python 3 (standard library only)
- A CPU index allowed by the current process affinity mask

No external data download or Python package is required.

## Build

```bash
bash experiments/scripts/build_drivers.sh
```

The script builds timing, operation-count, memory, allocation, index-query, fixed-vertex insertion, and oracle-verification executables under `build/experiments/`.

## Run All Experiments

```bash
bash experiments/scripts/run_all.sh [events] [time-repeats] [cpu] [output-directory]
```

Defaults are 500 events, 3 time repetitions, the first permitted CPU, and `build/results`. The campaign contains 26 configurations: 8 complete-graph timing/count runs, 8 GH scalability timing runs, 8 DR/GH memory/allocation/index-query runs, and 2 fixed-vertex insertion runs. It also executes the independent small-graph oracle. Count runs use one repetition. The output directory must be new for each campaign.

The runner writes CSV summaries for time distributions, successive refinements, baseline-ranked top-ten events, affected-event groups, operation counts, memory/initialization, index-query distributions, all-candidate cost accounting, and fixed-vertex insertions under `summary/`. Detailed event and checkpoint files remain in each run directory.

Bai PI*/PR* event timings and work/memory/initialization CSVs in `data/reference/` are frozen reference measurements. They are used to recompute ratios and select the same top-ten events; this release does not rebuild or rerun Bai's implementation. All-candidate summaries combine archived detector observations with newly measured nontrivial maintenance. Timings can differ across machines and do not reproduce the paper's exact elapsed times.

To run the new fixed-vertex experiment alone:

```bash
mkdir -p build
build/experiments/fixed_vertex data/datasets/full/github.txt build/fixed_vertex_GH 2 20260923
```

Choose an allowed CPU in place of `2`. Each dataset receives 1,000 distinct accumulating insertions incident to one selected left vertex, three timing sequences, and a separate validation sequence at five checkpoints. Butterfly-free insertions are included. No external large graph is needed for the bundled DR/GH runs.

To run one configuration:

```bash
bash experiments/scripts/run_one.sh time data/datasets/full/recordlabel.txt data/samples/full/recordlabel_insert.txt insert 500 3 2 build/one_run
```

The output directory must not already exist.

## Algorithms

- BM dynamically maintains BEIndex and traverses candidates layer by layer.
- SA adds support algebra to BM.
- SAP adds support/bloom-number pruning and EE to SA.
- SAP+ adds persistent support `h` to SAP.

The insertion and deletion kernels are in `src/algorithms/`. The exact function-to-method mapping and reproduction protocol are documented in `docs/algorithms.md` and `docs/reproduction.md`.

## Inputs

`data/datasets/full/recordlabel.txt` is the complete DR graph and `data/datasets/full/github.txt` is the complete GH graph. `data/datasets/scale/` contains GH02, GH04, GH06, and GH08 for scalability. The corresponding fixed workloads are in `data/samples/full/` and `data/samples/scale/`. The oracle verifier uses seed `10720261027`; experiment workloads are fixed files and use no runtime sampling seed.

Only these datasets are included: complete DR and GH graphs, plus GH02/GH04/GH06/GH08 scale graphs. Samples use the internal vertex IDs stored in each graph representation.
