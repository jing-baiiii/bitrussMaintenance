#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
if [[ $# -lt 4 ]]; then
  printf 'Usage: %s <time|count> <graph> <samples> <insert|delete> [events] [repeats] [cpu] [output-dir]\n' "$0" >&2
  exit 2
fi
mode=$1 graph=$2 samples=$3 direction=$4
events=${5:-500} repeats=${6:-3} cpu=${7:-2}
output=${8:-"${root}/build/run_${mode}_${direction}"}
if [[ ! -x "${root}/build/experiments/${mode}" ]]; then
  "${root}/experiments/scripts/build_drivers.sh"
fi
exec "${root}/build/experiments/${mode}" "${graph}" "${samples}" \
  "${direction}" "${events}" "${repeats}" "${output}" "${cpu}"
