#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
out="${root}/build/experiments"
mkdir -p "${out}"
common=(-std=c++17 -O3 -fopenmp -DL56_SINGLE_ONLY
  -I"${root}/src/algorithms"
  -I"${root}/experiments/src/instrumented"
  -I"${root}/src/dependencies")
g++ "${common[@]}" "${root}/experiments/src/main.cpp" -o "${out}/time"
g++ "${common[@]}" -DCOUNT104 -DINSERT60_COUNT -DABP_COUNT_OPS \
  "${root}/experiments/src/main.cpp" -o "${out}/count"
g++ "${common[@]}" "${root}/experiments/src/memory.cpp" -o "${out}/memory"
g++ "${common[@]}" -DALLOC "${root}/experiments/src/memory.cpp" -o "${out}/allocation"
g++ "${common[@]}" "${root}/experiments/src/index.cpp" -o "${out}/index"
g++ -std=c++17 -O1 -g -fopenmp \
  -I"${root}/src/algorithms" \
  -I"${root}/experiments/src/instrumented" \
  -I"${root}/src/dependencies" \
  "${root}/experiments/src/verify.cpp" -o "${out}/verify_oracle"
