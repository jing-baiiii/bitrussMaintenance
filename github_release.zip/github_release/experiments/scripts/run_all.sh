#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
events=${1:-500}
time_repeats=${2:-3}
cpu=${3:-$(python3 -c 'import os; print(min(os.sched_getaffinity(0)))')}
output_root=${4:-"${root}/build/results"}
if [[ "${events}" != 500 ]]; then
  printf 'The complete campaign requires exactly 500 events.\n' >&2
  exit 2
fi
if [[ -e "${output_root}" ]]; then
  printf 'Output directory already exists: %s\n' "${output_root}" >&2
  exit 2
fi
if [[ ! -x "${root}/build/experiments/fixed_vertex" ]]; then
  "${root}/experiments/scripts/build_drivers.sh"
fi
mkdir -p "${output_root}"
"${root}/build/experiments/verify_oracle" > "${output_root}/verification.json" 2>&1
time_bin="${root}/build/experiments/time"
count_bin="${root}/build/experiments/count"
memory_bin="${root}/build/experiments/memory"
allocation_bin="${root}/build/experiments/allocation"
index_bin="${root}/build/experiments/index"
full_names=(DR GH)
full_graphs=(recordlabel.txt github.txt)
run_main() {
  local label=$1 graph=$2 samples=$3 direction=$4 mode=$5 repeats=$6
  local output="${output_root}/${label}"
  "${root}/experiments/scripts/run_one.sh" "${mode}" "${graph}" "${samples}" \
    "${direction}" 500 "${repeats}" "${cpu}" "${output}"
}
for i in "${!full_names[@]}"; do
  name=${full_names[$i]}
  graph="${root}/data/datasets/full/${full_graphs[$i]}"
  for direction in insert delete; do
    stem=${full_graphs[$i]%.txt}
    sample="${root}/data/samples/full/${stem}_${direction}.txt"
    run_main "E1_${name}_${direction}_time" "${graph}" "${sample}" "${direction}" time "${time_repeats}"
    run_main "E1_${name}_${direction}_count" "${graph}" "${sample}" "${direction}" count 1
  done
done
for family in GH; do
  for fraction in 02 04 06 08; do
    name="${family}${fraction}"
    if [[ "${family}" == GH ]]; then
      graph="${root}/data/datasets/scale/${name}_normalized.txt"
    else
      graph="${root}/data/datasets/scale/${name}.txt"
    fi
    for direction in insert delete; do
      sample="${root}/data/samples/scale/${name}/${direction}.txt"
      run_main "E5_${name}_${direction}_time" "${graph}" "${sample}" "${direction}" time "${time_repeats}"
    done
  done
done
for i in "${!full_names[@]}"; do
  name=${full_names[$i]}
  graph="${root}/data/datasets/full/${full_graphs[$i]}"
  for direction in insert delete; do
    stem=${full_graphs[$i]%.txt}
    sample="${root}/data/samples/full/${stem}_${direction}.txt"
    if [[ "${direction}" == insert ]]; then
      "${memory_bin}" "${graph}" "${sample}" "${output_root}/memory_${name}_insert" "${cpu}"
      "${allocation_bin}" "${graph}" "${sample}" "${output_root}/allocation_${name}_insert" "${cpu}"
    fi
    "${index_bin}" "${direction}" "${graph}" "${sample}" "${output_root}/index_${name}_${direction}" "${cpu}"
  done
done
for i in "${!full_names[@]}"; do
  name=${full_names[$i]}
  graph="${root}/data/datasets/full/${full_graphs[$i]}"
  "${root}/build/experiments/fixed_vertex" "${graph}" "${output_root}/fixed_vertex_${name}" "${cpu}" 20260923
done
python3 "${root}/experiments/scripts/summarize.py" "${output_root}"
printf 'Completed 26 experiment configurations and oracle verification. Results: %s\n' "${output_root}"
