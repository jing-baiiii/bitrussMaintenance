#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "insertion_layer.h"
#include "deletion_layer.h"
#include "insertion_persistent.h"
#include "deletion_persistent.h"
#include <chrono>
#include <filesystem>
#include <sched.h>
using Clock104=std::chrono::steady_clock;
static void single104() {
    size_t n=0;for(const auto& entry:std::filesystem::directory_iterator("/proc/self/task")){(void)entry;++n;}
    if(n!=1)throw runtime_error("actual threads not one");
}
static uint64_t hash104(const vector<intE>& phi) {
    uint64_t h=1469598103934665603ULL;
    for(auto value:phi){h^=value;h*=1099511628211ULL;}return h;
}
static void entity104(Graph& graph,intE edge,bool remove) {
    auto uv=graph.eIdToV[edge];
    for(auto pair:{uv,make_pair(uv.second,uv.first)}) {
        auto& row=graph.adj[pair.first];auto& ids=graph.eId[pair.first];
        auto it=lower_bound(row.begin(),row.end(),pair.second);size_t at=it-row.begin();
        if(remove){if(it==row.end()||*it!=pair.second||ids[at]!=edge)throw runtime_error("entity mismatch");row.erase(it);ids.erase(ids.begin()+at);--graph.deg[pair.first];}
        else{row.insert(it,pair.second);ids.insert(ids.begin()+at,edge);++graph.deg[pair.first];}
    }
    if(remove)--graph.numE;else ++graph.numE;
}
static void static104(const Insertion60State& state,const Graph& initial,pair<intV,intV> uv,bool insertion,intE deleted,const vector<intE>& phi) {
    Graph graph=initial;
    if(insertion)insertEdgeIntoG(graph,uv.first,uv.second);else entity104(graph,deleted,true);
    auto gold=arrayStaticDecomp(graph);
    map<pair<intV,intV>,intE> values;
    for(intE e=0;e<graph.numE;++e){auto p=graph.eIdToV[e];values[minmax(p.first,p.second)]=gold[e];}
    for(intE e=0;e<phi.size();++e)if(insertion||e!=deleted){auto p=e==state.edges()?uv:state.endpoints(e);if(values.at(minmax(p.first,p.second))!=phi[e])throw runtime_error("static decomposition mismatch");}
}
int main(int argc,char** argv) {
    try {
        if(argc!=8)throw runtime_error("graph samples insert|delete N repeats output cpu");
        const string direction=argv[3];bool insertion=direction=="insert";
        if(!insertion&&direction!="delete")throw runtime_error("invalid direction");
        size_t limit=stoul(argv[4]);int repeats=stoi(argv[5]),cpu=stoi(argv[7]);
        cpu_set_t affinity;CPU_ZERO(&affinity);CPU_SET(cpu,&affinity);
        if(sched_setaffinity(0,sizeof(affinity),&affinity))throw runtime_error("affinity failed");single104();
        filesystem::path output=argv[6];if(!filesystem::create_directory(output))throw runtime_error("output exists");
        auto base=make_shared<Insertion60Base>();string graphPath=argv[1];base->graph.read_graph(graphPath,0);
        vector<intV> order,inverse;base->graph.sort_deg(order);invertMap(order,inverse);base->graph.reorder_in_place(inverse);
        base->left.resize(base->graph.numT);for(intV v=0;v<base->graph.numT;++v)base->left[v]=order[v]<base->graph.numU;
        vector<intE> phi,es;arrayBuildBase(base->graph,base->index,es,phi);
        Insertion60State initial(base,phi,vector<uint64_t>(es.begin(),es.end()));
        Insertion68State afInitial(initial);vector<intB> own;buildPersistentSupport(base->index,phi,own);
        ifstream input(argv[2]);vector<pair<intV,intV>> events;vector<intE> removed;string line;
        while(getline(input,line)&&events.size()<limit){if(line.empty()||line[0]=='#'||line[0]=='%')continue;istringstream row(line);intV u,v;if(!(row>>u>>v))throw runtime_error("bad sample");auto e=initial.findEdge(u,v);if(insertion!=(e==ABP_NOE))throw runtime_error("sample presence mismatch");events.push_back({u,v});removed.push_back(e);}
        if(events.size()!=limit)throw runtime_error("insufficient samples");
        ofstream timing(output/"events.tsv"),counts(output/"counts.tsv");
        timing<<"event_id\treplicate\tu\tv\tmethod\ttime_ms\tphi_hash\tchanged_edges\tphi_delta\n";
        counts<<"event_id\tmethod\tmetric\tvalue\n";
        vector<string> methods={"BM","SA","SAP","SAP+"};
        Insertion60Workspace insertionWork[4];PersistentWorkspace deletionWork;
        size_t statics=0,checkedH=0,paired=0;
        for(int rep=-1;rep<repeats;++rep)for(size_t id=0;id<(rep<0?1:limit);++id) {
            uint64_t expected=0;
            for(int position=0;position<4;++position) {
                int which=(position+id+(rep<0?0:rep))%4;const auto& method=methods[which];
                unique_ptr<Insertion60State> sl;unique_ptr<Insertion68State> af;
                BEGraphLoMem index;vector<intE> result,support;vector<intB> h;
                if(insertion){if(which==3)af=make_unique<Insertion68State>(afInitial);else sl=make_unique<Insertion60State>(initial);auto* s=af?static_cast<Insertion60State*>(af.get()):sl.get();s->phi.reserve(s->edges()+1);s->es.reserve(s->edges()+1);s->workspace=move(insertionWork[which]);if(af)af->h.reserve(af->edges()+1);}
                else{index=base->index;result=phi;support=es;if(which==3)h=own;}
                Insertion60Metrics im;Insertion68Metrics am;Layer56Metrics dm;PersistentMetrics pm;
                auto start=Clock104::now();
#ifdef COUNT104
                if(af)af->insert(events[id].first,events[id].second,&am);
                else if(sl)sl->insert(events[id].first,events[id].second,&im,which==2,which==2,which!=0);
                else if(which==3)arrayBMDPersistent(index,result,support,h,removed[id],deletionWork,&pm);
                else arrayBMD_layer(index,result,support,removed[id],which==2,1,&dm,which!=0,nullptr,which==2);
#else
                if(af)af->insert(events[id].first,events[id].second);
                else if(sl)sl->insert(events[id].first,events[id].second,nullptr,which==2,which==2,which!=0);
                else if(which==3)arrayBMDPersistent(index,result,support,h,removed[id],deletionWork);
                else arrayBMD_layer(index,result,support,removed[id],which==2,1,nullptr,which!=0,nullptr,which==2);
#endif
                if(!insertion)entity104(base->graph,removed[id],true);
                double ms=chrono::duration<double,milli>(Clock104::now()-start).count();single104();
                const auto& values=af?af->phi:sl?sl->phi:result;auto hash=hash104(values);
                if(position==0)expected=hash;else if(expected!=hash)throw runtime_error("paired phi mismatch event="+to_string(id));
                uint64_t changed=0,delta=0;for(size_t e=0;e<values.size();++e)if(insertion||e!=removed[id]){auto before=e<phi.size()?phi[e]:0;changed+=values[e]!=before;delta+=values[e]>before?values[e]-before:before-values[e];}
                if(!insertion)entity104(base->graph,removed[id],false);
                if(rep>=0)timing<<id<<'\t'<<rep<<'\t'<<events[id].first<<'\t'<<events[id].second<<'\t'<<method<<'\t'<<setprecision(17)<<ms<<'\t'<<hash<<'\t'<<changed<<'\t'<<delta<<'\n';
#ifdef COUNT104
                if(rep>=0){auto emit=[&](const char* field,uint64_t value){counts<<id<<'\t'<<method<<'\t'<<field<<'\t'<<value<<'\n';};
#define FIELD104(m,f) emit(#f,m.f)
                    if(insertion){const Insertion60Metrics& m=af?static_cast<const Insertion60Metrics&>(am):im;
                        FIELD104(m,candidates);FIELD104(m,candidateUnique);FIELD104(m,supportInitializations);FIELD104(m,supportWedgeScans);FIELD104(m,supportMemberships);FIELD104(m,closureMemberships);FIELD104(m,cascadeWedgeScans);FIELD104(m,bloomBuilds);FIELD104(m,bloomHits);FIELD104(m,edgeLookups);FIELD104(m,initialButterflies);FIELD104(m,layers);FIELD104(m,batches);
                        FIELD104(m,eeChecks);FIELD104(m,eeStops);FIELD104(m,eePropagations);FIELD104(m,explicitWitnessPairs);FIELD104(m,algebraLossGroups);FIELD104(m,filterChecks);
                        if(sl){FIELD104(im,algebraReads);FIELD104(im,pathPairProbes);}
                        if(af){FIELD104(am,hInitialWrites);FIELD104(am,hPromotionWrites);FIELD104(am,hAssignments);FIELD104(am,hMembershipScans);FIELD104(am,hWedgeScans);}}
                    else if(which==3){FIELD104(pm,checkedPairs);FIELD104(pm,peelPairs);FIELD104(pm,initialScans);FIELD104(pm,cascadeScans);FIELD104(pm,recomputeScans);FIELD104(pm,recomputeWrites);FIELD104(pm,recomputeMemberships);FIELD104(pm,layers);FIELD104(pm,batches);FIELD104(pm,eeChecks);FIELD104(pm,eeStops);FIELD104(pm,eePropagations);}
                    else{FIELD104(dm,C);FIELD104(dm,candidateUnique);FIELD104(dm,supportInitializations);FIELD104(dm,supportScans);FIELD104(dm,supportMemberships);FIELD104(dm,pruningMemberships);FIELD104(dm,admissionAttempts);FIELD104(dm,protectedAdmissions);FIELD104(dm,cascadeScans);FIELD104(dm,layers);FIELD104(dm,batches);FIELD104(dm,explicitWitnessPairs);FIELD104(dm,eeChecks);FIELD104(dm,eeStops);FIELD104(dm,eePropagations);}
#undef FIELD104
                    if(which==3&&(id==0||id==limit-1)){if(insertion){
                            for(intE e=0;e<af->edges();++e){uint64_t value=0;af->memberships(e,[&](auto membership){if(af->phi[membership.second]<af->phi[e])return;uint64_t g=0;af->wedges(membership.first,[&](auto w){if(af->phi[w.first]>=af->phi[e]&&af->phi[w.second]>=af->phi[e])++g;});if(!g)throw runtime_error("missing own path");value+=g-1;});if(value!=af->h[e])throw runtime_error("insertion h invariant mismatch");}}
                        else{vector<intB> gold;buildPersistentSupport(index,result,gold);if(gold!=h)throw runtime_error("deletion h invariant mismatch");}++checkedH;}
                    if(id==0||id==limit-1){static104(initial,base->graph,events[id],insertion,removed[id],values);++statics;}}
#endif
                if(insertion){auto* s=af?static_cast<Insertion60State*>(af.get()):sl.get();insertionWork[which]=move(s->workspace);}
            }
            if(rep>=0)++paired;
            timing.flush();counts.flush();
            if(rep>=0&&id%100==0)cout<<direction<<" rep="<<rep<<" event="<<id<<endl;
        }
        ofstream status(output/"status.json");status<<"{\"paired_events\":"<<paired<<",\"static_checks\":"<<statics<<",\"h_checks\":"<<checkedH<<",\"failures\":0}\n";
    }catch(const exception& e){cerr<<"FAIL104 "<<e.what()<<endl;return 1;}
}
