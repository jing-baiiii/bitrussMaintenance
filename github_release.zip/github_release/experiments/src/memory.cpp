#ifdef ALLOC
#define PI62_MEMORY 
#define PI62_MEMORY_IMPLEMENTATION 
#include "allocation.h"
#endif
#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "insertion_persistent_tracked.h"
#include <chrono>
#include <filesystem>
#include <sched.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>
#include <malloc.h>
using Clock=std::chrono::steady_clock;
static double elapsed(Clock::time_point t){return chrono::duration<double,milli>(Clock::now()-t).count();}
static long field(const string& key){ifstream f("/proc/self/status");string line;while(getline(f,line))if(line.rfind(key+":",0)==0){istringstream s(line.substr(key.size()+1));long n;s>>n;return n;}throw runtime_error("proc field missing");}
struct Result{long before,current,peak;uint64_t checksum,indexPeak,supportPeak;int error;};
int main(int argc,char** argv){
  try{
    if(argc!=5)throw runtime_error("graph samples output cpu required");
    cpu_set_t mask;CPU_ZERO(&mask);CPU_SET(stoi(argv[4]),&mask);if(sched_setaffinity(0,sizeof(mask),&mask))throw runtime_error("affinity failed");
    filesystem::path out=argv[3];if(!filesystem::create_directory(out))throw runtime_error("output exists");
    auto total=Clock::now();auto t=total;
    shared_ptr<Insertion60Base> base;PI62_MEMORY_BLOCK(Graph,base=make_shared<Insertion60Base>());string graph=argv[1];PI62_MEMORY_BLOCK(Graph,base->graph.read_graph(graph,0));double readMs=elapsed(t);t=Clock::now();
    vector<intV> order,inverse;base->graph.sort_deg(order);invertMap(order,inverse);base->graph.reorder_in_place(inverse);
    base->left.resize(base->graph.numT);for(intV v=0;v<base->graph.numT;++v)base->left[v]=order[v]<base->graph.numU;
    label_edges(base->graph);edgeId_to_vertices(base->graph);double orderMs=elapsed(t);t=Clock::now();
    vector<intE> es(base->graph.numE,0),phi(base->graph.numE,0);
    {vector<intV> wedges(base->graph.numT,0);PI62_MEMORY_BLOCK(Index,creat_BEIndex(base->graph,es,base->index,wedges));}
    double indexMs=elapsed(t);t=Clock::now();
    {auto index=base->index;auto support=es;fine_peel_part_wing(index,support,phi);}
    double peelMs=elapsed(t);t=Clock::now();
    vector<pair<intV,intV>> updates;ifstream samples(argv[2]);string line;
    while(getline(samples,line)){if(line.empty()||line[0]=='#'||line[0]=='%')continue;istringstream row(line);intV u,v;if(!(row>>u>>v))throw runtime_error("bad sample");updates.emplace_back(u,v);}
    if(updates.size()!=500)throw runtime_error("expected 500 samples");double sampleMs=elapsed(t);t=Clock::now();
    unique_ptr<Insertion68State> state;
    {Insertion60State initial(base,phi,vector<uint64_t>(es.begin(),es.end()));PI62_MEMORY_BLOCK(Aux,state=make_unique<Insertion68State>(initial));}
    double stateMs=elapsed(t);
    vector<intE>().swap(es);vector<intE>().swap(phi);vector<intV>().swap(order);vector<intV>().swap(inverse);malloc_trim(0);
#ifdef ALLOC
    allocation62::retag(state->phi.data(),allocation62::Output);allocation62::retag(state->es.data(),allocation62::Output);allocation62::retag(state->h.data(),allocation62::Aux);
#endif
    if(field("Threads")!=1)throw runtime_error("not single threaded");double initMs=elapsed(total)-sampleMs;
    ofstream events(out/"events.tsv");events<<"event_id\tbaseline_rss_kib\tcurrent_rss_kib\tpeak_rss_kib\tchecksum\n";
    ofstream capacities(out/"capacities.tsv");capacities<<"event_id\tindex_peak_bytes\th_peak_bytes\n";
    for(int id=-1;id<500;++id){
      int pipefd[2];if(pipe(pipefd))throw runtime_error("pipe failed");pid_t child=fork();if(child<0)throw runtime_error("fork failed");
      if(child==0){close(pipefd[0]);Result r{};try{
        PI62_MEMORY_BLOCK(Output,state->phi.reserve(state->edges()+1);state->es.reserve(state->edges()+1));PI62_MEMORY_BLOCK(Aux,state->h.reserve(state->edges()+1));
        r.before=field("VmRSS");auto uv=updates[id<0?0:id];
#ifdef ALLOC
        allocation62::begin();
#endif
        PI62_MEMORY_BLOCK(Aux,state->insert(uv.first,uv.second));
#ifdef ALLOC
        allocation62::end();r.indexPeak=allocation62::peak[allocation62::Index];r.supportPeak=allocation62::peak[allocation62::Aux];
#endif
        r.current=field("VmRSS");r.peak=field("VmHWM");r.checksum=state->edges();
        if(field("Threads")!=1)throw runtime_error("worker not single threaded");
      }catch(const exception&){r.error=1;}auto n=write(pipefd[1],&r,sizeof(r));close(pipefd[1]);_exit(n==sizeof(r)&&!r.error?0:1);}
      close(pipefd[1]);Result r{};auto n=read(pipefd[0],&r,sizeof(r));close(pipefd[0]);int status;waitpid(child,&status,0);
      if(n!=sizeof(r)||!WIFEXITED(status)||WEXITSTATUS(status)||r.error)throw runtime_error("memory child failed");
      if(id>=0)events<<id<<'\t'<<r.before<<'\t'<<r.current<<'\t'<<r.peak<<'\t'<<r.checksum<<'\n';
      if(id>=0)capacities<<id<<'\t'<<r.indexPeak<<'\t'<<r.supportPeak<<'\n';
    }
    ofstream status(out/"status.json");status<<setprecision(17)<<"{\"events\":500,\"actual_threads\":1,\"failures\":0,\"read_ms\":"<<readMs<<",\"order_ms\":"<<orderMs<<",\"index_ms\":"<<indexMs<<",\"peel_ms\":"<<peelMs<<",\"state_ms\":"<<stateMs<<",\"initialization_total_ms\":"<<initMs<<"}\n";
    if(!events||!status)throw runtime_error("output failed");
  }catch(const exception& e){cerr<<e.what()<<endl;return 1;}
}
