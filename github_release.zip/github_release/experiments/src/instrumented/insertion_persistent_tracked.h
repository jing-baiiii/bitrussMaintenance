#ifndef ARRAY_INSERTION_PERSISTENT68_H
#define ARRAY_INSERTION_PERSISTENT68_H 
#include "allocation.h"
#include "insertion_layer_tracked.h"
struct Insertion68Metrics : Insertion60Metrics {
    uint64_t hInitialWrites=0,hPromotionWrites=0,hAssignments=0,hLogicalInc=0;
    uint64_t hMembershipScans=0,hWedgeScans=0,hEffectiveWedges=0,hGroups=0;
};
#ifdef INSERT60_COUNT
#define I68_COUNT(field,amount) do {if(metrics)metrics->field+=(amount);} while(0)
#else
#define I68_COUNT(field,amount) do {} while(0)
#endif
class Insertion68State : public Insertion60State {
public:
    vector<uint64_t> h;
    Insertion68State(shared_ptr<const Insertion60Base> initial,vector<intE> levels,vector<uint64_t> supports)
        :Insertion60State(std::move(initial),std::move(levels),std::move(supports)) {initializeH();}
    explicit Insertion68State(const Insertion60State& state):Insertion60State(state) {initializeH();}
    void initializeH() {
        h.assign(edges(),0);
        for(intB b=0;b<blooms();++b) {
            vector<intE> levels;vector<Wedge> paths;
            wedges(b,[&](Wedge w){paths.push_back(w);levels.push_back(min(phi[w.first],phi[w.second]));});
            sort(levels.begin(),levels.end());
            for(Wedge w:paths)for(intE e:{w.first,w.second}) {
                intE twin=e==w.first?w.second:w.first;
                if(phi[twin]<phi[e])continue;
                uint64_t count=levels.end()-lower_bound(levels.begin(),levels.end(),phi[e]);
                if(!count)throw runtime_error("own wedge missing in initial support");
                addSupport(e,count-1);
            }
        }
    }
    void addSupport(intE e,uint64_t gain) {
        if(h[e]>numeric_limits<uint64_t>::max()-gain)throw overflow_error("own-layer support overflow");
        h[e]+=gain;
    }
    intE insert(intV u,intV v,Insertion68Metrics* metrics=nullptr) {
        if(u>=base->graph.numT||v>=base->graph.numT||base->left[u]==base->left[v])
            throw runtime_error("insertion endpoints outside fixed bipartition");
        if(findEdge(u,v,metrics)!=noEdge)throw runtime_error("insertion edge already exists");
        if(edges()>=noEdge)throw overflow_error("edge id exhausted");
        const intE inserted=edges();
        PI62_MEMORY_BLOCK(Graph,addedEdges.push_back({u,v}));
        PI62_MEMORY_BLOCK(Output,phi.push_back(0);es.push_back(0);h.push_back(0));
        auto addNeighbor=[&](intV a,intV b) {
            auto& list=addedAdj[a];auto it=lower_bound(list.begin(),list.end(),b,[](auto e,intV x){return e.first<x;});
            list.insert(it,{b,inserted});
        };
        PI62_MEMORY_BLOCK(Graph,addNeighbor(u,v);addNeighbor(v,u));
        workspace.grow(edges());
        struct Growth {Wedge current,prior;intB bloom=-1;};
        map<pair<intV,intV>,Growth> growth;
        map<intE,vector<intE>> roots;
        neighbors(u,[&](intV otherV,intE edge2) {
            I68_COUNT(firstHop,1);if(otherV==v)return;
            neighbors(v,[&](intV otherU,intE edge3) {
                I68_COUNT(secondHop,1);if(otherU==u)return;
                intE edge4=findEdge(otherU,otherV,metrics);if(edge4==noEdge)return;
                I68_COUNT(initialButterflies,1);
                array<intE,4> butterfly={inserted,edge2,edge3,edge4};
                for(intE e:butterfly) {
                    if(es[e]==std::numeric_limits<uint64_t>::max())throw overflow_error("total support overflow");
                    ++es[e];I68_COUNT(totalSupportWrites,1);I68_COUNT(totalSupportLogicalInc,1);
                    if(phi[e]==0) {addSupport(e,1);I68_COUNT(hInitialWrites,1);I68_COUNT(hLogicalInc,1);}
                    if(phi[e]==noEdge)throw overflow_error("layer exhausted");
                    roots[phi[e]+1].push_back(e);
                }
                intV minimum=min(min(u,v),min(otherU,otherV));
                bool masterU=minimum==u||minimum==otherU;
                pair<intV,intV> key=masterU?minmax(u,otherU):minmax(v,otherV);
                Wedge current={inserted,masterU?edge3:edge2};
                Wedge prior=masterU?Wedge{edge2,edge4}:Wedge{edge3,edge4};
                auto found=growth.find(key);
                if(found!=growth.end()) {
                    if(found->second.current!=current)throw runtime_error("inconsistent new wedge");
                    if(found->second.bloom<0&&minmax(found->second.prior.first,found->second.prior.second)!=minmax(prior.first,prior.second))
                        throw runtime_error("missing old bloom with multiple prior paths");
                    return;
                }
                intB b=-1;
                auto fresh=addedMaster.find(key);if(fresh!=addedMaster.end())b=fresh->second;
                if(b<0)memberships(prior.first,[&](Membership entry) {
                    I68_COUNT(masterMembershipScans,1);auto m=master(entry.first);
                    if(min(m.first,m.second)==key.first&&max(m.first,m.second)==key.second)b=entry.first;
                });
                growth.emplace(key,Growth{current,prior,b});
            });
        });
        auto addWedge=[&](intB b,Wedge w) {
            PI62_MEMORY_BLOCK(Index,addedWedges[b].push_back(w);addedMemberships[w.first].push_back({b,w.second});
            addedMemberships[w.second].push_back({b,w.first}));
            I68_COUNT(newWedges,1);I68_COUNT(newMemberships,2);
        };
        for(auto& item:growth) {
            auto& g=item.second;
            if(g.bloom<0) {
                g.bloom=blooms();PI62_MEMORY_BLOCK(Index,addedBlooms.push_back({{item.first.second,item.first.first}});
                addedMaster.emplace(item.first,g.bloom));addWedge(g.bloom,g.prior);I68_COUNT(newBlooms,1);
            }
            addWedge(g.bloom,g.current);
        }
        auto& work=workspace;
        while(!roots.empty()) {
            auto first=roots.begin();const intE k=first->first;
            vector<intE> seeds=std::move(first->second);roots.erase(first);I68_COUNT(layers,1);
            vector<intE> candidates;
            unordered_map<intB,uint64_t> good;
            unordered_map<intB,char> expanded;
            bool discovering=true;
            auto eligible=[&](intE e) {return phi[e]>=k||(phi[e]==k-1&&h[e]>=k);};
            auto activeWedge=[&](Wedge w) {
                auto live=[&](intE edge){return eligible(edge)&&!work.retired[edge]&&(discovering||phi[edge]>=k||work.candidate[edge]);};
                return live(w.first)&&live(w.second);
            };
            auto admit=[&](intE e) {
                I68_COUNT(filterChecks,1);
                if(phi[e]!=k-1||h[e]<k||work.candidate[e])return;
                work.candidate[e]=1;work.touched.push_back(e);candidates.push_back(e);I68_COUNT(candidates,1);
                if(!work.seenEvent[e]) {work.seenEvent[e]=1;work.seenTouched.push_back(e);I68_COUNT(candidateUnique,1);}
            };
            auto ensureGood=[&](intB b) {
                auto known=good.find(b);
                if(known!=good.end())return known->second;
                uint64_t count=0;
                wedges(b,[&](Wedge w){I68_COUNT(supportWedgeScans,1);if(activeWedge(w))++count;});
                good.emplace(b,count);I68_COUNT(bloomBuilds,1);
                return count;
            };
            for(intE e:seeds)admit(e);
            for(size_t position=0;position<candidates.size();++position) {
                intE e=candidates[position];
                I68_COUNT(eeChecks,1);
                uint64_t workingSupport=0;
                memberships(e,[&](Membership entry) {
                    if(!eligible(entry.second))return;
                    uint64_t count=ensureGood(entry.first);
                    if(count)workingSupport+=count-1;
                });
                if(workingSupport<k) {I68_COUNT(eeStops,1);continue;}
                I68_COUNT(eePropagations,1);
                memberships(e,[&](Membership entry) {
                    I68_COUNT(closureMemberships,1);
                    if(!eligible(entry.second))return;
                    if(expanded[entry.first]) {I68_COUNT(bloomHits,1);return;}
                    uint64_t count=ensureGood(entry.first);vector<intE> reached;
                    wedges(entry.first,[&](Wedge w) {
                        if(!activeWedge(w))return;
                        if(phi[w.first]==k-1)reached.push_back(w.first);
                        if(phi[w.second]==k-1)reached.push_back(w.second);
                    });
                    expanded[entry.first]=1;
                    if(count>=2)for(intE x:reached)admit(x);
                });
            }
            discovering=false;good.clear();
            vector<intE> current;
            for(intE e:candidates) {
                uint64_t support=0;
                memberships(e,[&](Membership entry) {
                    I68_COUNT(supportMemberships,1);if(!activeWedge({e,entry.second}))return;
                    uint64_t count=ensureGood(entry.first);
                    if(count) {
                        if(support>std::numeric_limits<uint64_t>::max()-(count-1))throw overflow_error("work support overflow");
                        support+=count-1;
                    }
                });
                work.support[e]=support;I68_COUNT(supportInitializations,1);
                if(support<k)current.push_back(e);
            }
            while(!current.empty()) {
                I68_COUNT(batches,1);I68_COUNT(peelPairs,current.size());
                for(intE e:current)work.inBatch[e]=1;
                unordered_map<intB,uint64_t> broken;
                for(intE e:current)memberships(e,[&](Membership entry) {
                    I68_COUNT(cascadeMemberships,1);
                    intE twin=entry.second;
                    if(!activeWedge({e,twin})||(work.inBatch[twin]&&e>twin))return;
                    ++broken[entry.first];
                });
                vector<intE> next;
                for(auto item:broken) {
                    I68_COUNT(algebraLossGroups,1);
                    uint64_t& count=good.at(item.first);uint64_t d=item.second;
                    if(count<d)throw runtime_error("invalid batch path loss");
                    I68_COUNT(cascadeGroups,1);
                    wedges(item.first,[&](Wedge w) {
                        I68_COUNT(cascadeWedgeScans,1);if(!activeWedge(w))return;
                        I68_COUNT(cascadeEffectiveWedges,1);
                        uint64_t loss=(work.inBatch[w.first]||work.inBatch[w.second])?count-1:d;
                        if(loss==0)return;
                        for(intE e:{w.first,w.second}) {
                            if(!work.candidate[e]||work.inBatch[e]||work.retired[e])continue;
                            if(work.support[e]<loss)throw runtime_error("work support underflow");
                            uint64_t before=work.support[e];work.support[e]-=loss;
                            I68_COUNT(workSupportWrites,1);I68_COUNT(workSupportLogicalDec,loss);
                            if(before>=k&&work.support[e]<k)next.push_back(e);
                        }
                    });
                    count-=d;
                }
                for(intE e:current) {work.retired[e]=1;work.inBatch[e]=0;}
                current=std::move(next);
            }
            vector<intE> promoted;
            unordered_set<intB> changedGroups;
            for(intE e:candidates)if(!work.retired[e]) {
                promoted.push_back(e);work.inBatch[e]=1;h[e]=0;I68_COUNT(hAssignments,1);
                memberships(e,[&](Membership entry) {
                    I68_COUNT(hMembershipScans,1);changedGroups.insert(entry.first);
                });
            }
            for(intE e:promoted) {
                phi[e]=k;I68_COUNT(phiWritesIncludingNew,1);
                if(e!=inserted)I68_COUNT(phiWritesExcludingNew,1);
                I68_COUNT(promotedEdges,1);
            }
            for(intB b:changedGroups) {
                vector<Wedge> active;uint64_t oldGood=0;I68_COUNT(hGroups,1);
                wedges(b,[&](Wedge w) {
                    I68_COUNT(hWedgeScans,1);
                    if(phi[w.first]<k||phi[w.second]<k)return;
                    active.push_back(w);
                    if(!work.inBatch[w.first]&&!work.inBatch[w.second])++oldGood;
                });
                const uint64_t newGood=active.size();
                if(newGood==oldGood)continue;
                for(Wedge w:active) {
                    I68_COUNT(hEffectiveWedges,1);
                    for(intE e:{w.first,w.second}) {
                        if(phi[e]!=k)continue;
                        intE twin=e==w.first?w.second:w.first;
                        uint64_t gain=work.inBatch[e]||work.inBatch[twin]?newGood-1:newGood-oldGood;
                        if(!gain)continue;
                        addSupport(e,gain);I68_COUNT(hPromotionWrites,1);I68_COUNT(hLogicalInc,gain);
                        if(!work.inBatch[e]&&h[e]>=uint64_t(k)+1) {
                            if(k==noEdge)throw overflow_error("layer exhausted");
                            roots[k+1].push_back(e);
                        }
                    }
                }
            }
            for(intE e:promoted) {
                work.inBatch[e]=0;
                if(h[e]<k)throw runtime_error("promoted edge has insufficient own-layer support");
                if(h[e]>=uint64_t(k)+1) {
                    if(k==noEdge)throw overflow_error("layer exhausted");
                    roots[k+1].push_back(e);
                }
            }
            work.clearLayer();
        }
        work.clearEvent();return inserted;
    }
};
#undef I68_COUNT
#endif
