#define PI62_MEMORY 
#define PI62_MEMORY_IMPLEMENTATION 
#include "allocation.h"
#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "insertion_layer_tracked.h"
#include "insertion_persistent_tracked.h"
#include "deletion_layer.h"
#include "deletion_persistent.h"
#include <filesystem>
#include <chrono>
#include <iomanip>
#include <sched.h>
using Clock=chrono::steady_clock;
static volatile uint64_t querySink=0;
static double elapsed(Clock::time_point start){return chrono::duration<double,milli>(Clock::now()-start).count();}
static uint64_t capacity(const BEGraphLoMem& ix) {
    return ix.edgeVI.capacity()*sizeof(intB)+ix.bloomVI.capacity()*sizeof(intB)
        +ix.edgeDegree.capacity()*sizeof(intE)+ix.bloomDegree.capacity()*sizeof(intE)
        +ix.bloomWdgCnt.capacity()*sizeof(intE)+ix.bloomMaster.capacity()*sizeof(pair<intV,intV>)
        +ix.edgeEI.capacity()*sizeof(pair<intB,intE>)+ix.bloomEI.capacity()*sizeof(pair<intE,intE>);
}
static void tagGraph(Graph& graph){
    allocation62::retag(graph.eId.data(),allocation62::Graph);
    for(auto& row:graph.eId)allocation62::retag(row.data(),allocation62::Graph);
    allocation62::retag(graph.eIdToV.data(),allocation62::Graph);
}
int main(int argc,char** argv){
    try{
        if(argc!=6)throw runtime_error("mode graph samples output cpu required");
        const bool insert=string(argv[1])=="insert";
        if(!insert&&string(argv[1])!="delete")throw runtime_error("mode");
        cpu_set_t affinity;CPU_ZERO(&affinity);CPU_SET(stoi(argv[5]),&affinity);
        if(sched_setaffinity(0,sizeof(affinity),&affinity))throw runtime_error("affinity");
        filesystem::path out=argv[4];if(!filesystem::create_directory(out))throw runtime_error("output exists");
        shared_ptr<Insertion60Base> base;
        auto started=Clock::now();
        {allocation62::Scope scope(allocation62::Graph);base=make_shared<Insertion60Base>();string path=argv[2];base->graph.read_graph(path,0);}
        vector<intV> order,inverse;base->graph.sort_deg(order);invertMap(order,inverse);base->graph.reorder_in_place(inverse);
        base->left.resize(base->graph.numT);for(intV v=0;v<base->graph.numT;++v)base->left[v]=order[v]<base->graph.numU;
        vector<intE> phi,es;
        {allocation62::Scope scope(allocation62::Index);arrayBuildBase(base->graph,base->index,es,phi);}
        for(auto* v:{&base->index.edgeVI,&base->index.bloomVI})allocation62::retag(v->data(),allocation62::Index);
        tagGraph(base->graph);allocation62::retag(phi.data(),allocation62::Output);allocation62::retag(es.data(),allocation62::Output);
        const double loadBuild=elapsed(started);
        if(allocation62::live[allocation62::Index]!=capacity(base->index))throw runtime_error("base index allocation accounting mismatch");
        vector<intB> h;unique_ptr<Insertion68State> state;
        started=Clock::now();
        {allocation62::Scope scope(allocation62::Output);
            if(insert)state=make_unique<Insertion68State>(base,phi,vector<uint64_t>(es.begin(),es.end()));
            else buildPersistentSupport(base->index,phi,h);
        }
        const double hBuild=elapsed(started);
        vector<pair<intV,intV>> events;set<pair<intV,intV>> seen;ifstream input(argv[3]);string line;size_t rows=0;
        if(!input)throw runtime_error("samples missing");
        while(getline(input,line)){
            if(line.empty()||line[0]=='#'||line[0]=='%')continue;
            istringstream row(line);intV u,v;string extra;
            if(!(row>>u>>v)||(row>>extra)||u>=base->graph.numT||v>=base->graph.numT||base->left[u]==base->left[v])throw runtime_error("invalid sample");
            ++rows;if(seen.emplace(min(u,v),max(u,v)).second)events.push_back({u,v});
        }
        if(rows!=500)throw runtime_error("expected 500 rows");
        auto find=[&](intV u,intV v){const auto& adj=base->graph.adj[u];auto it=lower_bound(adj.begin(),adj.end(),v);
            return it==adj.end()||*it!=v?Insertion60State::noEdge:base->graph.eId[u][it-adj.begin()];};
        vector<intE> deleted;for(auto uv:events){auto e=find(uv.first,uv.second);if(insert?(e!=Insertion60State::noEdge):(e==Insertion60State::noEdge))throw runtime_error("presence mismatch");deleted.push_back(e);}
        vector<char> present(base->graph.numE,1);PersistentWorkspace work;
        ofstream structures(out/"structures.tsv"),queries(out/"queries.tsv");
        structures<<"step\tkind\tedges\tblooms\tpaths\tmemberships\tindex_requested_capacity_bytes\trebuild_index_ms\trebuild_peel_ms\n";
        queries<<"step\tquery\tu\tv\tkind\trepeat\ttime_ms\tpath_visits\tmembership_slots\n";
        auto checkpoint=[&](size_t step){
            uint64_t blooms=0,paths=0;
            for(intB b=0;b<(insert?state->blooms():base->index.numV);++b){
                uint64_t degree=0;if(insert)state->wedges(b,[&](auto){++degree;});else degree=base->index.bloomDegree[b];
                if(degree>=2){++blooms;paths+=degree;}
            }
            structures<<step<<"\tmaintained\t"<<(insert?state->edges():phi.size()-step)<<'\t'<<blooms<<'\t'<<paths<<'\t'<<paths*2<<'\t'<<allocation62::live[allocation62::Index]<<"\t-1\t-1\n";
            allocation62::Scope referenceScope(allocation62::Test);
            Graph graph=base->graph;
            for(size_t i=0;i<step;++i){auto uv=events[i];if(insert)insertEdgeIntoG(graph,uv.first,uv.second);else deleteEdgeFromG(graph,uv.first,uv.second);}
            vector<intV> fresh,freshInverse;graph.sort_deg(fresh);invertMap(fresh,freshInverse);graph.reorder_in_place(freshInverse);
            label_edges(graph);edgeId_to_vertices(graph);
            BEGraphLoMem gold;vector<intE> support(graph.numE,0);vector<intV> wedges(graph.numT,0);
            auto t=Clock::now();creat_BEIndex(graph,support,gold,wedges);double indexMs=elapsed(t);
            auto peel=gold;auto peelSupport=support;vector<intE> values(graph.numE,0);
            t=Clock::now();fine_peel_part_wing(peel,peelSupport,values);double peelMs=elapsed(t);
            vector<intB> goldH;buildPersistentSupport(gold,values,goldH);
            uint64_t goldPaths=0,goldBlooms=0;for(auto d:gold.bloomDegree)if(d>=2){++goldBlooms;goldPaths+=d;}
            structures<<step<<"\trebuilt\t"<<graph.numE<<'\t'<<goldBlooms<<'\t'<<goldPaths<<'\t'<<goldPaths*2<<'\t'<<capacity(gold)<<'\t'<<setprecision(12)<<indexMs<<'\t'<<peelMs<<'\n';
            for(intE e=0;e<graph.numE;++e){
                auto uv=graph.eIdToV[e];uv={fresh[uv.first],fresh[uv.second]};
                auto id=insert?state->findEdge(uv.first,uv.second):find(uv.first,uv.second);
                if(id==Insertion60State::noEdge||(!insert&&!present[id]))throw runtime_error("mapping mismatch");
                if(values[e]!=(insert?state->phi[id]:phi[id])||support[e]!=(insert?state->es[id]:(uint64_t)es[id])||(uint64_t)goldH[e]!=(insert?state->h[id]:(uint64_t)h[id]))throw runtime_error("checkpoint phi/es/h mismatch");
            }
            mt19937_64 random(820016);uniform_int_distribution<intE> pick(0,graph.numE-1);
            for(int q=0;q<500;++q){
                intE e=pick(random);auto uv=graph.eIdToV[e];uv={fresh[uv.first],fresh[uv.second]};
                auto id=insert?state->findEdge(uv.first,uv.second):find(uv.first,uv.second);
                for(int repeat=-1;repeat<3;++repeat)for(int kind=0;kind<2;++kind){
                    uint64_t visits=0,slots=0,checksum=0;auto begin=Clock::now();
                    auto query=[&](auto item){
                        auto path=[&](auto w){++visits;checksum+=uint64_t(w.first)+w.second;};
                        if(!kind&&insert)state->wedges(item.first,path);
                        else{const auto& ix=kind?gold:base->index;for(intB j=ix.bloomVI[item.first];j<ix.bloomVI[item.first]+ix.bloomDegree[item.first];++j)path(ix.bloomEI[j]);}
                    };
                    if(!kind&&insert)state->memberships(id,[&](auto item){++slots;query(item);});
                    else{const auto& ix=kind?gold:base->index;intE edge=kind?e:id;for(intB j=ix.edgeVI[edge];j<ix.edgeVI[edge+1];++j){++slots;if(ix.edgeEI[j].first>=0)query(ix.edgeEI[j]);}}
                    double ms=elapsed(begin);querySink=checksum;
                    if(repeat>=0)queries<<step<<'\t'<<q<<'\t'<<uv.first<<'\t'<<uv.second<<'\t'<<(kind?"rebuilt":"maintained")<<'\t'<<repeat<<'\t'<<setprecision(12)<<ms<<'\t'<<visits<<'\t'<<slots<<'\n';
                }
            }
            structures.flush();queries.flush();cout<<"INDEX82_CHECKPOINT step="<<step<<" passed"<<endl;
        };
        checkpoint(0);
        for(size_t i=0;i<events.size();++i){
            {allocation62::Scope scope(allocation62::Aux);auto uv=events[i];if(insert)state->insert(uv.first,uv.second);else{arrayBMDPersistent(base->index,phi,es,h,deleted[i],work);present[deleted[i]]=0;}}
            if(i+1==100||i+1==250||i+1==events.size())checkpoint(i+1);
        }
        ofstream status(out/"status.json");status<<"{\"events\":"<<events.size()<<",\"checkpoints\":4,\"queries_per_checkpoint\":500,\"query_repeats\":3,\"checkpoint_full_static_checks\":4,\"load_build_ms\":"<<loadBuild<<",\"h_state_initialization_ms\":"<<hBuild<<",\"allocation_instrumented\":true,\"failures\":0}\n";
        if(!structures||!queries||!status)throw runtime_error("output failure");
    }catch(const exception& e){cerr<<"INDEX82_FAIL "<<e.what()<<endl;return 1;}
}
