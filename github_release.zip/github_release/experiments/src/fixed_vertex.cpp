#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "insertion_layer.h"
#include "insertion_persistent.h"
#include "deletion_layer.h"
#include "deletion_persistent.h"
#include <chrono>
#include <filesystem>
#include <iomanip>
#include <random>
#include <sched.h>

using Timer = std::chrono::steady_clock;
static double ms(Timer::time_point t) {
    return std::chrono::duration<double,std::milli>(Timer::now()-t).count();
}
static uint64_t indexBytes(const BEGraphLoMem& x) {
    return x.edgeVI.capacity()*sizeof(intB)+x.bloomVI.capacity()*sizeof(intB)
        +x.edgeDegree.capacity()*sizeof(intE)+x.bloomDegree.capacity()*sizeof(intE)
        +x.bloomWdgCnt.capacity()*sizeof(intE)+x.bloomMaster.capacity()*sizeof(pair<intV,intV>)
        +x.edgeEI.capacity()*sizeof(pair<intB,intE>)+x.bloomEI.capacity()*sizeof(pair<intE,intE>);
}

int main(int argc,char** argv) {
    try {
        if(argc!=5)throw runtime_error("graph output cpu seed required");
        cpu_set_t affinity;CPU_ZERO(&affinity);CPU_SET(stoi(argv[3]),&affinity);
        if(sched_setaffinity(0,sizeof(affinity),&affinity))throw runtime_error("affinity");
        filesystem::path out=argv[2];if(!filesystem::create_directory(out))throw runtime_error("output exists");
        const uint64_t seed=stoull(argv[4]);mt19937_64 rng(seed);
        auto base=make_shared<Insertion60Base>();string filename=argv[1];base->graph.read_graph(filename,0);
        const size_t count=1000;
        vector<intV> eligible;
        for(intV u=0;u<base->graph.numU;++u)
            if(base->graph.numV-base->graph.adj[u].size()>=count)eligible.push_back(u);
        if(eligible.empty())throw runtime_error("no left vertex with 1000 missing neighbors");
        intV fixed=eligible[uniform_int_distribution<size_t>(0,eligible.size()-1)(rng)];
        vector<intV> missing;
        for(intV v=base->graph.numU;v<base->graph.numT;++v)
            if(!binary_search(base->graph.adj[fixed].begin(),base->graph.adj[fixed].end(),v))missing.push_back(v);
        shuffle(missing.begin(),missing.end(),rng);missing.resize(count);
        ofstream samples(out/"samples_original.tsv");samples<<"# seed="<<seed<<" fixed_left_vertex="<<fixed<<"\n";
        for(intV v:missing)samples<<fixed<<'\t'<<v<<'\n';samples.close();
        vector<intV> order,inverse;base->graph.sort_deg(order);invertMap(order,inverse);base->graph.reorder_in_place(inverse);
        base->left.resize(base->graph.numT);
        for(intV v=0;v<base->graph.numT;++v)base->left[v]=order[v]<base->graph.numU;
        vector<pair<intV,intV>> events;for(intV v:missing)events.push_back({inverse[fixed],inverse[v]});
        vector<intE> phi,es;arrayBuildBase(base->graph,base->index,es,phi);
        Insertion68State initial(base,phi,vector<uint64_t>(es.begin(),es.end()));
        ofstream times(out/"events.tsv"),structures(out/"structures.tsv");
        times<<"repeat\tevent\tu\tv\ttime_ms\tbutterflies_created\n";
        structures<<"step\tkind\tedges\tblooms\tpaths\tmemberships\tpacked_index_capacity_bytes\tmean_path_visits\tmax_path_visits\n";
        {auto warm=initial;warm.insert(events[0].first,events[0].second);}
        for(int repeat=0;repeat<3;++repeat) {
            auto state=initial;
            for(size_t i=0;i<count;++i) {
                auto uv=events[i];auto t=Timer::now();auto id=state.insert(uv.first,uv.second);double elapsed=ms(t);
                times<<repeat<<'\t'<<i+1<<'\t'<<fixed<<'\t'<<missing[i]<<'\t'<<setprecision(12)<<elapsed<<'\t'<<state.es[id]<<'\n';
            }
            times.flush();cout<<"TIMING_PASS repeat="<<repeat<<" events="<<count<<endl;
        }
        auto state=initial;size_t checks=0;uint64_t butterflyChanging=0;
        auto checkpoint=[&](size_t step) {
            Graph graph=base->graph;
            for(size_t i=0;i<step;++i)insertEdgeIntoG(graph,events[i].first,events[i].second);
            vector<intV> fresh,inv;graph.sort_deg(fresh);invertMap(fresh,inv);graph.reorder_in_place(inv);
            BEGraphLoMem gold;vector<intE> goldES,goldPhi;arrayBuildBase(graph,gold,goldES,goldPhi);
            vector<intB> goldH;buildPersistentSupport(gold,goldPhi,goldH);
            if(graph.numE!=state.edges())throw runtime_error("edge count mismatch");
            uint64_t visits[2]={0,0},maxVisits[2]={0,0},paths[2]={0,0},blooms[2]={0,0};
            vector<uint64_t> degree(state.blooms(),0);
            for(intB b=0;b<state.blooms();++b) {
                uint64_t d=0;state.wedges(b,[&](auto){++d;});degree[b]=d;if(d>=2){++blooms[0];paths[0]+=d;}
            }
            for(auto d:gold.bloomDegree)if(d>=2){++blooms[1];paths[1]+=d;}
            for(intE e=0;e<graph.numE;++e) {
                auto uv=graph.eIdToV[e];auto id=state.findEdge(fresh[uv.first],fresh[uv.second]);
                if(id==Insertion60State::noEdge||state.phi[id]!=goldPhi[e]||state.es[id]!=(uint64_t)goldES[e]||state.h[id]!=(uint64_t)goldH[e])
                    throw runtime_error("full static phi/es/h mismatch");
                uint64_t v[2]={0,0},support=0;
                state.memberships(id,[&](auto item){auto d=degree[item.first];v[0]+=d;support+=d-1;});
                if(support!=state.es[id])throw runtime_error("maintained query support mismatch");
                for(intB j=gold.edgeVI[e];j<gold.edgeVI[e+1];++j)v[1]+=gold.bloomDegree[gold.edgeEI[j].first];
                for(int k=0;k<2;++k){visits[k]+=v[k];maxVisits[k]=max(maxVisits[k],v[k]);}
            }
            for(int k=0;k<2;++k)structures<<step<<'\t'<<(k?"rebuilt":"maintained")<<'\t'<<graph.numE<<'\t'<<blooms[k]<<'\t'<<paths[k]<<'\t'<<2*paths[k]<<'\t'<<(k?indexBytes(gold):0)<<'\t'<<setprecision(12)<<double(visits[k])/graph.numE<<'\t'<<maxVisits[k]<<'\n';
            structures.flush();++checks;cout<<"STATIC_PASS step="<<step<<endl;
        };
        checkpoint(0);
        for(size_t i=0;i<count;++i) {
            auto id=state.insert(events[i].first,events[i].second);butterflyChanging+=state.es[id]>0;
            if(i+1==100||i+1==250||i+1==500||i+1==count)checkpoint(i+1);
        }
        ofstream status(out/"status.json");
        status<<"{\"seed\":"<<seed<<",\"fixed_left_vertex_original\":"<<fixed
              <<",\"events\":1000,\"timing_repeats\":3,\"full_static_checkpoints\":"<<checks
              <<",\"butterfly_changing_events\":"<<butterflyChanging<<",\"failures\":0}\n";
        if(!times||!structures||!status)throw runtime_error("output write failure");
    }catch(const exception& e){cerr<<"STAR_FAIL "<<e.what()<<endl;return 1;}
}
