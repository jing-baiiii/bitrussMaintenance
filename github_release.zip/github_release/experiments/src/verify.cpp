#define INSERT60_COUNT 
#define ABP_COUNT_OPS 
#define L56_SINGLE_ONLY 
#define INSERT_COUNT 
#define L_SINGLE_ONLY 
#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#define INSERT insert
#include "insertion_layer.h"
#include "deletion_layer.h"
#include "insertion_persistent.h"
#include "deletion_persistent.h"
#include <random>
using Butterfly=array<intE,4>;
static uint64_t checks=0,events=0,eeStops=0,explicitWitnesses=0;
static vector<Butterfly> butterflies(const vector<pair<intV,intV>>& edges,const vector<char>& alive) {
    map<pair<intV,intV>,intE> ids;
    for(intE e=0;e<edges.size();++e)if(alive[e])ids[minmax(edges[e].first,edges[e].second)]=e;
    vector<Butterfly> out;
    for(auto a=ids.begin();a!=ids.end();++a)for(auto b=next(a);b!=ids.end();++b) {
        auto x=a->first,y=b->first;
        if(x.first==y.first||x.first==y.second||x.second==y.first||x.second==y.second)continue;
        for(auto crossing:{make_pair(make_pair(x.first,y.first),make_pair(x.second,y.second)),
                           make_pair(make_pair(x.first,y.second),make_pair(x.second,y.first))}) {
            auto c=ids.find(minmax(crossing.first.first,crossing.first.second));
            auto d=ids.find(minmax(crossing.second.first,crossing.second.second));
            if(c==ids.end()||d==ids.end())continue;
            Butterfly q={a->second,b->second,c->second,d->second};sort(q.begin(),q.end());out.push_back(q);
        }
    }
    sort(out.begin(),out.end());out.erase(unique(out.begin(),out.end()),out.end());return out;
}
static vector<intE> oracle(size_t n,const vector<char>& alive,const vector<Butterfly>& butterflies) {
    vector<intE> result(n,0);intE upper=0;
    vector<intE> total(n,0);for(auto q:butterflies)for(intE e:q)upper=max(upper,++total[e]);
    for(intE k=1;k<=upper;++k) {
        vector<char> live=alive;
        while(true) {
            vector<intE> support(n,0);
            for(auto q:butterflies)if(all_of(q.begin(),q.end(),[&](intE e){return live[e];}))for(intE e:q)++support[e];
            bool changed=false;
            for(intE e=0;e<n;++e)if(live[e]&&support[e]<k){live[e]=0;changed=true;}
            if(!changed)break;
        }
        bool any=false;for(intE e=0;e<n;++e)if(live[e]){result[e]=k;any=true;}
        if(!any)break;
    }
    return result;
}
template<class Paths,class Members> static void validate(const vector<pair<intV,intV>>& edges,const vector<char>& alive,
        const vector<intE>& phi,const vector<uint64_t>& es,const vector<uint64_t>* h,Paths paths,intB blooms,Members memberships) {
    auto gold=butterflies(edges,alive);auto levels=oracle(edges.size(),alive,gold);
    if(phi!=levels) {
        for(intE e=0;e<edges.size();++e)cerr<<"edge "<<e<<" ("<<edges[e].first<<","<<edges[e].second<<") actual="<<phi[e]<<" expected="<<levels[e]<<endl;
        throw runtime_error("labels differ from explicit static peeling");
    }
    vector<uint64_t> totals(edges.size(),0),own(edges.size(),0);
    for(auto q:gold)for(intE e:q) {
        ++totals[e];if(all_of(q.begin(),q.end(),[&](intE x){return phi[x]>=phi[e];}))++own[e];
    }
    if(totals!=es)throw runtime_error("total support mismatch");
    if(h&&own!=*h)throw runtime_error("persistent h mismatch");
    vector<Butterfly> indexed;
    vector<vector<pair<intB,intE>>> expected(edges.size());
    for(intB b=0;b<blooms;++b) {
        vector<pair<intE,intE>> wedges;paths(b,[&](auto w){wedges.push_back(w);});
        for(auto w:wedges) {
            expected.at(w.first).push_back({b,w.second});expected.at(w.second).push_back({b,w.first});
        }
        for(size_t i=0;i<wedges.size();++i)for(size_t j=i+1;j<wedges.size();++j) {
            Butterfly q={wedges[i].first,wedges[i].second,wedges[j].first,wedges[j].second};
            for(intE e:q)if(e>=edges.size()||!alive[e])throw runtime_error("dead edge in index");
            sort(q.begin(),q.end());indexed.push_back(q);
        }
    }
    sort(indexed.begin(),indexed.end());
    if(indexed!=gold)throw runtime_error("BEIndex butterfly partition mismatch");
    for(intE e=0;e<edges.size();++e) {
        vector<pair<intB,intE>> actual;memberships(e,[&](auto item){actual.push_back(item);});
        sort(actual.begin(),actual.end());sort(expected[e].begin(),expected[e].end());
        if(actual!=expected[e])throw runtime_error("BEIndex reverse membership mismatch");
    }
    ++checks;
}
static shared_ptr<Insertion60Base> makeBase(int left,int right,uint64_t mask,mt19937_64* rng=nullptr) {
    auto base=make_shared<Insertion60Base>();base->graph=Graph(right,left,0);
    iota(base->graph.uLabels.begin(),base->graph.uLabels.end(),0);
    iota(base->graph.vLabels.begin(),base->graph.vLabels.end(),left);
    base->left.resize(left+right,0);fill(base->left.begin(),base->left.begin()+left,1);
    for(int u=0;u<left;++u)for(int v=left;v<left+right;++v) {
        bool add=rng?((*rng)()%100<55):((mask>>(u*right+v-left))&1);
        if(add)insertEdgeIntoG(base->graph,u,v);
    }
    if(rng) {
        vector<intV> permutation(left+right);iota(permutation.begin(),permutation.end(),0);
        shuffle(permutation.begin(),permutation.end(),*rng);
        base->graph.reorder_in_place(permutation);
        fill(base->left.begin(),base->left.end(),0);
        for(int v=0;v<left;++v)base->left[permutation[v]]=1;
    }
    return base;
}
static void insertion(shared_ptr<Insertion60Base> base,vector<pair<intV,intV>> sequence) {
    vector<intE> es,phi;arrayBuildBase(base->graph,base->index,es,phi);
    Insertion60State initial(base,phi,vector<uint64_t>(es.begin(),es.end()));
    Insertion60State bm=initial,sa=initial,sap=initial;Insertion68State plus(initial);
    for(auto uv:sequence) {
        Insertion60Metrics mb,ma,mp;Insertion68Metrics mh;
        bm.INSERT(uv.first,uv.second,&mb,false,false,false);
        sa.INSERT(uv.first,uv.second,&ma,false,false,true);
        sap.INSERT(uv.first,uv.second,&mp,true,true,true);
        plus.insert(uv.first,uv.second,&mh);
        if(mb.candidates!=ma.candidates||mb.supportInitializations!=ma.supportInitializations)throw runtime_error("BM/SA candidate domains differ");
        if(mb.algebraReads||mb.bloomBuilds||mb.algebraLossGroups||mb.eeChecks||mb.filterChecks||ma.eeChecks||ma.filterChecks)throw runtime_error("insertion mechanism isolation");
        explicitWitnesses+=mb.explicitWitnessPairs;eeStops+=mp.eeStops+mh.eeStops;
        for(auto* state:{&bm,&sa,&sap,static_cast<Insertion60State*>(&plus)}) {
            vector<pair<intV,intV>> edges;for(intE e=0;e<state->edges();++e)edges.push_back(state->endpoints(e));
            validate(edges,vector<char>(edges.size(),1),state->phi,state->es,state==&plus?&plus.h:nullptr,
                [&](intB b,auto fn){state->wedges(b,fn);},state->blooms(),
                [&](intE e,auto fn){state->memberships(e,fn);});
        }
        ++events;
    }
}
static void deletion(shared_ptr<Insertion60Base> base,vector<intE> sequence) {
    vector<intE> es,phi;arrayBuildBase(base->graph,base->index,es,phi);
    array<BEGraphLoMem,4> indexes={base->index,base->index,base->index,base->index};
    array<vector<intE>,4> labels={phi,phi,phi,phi},supports={es,es,es,es};
    vector<intB> h;buildPersistentSupport(base->index,phi,h);PersistentWorkspace persistent;
    vector<char> alive(phi.size(),1);
    for(intE removed:sequence) {
        alive[removed]=0;
        long long bmCandidates=-1;
        for(int method=0;method<4;++method) {
            Layer56Metrics m;
            if(method==3)arrayBMDPersistent(indexes[method],labels[method],supports[method],h,removed,persistent);
            else arrayBMD_layer(indexes[method],labels[method],supports[method],removed,method==2,1,&m,method!=0,nullptr,method==2);
            if(method<2&&(m.eeChecks||m.pruningMemberships))throw runtime_error("deletion EE/filter isolation");
            if(method==0&&(m.bloomBuilds||m.algebraLossGroups))throw runtime_error("deletion algebra isolation");
            if(method==0)bmCandidates=m.C;
            if(method==1&&m.C!=bmCandidates)throw runtime_error("BM/SA deletion candidate domains differ");
            explicitWitnesses+=m.explicitWitnessPairs;eeStops+=m.eeStops;
            vector<uint64_t> total(supports[method].begin(),supports[method].end()),own(h.begin(),h.end());
            auto& index=indexes[method];
            validate(base->graph.eIdToV,alive,labels[method],total,method==3?&own:nullptr,
                [&](intB b,auto fn){for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j)fn(index.bloomEI[j]);},index.numV,
                [&](intE e,auto fn){for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i)if(index.edgeEI[i].first>=0)fn(index.edgeEI[i]);});
        }
        ++events;
    }
}
int main() {
    if(!freopen("/dev/null","w",stdout))return 2;string context;
    try {
        for(uint64_t mask=0;mask<512;++mask) {
            auto base=makeBase(3,3,mask);
            vector<intE> es,phi;arrayBuildBase(base->graph,base->index,es,phi);
            for(int u=0;u<3;++u)for(int v=3;v<6;++v)if(!(mask>>(u*3+v-3)&1)) {
                context="exhaustive insertion mask="+to_string(mask)+" uv="+to_string(u)+","+to_string(v);
                insertion(base,{{u,v}});
            }
            for(intE e=0;e<phi.size();++e) {
                context="exhaustive deletion mask="+to_string(mask)+" edge="+to_string(e);
                deletion(base,{e});
            }
        }
        mt19937_64 rng(10720261027ULL);
        for(int trial=0;trial<200;++trial) {
            auto base=makeBase(4+trial%4,4+(trial/4)%4,0,&rng);
            vector<intE> es,phi;arrayBuildBase(base->graph,base->index,es,phi);
            vector<pair<intV,intV>> insertions;
            for(intV u=0;u<base->graph.numT;++u)for(intV v=u+1;v<base->graph.numT;++v)
                if(base->left[u]!=base->left[v]&&!binary_search(base->graph.adj[u].begin(),base->graph.adj[u].end(),v))insertions.push_back({u,v});
            shuffle(insertions.begin(),insertions.end(),rng);
            context="random cumulative insertion trial="+to_string(trial);insertion(base,insertions);
            vector<intE> removals(phi.size());iota(removals.begin(),removals.end(),0);shuffle(removals.begin(),removals.end(),rng);
            context="random cumulative deletion trial="+to_string(trial);deletion(base,removals);
        }
        if(!eeStops||!explicitWitnesses)throw runtime_error("mechanism branches not exercised");
        cerr<<"{\"exhaustive_graphs\":512,\"random_graphs\":200,\"seed\":10720261027,\"events\":"<<events
            <<",\"method_checks\":"<<checks<<",\"ee_stops\":"<<eeStops<<",\"explicit_lost_witnesses\":"<<explicitWitnesses<<",\"failures\":0}"<<endl;
    } catch(const exception& error) {cerr<<"FAIL "<<context<<": "<<error.what()<<endl;return 1;}
}
